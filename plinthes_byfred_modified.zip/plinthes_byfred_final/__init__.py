# SPDX-License-Identifier: GPL-3.0-or-later
"""
plinthes_byfred - baseboard / skirting, door and window casing generator.

Workflow
--------
Baseboard : in Edit Mode, select the wall faces (or the bottom edges) of a room
            and press "Create Baseboard".  A mitred, profiled skirting is built
            along the bottom (or the top, for a crown) of the selection.

Door Frame: in Edit Mode, select the outline of an opening and press
            "Create Door Frame".  A mitred casing is built around it, on one or
            both sides of the wall, with an optional jamb lining.

Both generators keep a live link with their settings: change any value and the
mesh is rebuilt instantly.
"""

bl_info = {
    "name": "plinthes fred",
    "author": "byfred",
    "version": (1, 11, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > plinthes fred",
    "description": "Baseboards, crown mouldings and door casings from selected wall geometry",
    "category": "Add Mesh",
}

import json
import math
import os

import bpy
import bmesh
from mathutils import Matrix, Vector
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty,
                       PointerProperty, StringProperty)
from bpy.types import Operator, Panel, PropertyGroup


import sys as _sys

# ===========================================================================
#  Geometry core (kept in this file on purpose: a single-file add-on cannot
#  end up running a stale cached submodule after an in-place upgrade)
# ===========================================================================

# ---------------------------------------------------------------------------
# 2D corner profiles
# ---------------------------------------------------------------------------
#
# All corner shapes are described in a normalised "corner space" (p, q):
#
#       q
#       ^
#   E (0,1) ______
#       |         \
#       |          \   <- the profile curve
#       |           \
#   C (0,0) ---------- S (1,0)  -> p
#
# C is the sharp corner apex, S the start point on the first face and E the
# end point on the second face.  A real point is:
#
#       P = C + p * (S - C) + q * (E - C)
#
# so the same table works whatever the physical size of the cut is.

EDGE_PROFILES = ('SQUARE', 'CHAMFER', 'BULLNOSE', 'COVE', 'OGEE', 'STEPPED')


def _arc(cx, cy, r, a0, a1, segs):
    """Sample an arc, angles in degrees, both ends included."""
    pts = []
    segs = max(1, int(segs))
    for i in range(segs + 1):
        t = i / segs
        a = math.radians(a0 + (a1 - a0) * t)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def corner_points(kind, segments=4, steps=2):
    """Return the corner curve in (p, q) space, from S=(1,0) to E=(0,1)."""
    if kind == 'SQUARE':
        return [(1.0, 0.0), (0.0, 0.0), (0.0, 1.0)]

    if kind == 'CHAMFER':
        return [(1.0, 0.0), (0.0, 1.0)]

    n = max(1, int(segments))

    if kind == 'BULLNOSE':
        # convex round-over: circle centred "inside" the material
        return _arc(1.0, 1.0, 1.0, -90.0, -180.0, n)

    if kind == 'COVE':
        # concave scoop: circle centred on the apex
        return _arc(0.0, 0.0, 1.0, 0.0, 90.0, n)

    if kind == 'OGEE':
        a = _arc(0.5, 0.0, 0.5, 0.0, 90.0, n)
        b = _arc(0.5, 1.0, 0.5, -90.0, -180.0, n)
        return a + b[1:]

    if kind == 'STEPPED':
        m = max(1, int(steps))
        pts = [(1.0, 0.0)]
        for i in range(m):
            p1 = 1.0 - (i + 1) / m
            q0 = i / m
            q1 = (i + 1) / m
            pts.append((p1, q0))
            pts.append((p1, q1))
        return pts

    return [(1.0, 0.0), (0.0, 0.0), (0.0, 1.0)]


def map_corner(pts, corner, start, end):
    """Map (p, q) corner-space points onto a real 2D corner."""
    cx, cy = corner
    ax, ay = start[0] - cx, start[1] - cy
    bx, by = end[0] - cx, end[1] - cy
    return [(cx + p * ax + q * bx, cy + p * ay + q * by) for p, q in pts]


def _dedup(pts, eps=1e-7):
    out = []
    for p in pts:
        if not out or abs(p[0] - out[-1][0]) > eps or abs(p[1] - out[-1][1]) > eps:
            out.append(p)
    # a closed loop must not repeat its first point at the end
    if len(out) > 1 and abs(out[0][0] - out[-1][0]) <= eps and abs(out[0][1] - out[-1][1]) <= eps:
        out.pop()
    return out


def build_profile(size_a, size_b,
                  inner='SQUARE', inner_size=0.5, inner_segments=4,
                  inner_steps=2, inner_step_depth=0.5,
                  outer='CHAMFER', outer_size=0.5, outer_segments=4,
                  outer_steps=2, outer_step_depth=0.5,
                  flip_a=False, flip_b=False):
    """Closed 2D cross-section of a moulding, as a list of (a, b).

    a = 0 sits against the wall (baseboard) or against the opening (casing)
        and grows outwards up to ``size_a``.
    b = 0 sits on the floor (baseboard) or on the wall surface (casing)
        and grows up to ``size_b``.

    The two top corners are the shaped ones:
      * outer corner  = (size_a, size_b)  -> the visible front edge
      * inner corner  = (0, size_b)       -> the edge that dies into the wall
    """
    a = max(float(size_a), 1e-5)
    b = max(float(size_b), 1e-5)

    ref = min(a, b)
    ko = 0.0 if outer == 'SQUARE' else max(0.0, min(float(outer_size), 1.0)) * ref
    ki = 0.0 if inner == 'SQUARE' else max(0.0, min(float(inner_size), 1.0)) * ref

    # how deep the cut bites into the front face (b axis)
    ko_b = min(ko, b * 0.98)
    ki_b = min(ki, b * 0.98)

    # how far it travels along the top face (a axis).  Stepped profiles may
    # reach much further than the thickness, which is what gives a moulding
    # its relief instead of a flat slab.
    ko_a = ko * (max(0.02, float(outer_step_depth)) if outer == 'STEPPED' else 1.0)
    ki_a = ki * (max(0.02, float(inner_step_depth)) if inner == 'STEPPED' else 1.0)

    # the two cuts share the top face, keep a sliver of flat between them
    total = ko_a + ki_a
    if total > a * 0.98:
        f = (a * 0.98) / total if total > 0.0 else 0.0
        ko_a *= f
        ki_a *= f

    pts = [(0.0, 0.0), (a, 0.0)]

    if ko_b > 0.0 and ko_a > 0.0:
        pts += map_corner(corner_points(outer, outer_segments, outer_steps),
                          corner=(a, b), start=(a, b - ko_b), end=(a - ko_a, b))
    else:
        pts.append((a, b))

    if ki_b > 0.0 and ki_a > 0.0:
        pts += map_corner(corner_points(inner, inner_segments, inner_steps),
                          corner=(0.0, b), start=(ki_a, b), end=(0.0, b - ki_b))
    else:
        pts.append((0.0, b))

    pts = _dedup(pts)

    if flip_a:
        pts = [(-p, q) for p, q in pts]
    if flip_b:
        pts = [(p, -q) for p, q in pts]
    return pts


def profile_lengths(profile):
    """Cumulative perimeter of a closed profile, len = len(profile) + 1."""
    out = [0.0]
    n = len(profile)
    for i in range(n):
        x0, y0 = profile[i]
        x1, y1 = profile[(i + 1) % n]
        out.append(out[-1] + math.hypot(x1 - x0, y1 - y0))
    return out


# ---------------------------------------------------------------------------
# Edge chaining
# ---------------------------------------------------------------------------

def chain_segments(segments):
    """Turn a soup of (a, b) index pairs into runs.

    Returns a list of ``(vertex_keys, closed)`` tuples.  Open runs come first,
    then closed loops.  Junctions with more than two edges simply split runs.
    """
    adj = {}
    edges = set()
    for a, b in segments:
        if a == b:
            continue
        key = (a, b) if a < b else (b, a)
        if key in edges:
            continue
        edges.add(key)
        adj.setdefault(a, []).append(b)
        adj.setdefault(b, []).append(a)

    used = set()
    runs = []

    def ekey(a, b):
        return (a, b) if a < b else (b, a)

    def walk(start, first):
        chain = [start, first]
        used.add(ekey(start, first))
        cur = first
        while True:
            if len(adj.get(cur, ())) != 2:
                break
            nxt = None
            for cand in adj[cur]:
                if ekey(cur, cand) not in used:
                    nxt = cand
                    break
            if nxt is None:
                break
            used.add(ekey(cur, nxt))
            chain.append(nxt)
            cur = nxt
            if cur == start:
                break
        return chain

    # open runs, starting from every endpoint / junction
    for v in sorted(k for k, n in adj.items() if len(n) != 2):
        for nb in list(adj[v]):
            if ekey(v, nb) in used:
                continue
            runs.append((walk(v, nb), False))

    # whatever is left is made of closed loops
    for a, b in sorted(edges):
        if (a, b) in used:
            continue
        chain = walk(a, b)
        closed = len(chain) > 2 and chain[0] == chain[-1]
        if closed:
            chain = chain[:-1]
        runs.append((chain, closed))

    return [(c, cl) for c, cl in runs if len(c) >= 2]


# ---------------------------------------------------------------------------
# Sweeping
# ---------------------------------------------------------------------------

def _v(x):
    return Vector(x) if Vector is not None else x


def run_frames(points, closed, normal, outs, miter_limit=8.0):
    """Per-point mitre vectors.

    ``normal``  the plane normal of the run (profile "b" axis)
    ``outs``    one desired outward direction per segment (profile "a" axis)

    Returns ``(mitres, scales, sign, lengths)``.
    """
    N = normal.normalized()
    n = len(points)
    nseg = n if closed else n - 1

    tangents = []
    for i in range(nseg):
        t = points[(i + 1) % n] - points[i]
        if t.length < 1e-9:
            t = Vector((1.0, 0.0, 0.0))
        tangents.append(t.normalized())

    # which way round does (t x N) have to be flipped so it matches `outs`?
    vote = 0.0
    for i, t in enumerate(tangents):
        s = t.cross(N)
        if s.length < 1e-9:
            continue
        o = outs[i] if i < len(outs) else outs[-1]
        vote += s.normalized().dot(o)
    sign = -1.0 if vote < 0.0 else 1.0

    sides = []
    for t in tangents:
        s = t.cross(N)
        if s.length < 1e-9:
            s = Vector((1.0, 0.0, 0.0))
        sides.append(s.normalized() * sign)

    mitres, scales = [], []
    for i in range(n):
        if closed:
            s_prev = sides[i - 1]
            s_next = sides[i % nseg]
        else:
            s_prev = sides[i - 1] if i > 0 else sides[0]
            s_next = sides[i] if i < nseg else sides[-1]
        m = s_prev + s_next
        if m.length < 1e-6:
            mitres.append(s_next.copy())
            scales.append(1.0)
        else:
            m.normalize()
            d = m.dot(s_next)
            scales.append(1.0 / max(d, 1.0 / max(1.0, miter_limit)))
            mitres.append(m)

    lengths = [0.0]
    for i in range(nseg):
        lengths.append(lengths[-1] + (points[(i + 1) % n] - points[i]).length)

    return mitres, scales, sign, lengths


def sweep_run(points, closed, normal, outs, profile,
              miter_limit=8.0, offset_a=0.0, offset_b=0.0,
              uv_scale=1.0, u_scale=None, v_coords=None, cap_ends=True):
    """Sweep a closed 2D profile along a planar polyline.

    ``u_scale``   multiplier applied to the distance along the path.
    ``v_coords``  explicit V per profile point (len == len(profile) + 1).
                  Defaults to the profile perimeter in metres.

    Returns ``(verts, faces, face_uvs)`` where faces index into verts and
    face_uvs holds one (u, v) per face corner.
    """
    N = normal.normalized()
    n = len(points)
    mitres, scales, _sign, lengths = run_frames(points, closed, N, outs, miter_limit)
    plen = profile_lengths(profile)

    if u_scale is None:
        u_scale = uv_scale
    if v_coords is None:
        v_coords = [x * uv_scale for x in plen]

    verts = []
    rings = []
    for i in range(n):
        ring = []
        for (a, b) in profile:
            p = (points[i]
                 + mitres[i] * ((a + offset_a) * scales[i])
                 + N * (b + offset_b))
            ring.append(len(verts))
            verts.append(p)
        rings.append(ring)

    faces, face_uvs = [], []
    P = len(profile)
    nseg = n if closed else n - 1
    for i in range(nseg):
        r0 = rings[i]
        r1 = rings[(i + 1) % n]
        u0 = lengths[i] * u_scale
        u1 = lengths[i + 1] * u_scale
        for j in range(P):
            k = (j + 1) % P
            v0 = v_coords[j]
            v1 = v_coords[j + 1]
            faces.append((r0[j], r0[k], r1[k], r1[j]))
            face_uvs.append(((u0, v0), (u0, v1), (u1, v1), (u1, v0)))

    if cap_ends and not closed and n >= 2:
        caps = [(a * u_scale, b * u_scale) for a, b in profile]
        faces.append(tuple(reversed(rings[0])))
        face_uvs.append(tuple(reversed(caps)))
        faces.append(tuple(rings[-1]))
        face_uvs.append(tuple(caps))

    return verts, faces, face_uvs


# ---------------------------------------------------------------------------
# Path post-processing
# ---------------------------------------------------------------------------

def _turn_angle(prev, cur, nxt):
    """Angle between the incoming and outgoing direction at a vertex."""
    t0 = cur - prev
    t1 = nxt - cur
    if t0.length < 1e-9 or t1.length < 1e-9:
        return 0.0
    d = max(-1.0, min(1.0, t0.normalized().dot(t1.normalized())))
    return math.acos(d)


def _catmull(p0, p1, p2, p3, t, alpha=0.5):
    """Centripetal Catmull-Rom: follows an arc closely, never overshoots."""
    def knot(ti, pa, pb):
        d = (pb - pa).length
        return ti + (d ** alpha if d > 1e-12 else 1e-12)

    t0 = 0.0
    t1 = knot(t0, p0, p1)
    t2 = knot(t1, p1, p2)
    t3 = knot(t2, p2, p3)
    tt = t1 + (t2 - t1) * t

    def lerp(pa, pb, ta, tb):
        if abs(tb - ta) < 1e-12:
            return pa.copy()
        f = (tt - ta) / (tb - ta)
        return pa * (1.0 - f) + pb * f

    a1 = lerp(p0, p1, t0, t1)
    a2 = lerp(p1, p2, t1, t2)
    a3 = lerp(p2, p3, t2, t3)
    b1 = lerp(a1, a2, t0, t2)
    b2 = lerp(a2, a3, t1, t3)
    return lerp(b1, b2, t1, t2)


def refine_run(points, outs, closed, subdiv, max_angle):
    """Subdivide the curved parts of a run, leaving corners untouched.

    A low-poly arch (an arched doorway modelled with 4 or 6 facets) becomes a
    smooth curve, while square corners and straight walls are left exactly as
    they are.
    """
    n = len(points)
    nseg = n if closed else n - 1
    subdiv = int(subdiv)
    if subdiv < 1 or nseg < 2:
        return points, outs

    smooth = []
    for i in range(n):
        if not closed and (i == 0 or i == n - 1):
            smooth.append(False)
            continue
        ang = _turn_angle(points[i - 1], points[i], points[(i + 1) % n])
        smooth.append(1e-4 < ang <= max_angle)

    new_pts = []
    new_outs = []
    for i in range(nseg):
        p1 = points[i]
        p2 = points[(i + 1) % n]
        o = outs[i] if i < len(outs) else outs[-1]
        new_pts.append(p1)

        if smooth[i] or smooth[(i + 1) % n]:
            p0 = points[i - 1] if (closed or i > 0) else p1 + (p1 - p2)
            p3 = points[(i + 2) % n] if (closed or i + 2 < n) else p2 + (p2 - p1)
            for k in range(1, subdiv + 1):
                new_pts.append(_catmull(p0, p1, p2, p3, k / (subdiv + 1.0)))
            new_outs.extend([o] * (subdiv + 1))
        else:
            new_outs.append(o)

    if not closed:
        new_pts.append(points[-1])
    return new_pts, new_outs


def extend_ends(points, closed, start_amount, end_amount):
    """Push each open end of a run outwards by its own amount."""
    if closed or len(points) < 2:
        return points
    pts = [p.copy() for p in points]
    if start_amount:
        t = pts[0] - pts[1]
        if t.length > 1e-9:
            pts[0] = pts[0] + t.normalized() * start_amount
    if end_amount:
        t = pts[-1] - pts[-2]
        if t.length > 1e-9:
            pts[-1] = pts[-1] + t.normalized() * end_amount
    return pts


def extend_run(points, closed, amount):
    """Push the two open ends of a run further along their tangents."""
    if closed or amount == 0.0 or len(points) < 2:
        return points
    pts = [p.copy() for p in points]
    t0 = (pts[0] - pts[1])
    if t0.length > 1e-9:
        pts[0] = pts[0] + t0.normalized() * amount
    t1 = (pts[-1] - pts[-2])
    if t1.length > 1e-9:
        pts[-1] = pts[-1] + t1.normalized() * amount
    return pts


def _runs_from_segments(points, outs, seg_ids, n, nseg, closed):
    """Group consecutive segment ids into open runs."""
    groups = []
    cur = [seg_ids[0]]
    for i in seg_ids[1:]:
        if i == cur[-1] + 1:
            cur.append(i)
        else:
            groups.append(cur)
            cur = [i]
    groups.append(cur)

    # a closed loop can wrap around index 0
    if closed and len(groups) > 1 and groups[0][0] == 0 and groups[-1][-1] == nseg - 1:
        groups[0] = groups[-1] + groups[0]
        groups.pop()

    runs = []
    for g in groups:
        pts = [points[g[0]]]
        os_ = []
        for i in g:
            pts.append(points[(i + 1) % n])
            os_.append(outs[i] if i < len(outs) else outs[-1])
        runs.append((pts, os_, False))
    return runs


def split_at_bottom(points, outs, closed, tol=1e-4):
    """Split a loop into (everything else, the horizontal runs at the lowest Z).

    The door tool throws the bottom away; the window tool turns it into a sill.
    """
    n = len(points)
    nseg = n if closed else n - 1
    if nseg < 2:
        return [(points, outs, closed)], []

    zmin = min(p.z for p in points)
    drop = []
    for i in range(nseg):
        a = points[i]
        b = points[(i + 1) % n]
        if abs(a.z - b.z) <= tol and abs(0.5 * (a.z + b.z) - zmin) <= tol:
            drop.append(i)

    if not drop:
        return [(points, outs, closed)], []

    keep = [i for i in range(nseg) if i not in drop]
    other = _runs_from_segments(points, outs, keep, n, nseg, closed) if keep else []
    bottom = _runs_from_segments(points, outs, drop, n, nseg, closed)
    return other, bottom


def split_bottom(points, outs, closed, tol=1e-4):
    """Drop the horizontal segments sitting at the lowest Z of a closed loop."""
    other, _ = split_at_bottom(points, outs, closed, tol)
    return other if other else [(points, outs, closed)]


tc = _sys.modules[__name__]

# ===========================================================================
#  Blender integration
# ===========================================================================

# Blender removes bl_info from the module namespace when the add-on is installed
# as an extension, so the version is kept in a plain constant as well.
ADDON_VERSION = (1, 11, 0)

BASEBOARD_COLL = "trim_baseboards"
DOORFRAME_COLL = "trim_doorframes"
WINDOW_COLL = "trim_windows"

# kind -> (object property, scene property, object name base, collection)
KINDS = {
    'BASEBOARD': ("trim_baseboard", "baseboard", "baseboard", BASEBOARD_COLL),
    'DOORFRAME': ("trim_doorframe", "doorframe", "doorframe", DOORFRAME_COLL),
    'WINDOWFRAME': ("trim_windowframe", "windowframe", "windowframe", WINDOW_COLL),
}

_GUARD = False  # blocks re-entrant rebuilds while properties are copied


# ---------------------------------------------------------------------------
# Property groups
# ---------------------------------------------------------------------------

EDGE_ITEMS = [
    ('SQUARE', "Square", "Keep the corner sharp"),
    ('CHAMFER', "Chamfer", "Straight bevel"),
    ('BULLNOSE', "Bullnose", "Convex round-over"),
    ('COVE', "Cove", "Concave scoop"),
    ('OGEE', "Ogee", "Classic S-curve"),
    ('STEPPED', "Stepped", "Stair-stepped profile"),
]

SHAPED = {'CHAMFER', 'BULLNOSE', 'COVE', 'OGEE', 'STEPPED'}
ROUNDED = {'BULLNOSE', 'COVE', 'OGEE'}


def _prop_update(self, context):
    """Live update callback shared by every setting."""
    if _GUARD:
        return
    obj = self.id_data
    if not isinstance(obj, bpy.types.Object):
        return
    if not obj.get("trim_type"):
        return
    if not self.live_update:
        return
    try:
        rebuild_object(obj)
    except Exception as exc:  # never let a UI edit raise
        print("[plinthes fred] rebuild failed:", exc)


BASEBOARD_PRESETS = {
    'FLAT': dict(height=0.10, depth=0.015,
                 inner_edge='SQUARE', outer_edge='SQUARE'),
    'CHAMFER': dict(height=0.10, depth=0.018,
                    inner_edge='SQUARE',
                    outer_edge='CHAMFER', outer_size=0.5),
    'BULLNOSE': dict(height=0.12, depth=0.018,
                     inner_edge='SQUARE',
                     outer_edge='BULLNOSE', outer_size=1.0, outer_segments=6),
    'COVE': dict(height=0.12, depth=0.020,
                 inner_edge='SQUARE',
                 outer_edge='COVE', outer_size=0.9, outer_segments=6),
    'OGEE': dict(height=0.14, depth=0.020,
                 inner_edge='COVE', inner_size=0.3, inner_segments=4,
                 outer_edge='OGEE', outer_size=1.0, outer_segments=8),
    'STEPPED': dict(height=0.14, depth=0.022,
                    inner_edge='SQUARE',
                    outer_edge='STEPPED', outer_size=0.95, outer_steps=3,
                    outer_step_depth=1.8),
    'COLONIAL': dict(height=0.16, depth=0.022,
                     inner_edge='STEPPED', inner_size=0.5, inner_steps=1,
                     inner_step_depth=1.2,
                     outer_edge='OGEE', outer_size=1.0, outer_segments=8),
    'VICTORIAN': dict(height=0.19, depth=0.025,
                      inner_edge='COVE', inner_size=0.45, inner_segments=5,
                      outer_edge='STEPPED', outer_size=1.0, outer_steps=4,
                      outer_step_depth=2.2),
}

CASING_PRESETS = {
    'FLAT': dict(width=0.09, thickness=0.018,
                 inner_edge='SQUARE', outer_edge='SQUARE'),
    'CHAMFER': dict(width=0.09, thickness=0.020,
                    inner_edge='SQUARE',
                    outer_edge='CHAMFER', outer_size=0.5),
    'STEPPED': dict(width=0.109, thickness=0.029,
                    inner_edge='STEPPED', inner_size=0.62, inner_steps=1,
                    inner_step_depth=0.74,
                    outer_edge='CHAMFER', outer_size=0.5),
    'MOLDED': dict(width=0.115, thickness=0.030,
                   inner_edge='STEPPED', inner_size=0.6, inner_steps=2,
                   inner_step_depth=1.3,
                   outer_edge='OGEE', outer_size=0.9, outer_segments=8),
    'BULLNOSE': dict(width=0.09, thickness=0.025,
                     inner_edge='SQUARE',
                     outer_edge='BULLNOSE', outer_size=1.0, outer_segments=6),
    'CRAFTSMAN': dict(width=0.14, thickness=0.025,
                      inner_edge='SQUARE',
                      outer_edge='STEPPED', outer_size=0.95, outer_steps=2,
                      outer_step_depth=1.6),
    'VICTORIAN': dict(width=0.13, thickness=0.034,
                      inner_edge='COVE', inner_size=0.5, inner_segments=5,
                      outer_edge='STEPPED', outer_size=1.0, outer_steps=3,
                      outer_step_depth=2.0),
}

PRESET_ITEMS = [
    ('FLAT', "Flat Slab", "Plain rectangular board, no relief"),
    ('CHAMFER', "Chamfered", "Simple bevel on the front edge"),
    ('BULLNOSE', "Bullnose", "Rounded front edge"),
    ('COVE', "Cove", "Concave scoop"),
    ('OGEE', "Ogee", "Classic S-curve moulding"),
    ('STEPPED', "Stepped", "Stair-stepped moulding"),
    ('MOLDED', "Molded", "Steps at the opening plus an ogee outside"),
    ('CRAFTSMAN', "Craftsman", "Wide flat board with a stepped outer edge"),
    ('COLONIAL', "Colonial", "Stepped back, ogee front"),
    ('VICTORIAN', "Victorian", "Tall, deeply moulded"),
]


# ---------------------------------------------------------------------------
# User presets, saved as plain JSON next to Blender's own config
# ---------------------------------------------------------------------------

PRESET_SKIP = {"rna_type", "name", "live_update", "user_preset", "preset"}

# Blender needs the enum item strings to stay alive, so they are cached here
_ENUM_CACHE = {}

PG_KIND = {
    "TRIM_PG_baseboard": 'BASEBOARD',
    "TRIM_PG_doorframe": 'DOORFRAME',
    "TRIM_PG_windowframe": 'WINDOWFRAME',
}


def preset_dir():
    return bpy.utils.user_resource('CONFIG', path="plinthes_fred", create=True)


def preset_path(kind):
    return os.path.join(preset_dir(), "%s.json" % kind.lower())


def load_presets(kind):
    try:
        with open(preset_path(kind), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def write_presets(kind, data):
    with open(preset_path(kind), "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)


def settings_to_dict(s):
    """Every plain value of a settings group. Material is an ID, so it is
    skipped: a preset is a shape, not a link to a specific datablock."""
    out = {}
    for prop in s.bl_rna.properties:
        if prop.identifier in PRESET_SKIP or prop.is_readonly:
            continue
        if prop.type == 'POINTER':
            continue
        value = getattr(s, prop.identifier)
        if isinstance(value, (bool, int, float, str)):
            out[prop.identifier] = value
    return out


def apply_dict(s, data):
    global _GUARD
    _GUARD = True
    try:
        for key, value in data.items():
            if key in PRESET_SKIP:
                continue
            if not hasattr(s, key):
                continue                      # preset from an older version
            try:
                setattr(s, key, value)
            except (TypeError, ValueError):
                pass                          # an enum item that no longer exists
    finally:
        _GUARD = False

    obj = s.id_data
    if isinstance(obj, bpy.types.Object) and obj.get("trim_type") and s.live_update:
        try:
            rebuild_object(obj)
        except Exception as exc:
            print("[plinthes fred] rebuild failed:", exc)


def settings_kind(s):
    return PG_KIND.get(s.bl_rna.identifier, 'BASEBOARD')


def _user_preset_items(self, context):
    kind = settings_kind(self)
    names = sorted(load_presets(kind))
    if not names:
        items = [('NONE', "No saved presets", "Use the + button to save one")]
    else:
        items = [('NONE', "Select...", "")]
        items += [(n, n, "Apply the saved preset '%s'" % n) for n in names]
    _ENUM_CACHE[kind] = items
    return items


def _user_preset_update(self, context):
    if _GUARD or self.user_preset == 'NONE':
        return
    data = load_presets(settings_kind(self)).get(self.user_preset)
    if data:
        apply_dict(self, data)


def _apply_preset(s, table):
    """Push a preset's values onto a settings group, then rebuild once."""
    global _GUARD
    values = table.get(s.preset)
    if not values:
        return
    _GUARD = True
    try:
        for key, value in values.items():
            setattr(s, key, value)
    finally:
        _GUARD = False

    obj = s.id_data
    if isinstance(obj, bpy.types.Object) and obj.get("trim_type") and s.live_update:
        try:
            rebuild_object(obj)
        except Exception as exc:
            print("[plinthes fred] rebuild failed:", exc)


def _preset_update_baseboard(self, context):
    if not _GUARD:
        _apply_preset(self, BASEBOARD_PRESETS)


def _preset_update_casing(self, context):
    if not _GUARD:
        _apply_preset(self, CASING_PRESETS)


def _preset_prop(update, default, table):
    items = [it for it in PRESET_ITEMS if it[0] in table]
    return EnumProperty(name="Preset", items=items, default=default, update=update)


def _edge_props(prefix, default_kind, default_size):
    """Build the property dict for one shaped edge (inner or outer)."""
    return {
        prefix + "_edge": EnumProperty(
            name="Edge", items=EDGE_ITEMS, default=default_kind, update=_prop_update),
        prefix + "_size": FloatProperty(
            name="Size", default=default_size, min=0.0, max=1.0, subtype='FACTOR',
            description="Cut size, as a fraction of the smallest profile dimension",
            update=_prop_update),
        prefix + "_segments": IntProperty(
            name="Segments", default=3, min=1, max=32, update=_prop_update),
        prefix + "_steps": IntProperty(
            name="Steps", default=2, min=1, max=16, update=_prop_update),
        prefix + "_step_depth": FloatProperty(
            name="Step Depth", default=0.6, min=0.02, max=4.0, soft_max=2.5,
            description="How far the steps travel along the face. Above 1.0 the "
                        "moulding gets real relief instead of a flat slab",
            update=_prop_update),
    }


def _common_props():
    """Fresh property definitions shared by both tools.

    A new dict of new property definitions is built on every call: property
    definitions must never be shared between two registered classes.
    """
    return {
        "live_update": BoolProperty(
            name="Live Update", default=True,
            description="Rebuild the mesh as soon as a setting changes"),
        "user_preset": EnumProperty(
            name="My Presets", items=_user_preset_items,
            update=_user_preset_update,
            description="Your own saved presets"),
        "flip_side": BoolProperty(
            name="Flip Side", default=False,
            description="Build on the other side of the wall",
            update=_prop_update),
        # unwrap
        "uv_enabled": BoolProperty(name="Generate UVs", default=True, update=_prop_update),
        "uv_mode": EnumProperty(
            name="Mode", update=_prop_update, default='AUTO',
            items=[('AUTO', "Fit Texture",
                    "V spans the visible profile, U tiles from the texture aspect "
                    "ratio so the pixels stay square"),
                   ('TRIM', "Fit Profile",
                    "V spans the visible profile, U repeats every Tile Length"),
                   ('WORLD', "World Metres",
                    "Raw metres on both axes, for a plain tiling texture")]),
        "uv_tile_length": FloatProperty(
            name="Tile Length", default=0.5, min=0.001, soft_max=10.0,
            unit='LENGTH', description="Distance covered by one texture repeat",
            update=_prop_update),
        "uv_flip_v": BoolProperty(name="Flip V", default=False, update=_prop_update),
        "uv_lock": BoolProperty(
            name="Lock", default=False,
            description="Freeze the repeat length. Fit Texture will no longer "
                        "recompute it when the material changes",
            update=_prop_update),
        "uv_scale": FloatProperty(name="UV Scale", default=1.0, min=0.001, soft_max=10.0,
                                  update=_prop_update),
        # shading
        "shade_smooth": BoolProperty(name="Shade Smooth", default=True, update=_prop_update),
        "smooth_angle": FloatProperty(name="Angle", default=0.5236, min=0.0, max=3.14159,
                                      subtype='ANGLE', update=_prop_update),
        # material
        "material": PointerProperty(name="Material", type=bpy.types.Material,
                                    update=_prop_update),
        "refine": IntProperty(
            name="Refine Curves", default=0, min=0, max=8,
            description="Subdivide curved runs, for example the top of an arched "
                        "opening. Corners and straight runs are left untouched",
            update=_prop_update),
        "refine_angle": FloatProperty(
            name="Curve Limit", default=1.0472, min=0.0, max=3.14159,
            subtype='ANGLE',
            description="Turns sharper than this stay sharp corners",
            update=_prop_update),
        # advanced
        "miter_limit": FloatProperty(name="Miter Limit", default=8.0, min=1.0, max=50.0,
                                     update=_prop_update),
        "tolerance": FloatProperty(name="Tolerance", default=0.0005, min=0.000001,
                                   soft_max=0.05, precision=5, unit='LENGTH'),
        "parent_to_source": BoolProperty(name="Parent To Source", default=True),
    }


def _baseboard_annotations():
    d = _common_props()
    d["preset"] = _preset_prop(_preset_update_baseboard, 'CHAMFER', BASEBOARD_PRESETS)
    d.update(_edge_props("inner", 'SQUARE', 0.5))
    d.update(_edge_props("outer", 'CHAMFER', 0.5))
    d.update({
        "height": FloatProperty(
            name="Height", default=0.10, min=0.0005, soft_max=0.6,
            unit='LENGTH', update=_prop_update),
        "depth": FloatProperty(
            name="Depth", default=0.018, min=0.0005, soft_max=0.2,
            unit='LENGTH', update=_prop_update),
        "placement": EnumProperty(
            name="Placement", update=_prop_update,
            items=[('SKIRTING', "Skirting", "Along the bottom of the walls"),
                   ('CROWN', "Crown", "Along the top of the walls"),
                   ('CHAIR_RAIL', "Chair Rail", "At a fixed height above the floor")],
            default='SKIRTING'),
        "rail_height": FloatProperty(
            name="Rail Height", default=0.9, min=0.0, soft_max=3.0,
            unit='LENGTH', update=_prop_update),
        # fit
        "wall_offset": FloatProperty(
            name="Wall Gap", default=0.0, soft_min=-0.05, soft_max=0.05,
            unit='LENGTH', description="Push the trim away from the wall",
            update=_prop_update),
        "vertical_offset": FloatProperty(
            name="Vertical Offset", default=0.0, soft_min=-0.1, soft_max=0.1,
            unit='LENGTH', update=_prop_update),
        "extend": FloatProperty(
            name="Extend Ends", default=0.0, soft_min=-0.2, soft_max=0.2,
            unit='LENGTH', update=_prop_update),
        "auto_extend": BoolProperty(
            name="Auto Extend", default=False,
            description="Fire a ray from each open end and stretch it until it "
                        "meets whatever is in front: a door casing, a wall, "
                        "another baseboard",
            update=_prop_update),
        "auto_extend_max": FloatProperty(
            name="Search Distance", default=0.15, min=0.001, soft_max=1.0,
            unit='LENGTH',
            description="Give up beyond this distance and leave the end alone",
            update=_prop_update),
        "cap_ends": BoolProperty(name="Cap Ends", default=True, update=_prop_update),
    })
    return d


def _opening_annotations():
    """Everything a door casing and a window casing have in common."""
    d = _common_props()
    d["preset"] = _preset_prop(_preset_update_casing, 'STEPPED', CASING_PRESETS)
    d.update(_edge_props("inner", 'SQUARE', 0.5))
    d.update(_edge_props("outer", 'CHAMFER', 0.4))
    d.update({
        "width": FloatProperty(
            name="Width", default=0.09, min=0.0005, soft_max=0.5,
            unit='LENGTH', update=_prop_update),
        "thickness": FloatProperty(
            name="Thickness", default=0.02, min=0.0005, soft_max=0.2,
            unit='LENGTH', update=_prop_update),
        "reveal": FloatProperty(
            name="Reveal", default=0.005, soft_min=-0.05, soft_max=0.05,
            unit='LENGTH', description="Set the casing back from the opening edge",
            update=_prop_update),
        "both_sides": BoolProperty(
            name="Mirror", default=False,
            description="Add the far half: a matching casing on the other face of the wall",
            update=_prop_update),
        "jamb": BoolProperty(
            name="Jamb Lining", default=False,
            description="Line the inside of the opening", update=_prop_update),
        "jamb_depth": FloatProperty(
            name="Jamb Depth", default=0.12, min=0.001, soft_max=0.6,
            unit='LENGTH', update=_prop_update),
        "jamb_reveal": FloatProperty(
            name="Jamb Thickness", default=0.018, min=0.0005, soft_max=0.1,
            unit='LENGTH', update=_prop_update),
        "cap_ends": BoolProperty(name="Cap Ends", default=True, update=_prop_update),
    })
    return d


def _doorframe_annotations():
    d = _opening_annotations()
    d.update({
        "skip_bottom": BoolProperty(
            name="Skip Floor Run", default=True,
            description="Do not run the casing across the floor",
            update=_prop_update),
    })
    return d


def _windowframe_annotations():
    d = _opening_annotations()
    d.update({
        "sill": BoolProperty(
            name="Window Sill", default=False,
            description="Replace the bottom run with a sill board",
            update=_prop_update),
        "sill_thickness": FloatProperty(
            name="Thickness", default=0.03, min=0.0005, soft_max=0.15,
            unit='LENGTH', update=_prop_update),
        "sill_depth": FloatProperty(
            name="Depth", default=0.05, min=0.0, soft_max=0.5,
            unit='LENGTH', description="How far the sill sticks out of the wall",
            update=_prop_update),
        "sill_inset": FloatProperty(
            name="Inset", default=0.10, min=0.0, soft_max=1.0,
            unit='LENGTH', description="How far the sill runs back into the opening",
            update=_prop_update),
        "sill_overhang": FloatProperty(
            name="Overhang", default=0.04, min=0.0, soft_max=0.4,
            unit='LENGTH', description="How far the sill runs past the opening on each side",
            update=_prop_update),
        "sill_edge": EnumProperty(
            name="Front Edge", items=EDGE_ITEMS, default='CHAMFER', update=_prop_update),
        "sill_edge_size": FloatProperty(
            name="Edge Size", default=0.35, min=0.0, max=1.0, subtype='FACTOR',
            update=_prop_update),
        "sill_edge_segments": IntProperty(
            name="Segments", default=3, min=1, max=32, update=_prop_update),
    })
    return d


class TRIM_PG_baseboard(PropertyGroup):
    __annotations__ = _baseboard_annotations()


class TRIM_PG_doorframe(PropertyGroup):
    __annotations__ = _doorframe_annotations()


class TRIM_PG_windowframe(PropertyGroup):
    __annotations__ = _windowframe_annotations()


class TRIM_PG_scene(PropertyGroup):
    baseboard: PointerProperty(type=TRIM_PG_baseboard)
    doorframe: PointerProperty(type=TRIM_PG_doorframe)
    windowframe: PointerProperty(type=TRIM_PG_windowframe)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def copy_settings(src, dst):
    """Copy every value of one settings group onto another."""
    global _GUARD
    _GUARD = True
    try:
        for prop in src.bl_rna.properties:
            if prop.identifier in {"rna_type", "name"} or prop.is_readonly:
                continue
            setattr(dst, prop.identifier, getattr(src, prop.identifier))
    finally:
        _GUARD = False


def unique_name(base):
    i = 1
    while "%s_%03d" % (base, i) in bpy.data.objects:
        i += 1
    return "%s_%03d" % (base, i)


def get_collection(name):
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(coll)
    elif name not in {c.name for c in bpy.context.scene.collection.children_recursive}:
        try:
            bpy.context.scene.collection.children.link(coll)
        except RuntimeError:
            pass
    return coll


def active_settings(context, kind):
    """Return (settings, target_object) - the object's own settings if the
    active object was made by this add-on, otherwise the scene defaults."""
    obj_prop, scene_prop = KINDS[kind][0], KINDS[kind][1]
    obj = context.active_object
    if obj is not None and obj.get("trim_type") == kind:
        return getattr(obj, obj_prop), obj
    return getattr(context.scene.trim_settings, scene_prop), None


def texture_aspect(mat):
    """width / height of the first image texture of a material, or None."""
    if mat is None or not getattr(mat, "use_nodes", False) or mat.node_tree is None:
        return None
    for node in mat.node_tree.nodes:
        if node.type == 'TEX_IMAGE' and node.image is not None:
            w, h = node.image.size
            if w and h:
                return w / h
    return None


def uv_setup(s, profile, aspect, hidden_last=True):
    """Return (u_scale, v_coords) for one profile.

    The profile loop always starts against the wall, so point 0 -> 1 is the
    hidden face lying on the floor and the last point -> 0 is the hidden back.
    Everything between is what the eye sees, and that is what gets V 0..1.
    """
    plen = tc.profile_lengths(profile)
    if not s.uv_enabled:
        return 1.0, list(plen)
    if s.uv_mode == 'WORLD':
        return s.uv_scale, [x * s.uv_scale for x in plen]

    count = len(profile)
    start = plen[1] if count > 2 else plen[0]
    if count > 2:
        end = plen[count - 1] if hidden_last else plen[count]
    else:
        end = plen[-1]
    span = max(end - start, 1e-6)

    v = [(x - start) / span for x in plen]
    if s.uv_flip_v:
        v = [1.0 - x for x in v]

    tile = s.uv_tile_length
    if s.uv_mode == 'AUTO' and aspect and not s.uv_lock:
        tile = span * aspect
    return s.uv_scale / max(tile, 1e-6), v


def uv_repeat_length(s, profile, aspect):
    """The distance one texture repeat covers, in metres."""
    u_scale, _v = uv_setup(s, profile, aspect)
    return 1.0 / max(u_scale, 1e-9)


def active_profile(s, kind):
    """The cross-section the given settings would produce right now."""
    if kind == 'BASEBOARD':
        return profile_from_settings(s, s.depth, s.height)
    return profile_from_settings(s, s.width, s.thickness)


def profile_from_settings(s, size_a, size_b, flip_a=False, flip_b=False):
    return tc.build_profile(
        size_a, size_b,
        inner=s.inner_edge, inner_size=s.inner_size,
        inner_segments=s.inner_segments, inner_steps=s.inner_steps,
        inner_step_depth=s.inner_step_depth,
        outer=s.outer_edge, outer_size=s.outer_size,
        outer_segments=s.outer_segments, outer_steps=s.outer_steps,
        outer_step_depth=s.outer_step_depth,
        flip_a=flip_a, flip_b=flip_b)


# ---------------------------------------------------------------------------
# Extraction from the edit-mode mesh
# ---------------------------------------------------------------------------

def world_maps(matrix):
    """Return (point_map, normal_map) for a source object matrix.

    Everything is generated in world space: an object scale of, say,
    (2, 1, 1) would otherwise stretch the profile differently on each wall.
    """
    if matrix is None:
        return (lambda co: co.copy()), (lambda n: n.copy())
    nm = matrix.to_3x3().inverted().transposed()
    return (lambda co: matrix @ co), (lambda n: nm @ n)


def extract_wall_runs(bm, placement, tol, matrix=None):
    """Collect the bottom (or top) edges of the selected walls."""
    bm.verts.index_update()
    to_world, to_world_n = world_maps(matrix)

    wco = {}

    def co(v):
        c = wco.get(v.index)
        if c is None:
            c = to_world(v.co)
            wco[v.index] = c
        return c

    def face_normal(f):
        n = to_world_n(f.normal)
        return n.normalized() if n.length > 1e-9 else n

    outward = {}

    sel_faces = [f for f in bm.faces if f.select]
    wall_faces = [f for f in sel_faces if abs(face_normal(f).z) < 0.7]

    if wall_faces:
        for f in wall_faces:
            fn = face_normal(f)
            n = Vector((fn.x, fn.y, 0.0))
            if n.length < 1e-6:
                continue
            n.normalize()
            zs = [co(v).z for v in f.verts]
            target = max(zs) if placement == 'CROWN' else min(zs)
            for e in f.edges:
                v0, v1 = e.verts
                z0, z1 = co(v0).z, co(v1).z
                if abs(z0 - z1) > tol:
                    continue
                if abs(0.5 * (z0 + z1) - target) > tol:
                    continue
                outward[e] = outward.get(e, Vector()) + n
    else:
        for e in bm.edges:
            if not e.select:
                continue
            acc = Vector()
            for f in e.link_faces:
                fn = face_normal(f)
                if abs(fn.z) < 0.7:
                    n = Vector((fn.x, fn.y, 0.0))
                    if n.length > 1e-6:
                        acc += n.normalized()
            if acc.length < 1e-6:
                continue
            outward[e] = acc

    if not outward:
        return []

    seg_out = {}
    segments = []
    for e, n in outward.items():
        a, b = e.verts[0].index, e.verts[1].index
        key = (a, b) if a < b else (b, a)
        seg_out[key] = n.normalized()
        segments.append(key)

    coords = {}
    for e in outward:
        for v in e.verts:
            coords[v.index] = co(v)

    runs = []
    for chain, closed in tc.chain_segments(segments):
        pts = [coords[i] for i in chain]
        outs = []
        n = len(chain)
        count = n if closed else n - 1
        for i in range(count):
            a, b = chain[i], chain[(i + 1) % n]
            key = (a, b) if a < b else (b, a)
            outs.append(seg_out.get(key, Vector((1.0, 0.0, 0.0))))
        runs.append({
            "pts": [list(p) for p in pts],
            "closed": closed,
            "outs": [list(o) for o in outs],
            "normal": [0.0, 0.0, 1.0],
        })
    return runs


def extract_opening_runs(bm, tol, matrix=None):
    """Collect the selected opening outline(s)."""
    bm.verts.index_update()
    to_world, _ = world_maps(matrix)

    segments = []
    coords = {}

    def add(e):
        a, b = e.verts[0].index, e.verts[1].index
        segments.append((a, b) if a < b else (b, a))
        coords[a] = to_world(e.verts[0].co)
        coords[b] = to_world(e.verts[1].co)

    for e in bm.edges:
        if e.select:
            add(e)

    if not segments:
        for f in bm.faces:
            if not f.select:
                continue
            for e in f.edges:
                add(e)

    if not segments:
        return []

    runs = []
    for chain, closed in tc.chain_segments(segments):
        pts = [coords[i] for i in chain]
        n = len(pts)
        if n < 3:
            continue

        # plane normal of the outline (Newell)
        nrm = Vector((0.0, 0.0, 0.0))
        for i in range(n):
            a = pts[i]
            b = pts[(i + 1) % n]
            nrm.x += (a.y - b.y) * (a.z + b.z)
            nrm.y += (a.z - b.z) * (a.x + b.x)
            nrm.z += (a.x - b.x) * (a.y + b.y)
        if nrm.length < 1e-9:
            continue
        nrm.normalize()
        if nrm.z < -0.999:          # keep a deterministic orientation
            nrm = -nrm

        centre = Vector((0.0, 0.0, 0.0))
        for p in pts:
            centre += p
        centre /= n

        outs = []
        count = n if closed else n - 1
        for i in range(count):
            a = pts[i]
            b = pts[(i + 1) % n]
            t = (b - a)
            if t.length < 1e-9:
                outs.append(Vector((1.0, 0.0, 0.0)))
                continue
            t.normalize()
            v = (a + b) * 0.5 - centre
            v = v - nrm * v.dot(nrm)
            v = v - t * v.dot(t)
            if v.length < 1e-9:
                v = t.cross(nrm)
            outs.append(v.normalized())

        runs.append({
            "pts": [list(p) for p in pts],
            "closed": closed,
            "outs": [list(o) for o in outs],
            "normal": list(nrm),
        })
    return runs


# ---------------------------------------------------------------------------
# Mesh building
# ---------------------------------------------------------------------------

def _run_vectors(run):
    pts = [Vector(p) for p in run["pts"]]
    outs = [Vector(o) for o in run["outs"]] or [Vector((1.0, 0.0, 0.0))]
    nrm = Vector(run["normal"])
    return pts, outs, nrm, bool(run["closed"])


def ray_distance(origin, direction, limit, ignore=None):
    """Distance to the first surface in front of a point, 0 if nothing.

    Never raises: if there is no usable context the caller simply gets 0 and
    the end is left where it was.
    """
    try:
        scene = bpy.context.scene
        deps = bpy.context.evaluated_depsgraph_get()
    except Exception:
        return 0.0
    if scene is None or deps is None:
        return 0.0

    eps = 0.0005                      # step off our own end cap first
    start = origin + direction * eps
    try:
        hit, location, _n, _i, obj, _m = scene.ray_cast(
            deps, start, direction, distance=max(limit, 1e-4))
    except Exception:
        return 0.0
    if not hit:
        return 0.0
    if ignore is not None and obj is not None:
        original = getattr(obj, "original", obj)
        if original == ignore:
            return 0.0
    return eps + (location - start).length


def auto_extend_amounts(pts, outs, s, owner):
    """How far each open end should travel to touch what is in front."""
    limit = s.auto_extend_max
    up = Vector((0.0, 0.0, -1.0 if s.placement == 'CROWN' else 1.0))
    flip = -1.0 if s.flip_side else 1.0

    def probe(end_point, direction, out):
        best = 0.0
        for factor in (0.25, 0.5, 0.75):
            origin = (end_point
                      + up * (s.height * factor)
                      + out * (s.depth * 0.5 * flip))
            d = ray_distance(origin, direction, limit, owner)
            if d > 0.0 and (best == 0.0 or d < best):
                best = d
        return best

    first = (pts[0] - pts[1])
    last = (pts[-1] - pts[-2])
    if first.length < 1e-9 or last.length < 1e-9:
        return 0.0, 0.0
    out_first = Vector(outs[0]) if outs else Vector((1.0, 0.0, 0.0))
    out_last = Vector(outs[-1]) if outs else out_first
    return (probe(pts[0], first.normalized(), out_first),
            probe(pts[-1], last.normalized(), out_last))


def _sweeps_baseboard(runs, s, aspect=None, owner=None):
    """Yield (verts, faces, uvs) tuples for a baseboard."""
    profile = profile_from_settings(s, s.depth, s.height, flip_a=s.flip_side)
    u_scale, v_coords = uv_setup(s, profile, aspect)
    for run in runs:
        pts, outs, nrm, closed = _run_vectors(run)

        if s.placement == 'CROWN':
            nrm = -nrm
        elif s.placement == 'CHAIR_RAIL':
            pts = [p + Vector((0.0, 0.0, s.rail_height)) for p in pts]

        if s.refine:
            pts, outs = tc.refine_run(pts, outs, closed, s.refine, s.refine_angle)

        if s.auto_extend and not closed:
            a, b = auto_extend_amounts(pts, outs, s, owner)
            if a or b:
                pts = tc.extend_ends(pts, closed, a, b)

        if s.extend:
            pts = tc.extend_run(pts, closed, s.extend)

        yield tc.sweep_run(
            pts, closed, nrm, outs, profile,
            miter_limit=s.miter_limit,
            offset_a=s.wall_offset,
            offset_b=s.vertical_offset,
            u_scale=u_scale, v_coords=v_coords, cap_ends=s.cap_ends)


def _sill_profile(s):
    """Sill cross-section: a = downwards (away from the opening), b = wall normal."""
    prof = tc.build_profile(
        s.sill_thickness, s.sill_depth + s.sill_inset,
        inner=s.sill_edge, inner_size=s.sill_edge_size,
        inner_segments=s.sill_edge_segments,
        outer=s.sill_edge, outer_size=s.sill_edge_size,
        outer_segments=s.sill_edge_segments)
    # the profile is built from 0; slide it back so it starts inside the opening
    return [(a, b - s.sill_inset) for a, b in prof]


def _sweeps_opening(runs, s, is_window, aspect=None):
    """Yield (verts, faces, uvs) tuples for a door or window casing."""
    casing = profile_from_settings(s, s.width, s.thickness)
    u_scale, v_coords = uv_setup(s, casing, aspect)
    jamb = [(0.0, -s.jamb_depth * 0.5), (0.0, s.jamb_depth * 0.5),
            (-s.jamb_reveal, s.jamb_depth * 0.5), (-s.jamb_reveal, -s.jamb_depth * 0.5)]

    use_sill = is_window and s.sill
    skip_bottom = use_sill if is_window else s.skip_bottom
    tol = max(s.tolerance, 1e-5)

    for run in runs:
        pts, outs, nrm, closed = _run_vectors(run)
        if s.flip_side:
            nrm = -nrm

        if s.refine:
            pts, outs = tc.refine_run(pts, outs, closed, s.refine, s.refine_angle)

        pieces = [(pts, outs, closed)]
        bottoms = []
        if closed and (skip_bottom or use_sill):
            other, bottoms = tc.split_at_bottom(pts, outs, closed, tol)
            if skip_bottom and other:
                pieces = other

        for p, o, cl in pieces:
            sides = [False, True] if s.both_sides else [False]
            for mirrored in sides:
                prof = casing
                if mirrored:
                    prof = [(a, -b) for a, b in casing]
                yield tc.sweep_run(
                    p, cl, nrm, o, prof,
                    miter_limit=s.miter_limit,
                    offset_a=s.reveal, offset_b=0.0,
                    u_scale=u_scale, v_coords=v_coords, cap_ends=s.cap_ends)
            if s.jamb:
                ju, jv = uv_setup(s, jamb, aspect)
                yield tc.sweep_run(
                    p, cl, nrm, o, jamb,
                    miter_limit=s.miter_limit,
                    offset_a=0.0, offset_b=0.0,
                    u_scale=ju, v_coords=jv, cap_ends=s.cap_ends)

        if use_sill:
            sill = _sill_profile(s)
            su, sv = uv_setup(s, sill, aspect)
            for bp, bo, _bc in bottoms:
                bp = tc.extend_run(bp, False, s.sill_overhang)
                yield tc.sweep_run(
                    bp, False, nrm, bo, sill,
                    miter_limit=s.miter_limit,
                    offset_a=0.0, offset_b=0.0,
                    u_scale=su, v_coords=sv, cap_ends=True)


def build_mesh(me, runs, s, kind, owner=None):
    """(Re)build the mesh datablock from the stored runs."""
    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new("UVMap")

    mat = s.material or (me.materials[0] if me.materials else None)
    aspect = texture_aspect(mat)

    if kind == 'BASEBOARD':
        gen = _sweeps_baseboard(runs, s, aspect, owner)
    else:
        gen = _sweeps_opening(runs, s, kind == 'WINDOWFRAME', aspect)

    for verts, faces, face_uvs in gen:
        bverts = [bm.verts.new(v) for v in verts]
        for idx, face in enumerate(faces):
            try:
                f = bm.faces.new([bverts[i] for i in face])
            except ValueError:
                continue
            for loop, uv in zip(f.loops, face_uvs[idx]):
                loop[uv_layer].uv = uv

    bm.verts.index_update()
    bm.faces.index_update()
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])

    smooth = s.shade_smooth
    for f in bm.faces:
        f.smooth = smooth
    if smooth:
        limit = s.smooth_angle
        for e in bm.edges:
            if len(e.link_faces) == 2:
                e.smooth = e.calc_face_angle(0.0) <= limit
            else:
                e.smooth = False

    bm.to_mesh(me)
    bm.free()
    me.update()

    # bm.to_mesh replaces every custom data layer, which leaves the mesh with
    # no UV map flagged for rendering. An Image Texture node with nothing
    # plugged into its Vector input then samples a single texel and the whole
    # trim turns into one flat colour. Put the flags back.
    if me.uv_layers:
        me.uv_layers.active_index = 0
        for i, layer in enumerate(me.uv_layers):
            layer.active_render = (i == 0)

    # and make sure the viewport rebuilds its cached batches, since the mesh
    # was edited from a property callback rather than by an operator
    me.update_tag()
    for ob in bpy.data.objects:
        if ob.data is me:
            ob.update_tag(refresh={'DATA'})

    # material: only touched when one is picked, so a manual assignment survives
    if s.material is not None:
        if not me.materials:
            me.materials.append(s.material)
        elif me.materials[0] is not s.material:
            me.materials[0] = s.material


def rebuild_object(obj):
    kind = obj.get("trim_type")
    raw = obj.get("trim_data")
    if not kind or not raw:
        return False
    if kind not in KINDS:
        return False
    data = json.loads(raw)
    s = getattr(obj, KINDS[kind][0])
    build_mesh(obj.data, data["runs"], s, kind, obj)
    return True


def create_trim_object(context, source, runs, settings, kind):
    obj_prop, _scene_prop, base, coll_name = KINDS[kind]
    name = unique_name(base)
    me = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, me)

    obj["trim_type"] = kind
    obj["trim_source"] = source.name
    obj["trim_data"] = json.dumps({"runs": runs, "space": "WORLD"})

    target = getattr(obj, obj_prop)
    copy_settings(settings, target)

    coll = get_collection(coll_name)
    coll.objects.link(obj)

    # the runs are stored in world space, so the object itself stays at the
    # origin; parenting uses the inverse matrix so it still follows the wall
    if settings.parent_to_source:
        obj.parent = source
        obj.matrix_parent_inverse = source.matrix_world.inverted()
    obj.matrix_basis = Matrix.Identity(4)

    build_mesh(me, runs, target, kind, obj)
    return obj


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class TRIM_OT_create_baseboard(Operator):
    bl_idname = "trim.create_baseboard"
    bl_label = "Create Baseboard"
    bl_description = "Build a mitred baseboard along the selected wall geometry"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        source = context.active_object
        s = context.scene.trim_settings.baseboard

        bm = bmesh.from_edit_mesh(source.data)
        bm.verts.ensure_lookup_table()
        runs = extract_wall_runs(bm, s.placement, max(s.tolerance, 1e-6),
                                 source.matrix_world)

        if not runs:
            self.report({'ERROR'},
                        "Nothing found: select the wall faces, or the bottom edges directly")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')
        obj = create_trim_object(context, source, runs, s, 'BASEBOARD')

        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        self.report({'INFO'}, "Created '%s': %d run(s), %d face(s)"
                    % (obj.name, len(runs), len(obj.data.polygons)))
        return {'FINISHED'}


class TRIM_OT_create_doorframe(Operator):
    bl_idname = "trim.create_doorframe"
    bl_label = "Create Door Frame"
    bl_description = "Build a mitred casing around the selected opening outline"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        source = context.active_object
        s = context.scene.trim_settings.doorframe

        bm = bmesh.from_edit_mesh(source.data)
        bm.verts.ensure_lookup_table()
        runs = extract_opening_runs(bm, max(s.tolerance, 1e-6),
                                    source.matrix_world)

        if not runs:
            self.report({'ERROR'}, "Nothing found: select the edges around the opening")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')
        obj = create_trim_object(context, source, runs, s, 'DOORFRAME')

        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        self.report({'INFO'}, "Created '%s': %d outline(s), %d face(s)"
                    % (obj.name, len(runs), len(obj.data.polygons)))
        return {'FINISHED'}


class TRIM_OT_create_windowframe(Operator):
    bl_idname = "trim.create_windowframe"
    bl_label = "Create Window Frame"
    bl_description = "Build a mitred casing around the selected window outline"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        source = context.active_object
        s = context.scene.trim_settings.windowframe

        bm = bmesh.from_edit_mesh(source.data)
        bm.verts.ensure_lookup_table()
        runs = extract_opening_runs(bm, max(s.tolerance, 1e-6),
                                    source.matrix_world)

        if not runs:
            self.report({'ERROR'}, "Nothing found: select the edges around the window")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')
        obj = create_trim_object(context, source, runs, s, 'WINDOWFRAME')

        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        self.report({'INFO'}, "Created '%s': %d outline(s), %d face(s)"
                    % (obj.name, len(runs), len(obj.data.polygons)))
        return {'FINISHED'}


class TRIM_OT_preset_save(Operator):
    bl_idname = "trim.preset_save"
    bl_label = "Save Preset"
    bl_description = "Save the current settings under a name you choose"
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')
    preset_name: StringProperty(name="Name", default="My Preset")

    def invoke(self, context, event):
        s, _obj = active_settings(context, self.kind)
        if s.user_preset != 'NONE':
            self.preset_name = s.user_preset
        return context.window_manager.invoke_props_dialog(self, width=280)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "preset_name")
        if self.preset_name.strip() in load_presets(self.kind):
            layout.label(text="This will overwrite the existing one", icon='ERROR')

    def execute(self, context):
        name = self.preset_name.strip()
        if not name:
            self.report({'ERROR'}, "Give the preset a name")
            return {'CANCELLED'}

        s, _obj = active_settings(context, self.kind)
        data = load_presets(self.kind)
        data[name] = settings_to_dict(s)
        try:
            write_presets(self.kind, data)
        except OSError as exc:
            self.report({'ERROR'}, "Could not write the preset file: %s" % exc)
            return {'CANCELLED'}

        global _GUARD
        _GUARD = True
        try:
            s.user_preset = name
        except TypeError:
            pass
        finally:
            _GUARD = False

        self.report({'INFO'}, "Saved '%s'" % name)
        return {'FINISHED'}


class TRIM_OT_preset_delete(Operator):
    bl_idname = "trim.preset_delete"
    bl_label = "Delete Preset"
    bl_description = "Delete the selected preset"
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        s, _obj = active_settings(context, self.kind)
        name = s.user_preset
        data = load_presets(self.kind)
        if name == 'NONE' or name not in data:
            self.report({'ERROR'}, "No preset selected")
            return {'CANCELLED'}
        del data[name]
        try:
            write_presets(self.kind, data)
        except OSError as exc:
            self.report({'ERROR'}, "Could not write the preset file: %s" % exc)
            return {'CANCELLED'}

        global _GUARD
        _GUARD = True
        try:
            s.user_preset = 'NONE'
        except TypeError:
            pass
        finally:
            _GUARD = False

        self.report({'INFO'}, "Deleted '%s'" % name)
        return {'FINISHED'}


class TRIM_OT_preset_folder(Operator):
    bl_idname = "trim.preset_folder"
    bl_label = "Open Preset Folder"
    bl_description = "Show the folder holding the preset files"
    bl_options = {'REGISTER'}

    def execute(self, context):
        path = preset_dir()
        try:
            bpy.ops.wm.path_open(filepath=path)
        except Exception:
            self.report({'INFO'}, path)
            return {'FINISHED'}
        self.report({'INFO'}, path)
        return {'FINISHED'}


class TRIM_OT_fix_uv(Operator):
    bl_idname = "trim.fix_uv"
    bl_label = "Fix UV Map"
    bl_description = "Flag the first UV map as the one to render"
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        me = context.active_object.data
        if not me.uv_layers:
            self.report({'ERROR'}, "No UV map on this mesh, rebuild it first")
            return {'CANCELLED'}
        me.uv_layers.active_index = 0
        for i, layer in enumerate(me.uv_layers):
            layer.active_render = (i == 0)
        me.update_tag()
        context.active_object.update_tag(refresh={'DATA'})
        self.report({'INFO'}, "'%s' is now the render UV map" % me.uv_layers[0].name)
        return {'FINISHED'}


class TRIM_OT_lock_uv(Operator):
    bl_idname = "trim.lock_uv"
    bl_label = "Lock Current Repeat"
    bl_description = ("Freeze the repeat length being used right now, so a "
                      "rebuild can never change the mapping again")
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')

    def execute(self, context):
        s, obj = active_settings(context, self.kind)
        mat = s.material
        if mat is None and obj is not None and obj.data.materials:
            mat = obj.data.materials[0]
        length = uv_repeat_length(s, active_profile(s, self.kind),
                                  texture_aspect(mat))
        global _GUARD
        _GUARD = True
        try:
            s.uv_tile_length = length
            s.uv_lock = True
        finally:
            _GUARD = False
        self.report({'INFO'}, "Repeat locked at %.3f m" % length)
        return {'FINISHED'}


class TRIM_OT_rebuild(Operator):
    bl_idname = "trim.rebuild"
    bl_label = "Rebuild"
    bl_description = "Rebuild this trim from its stored path"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get("trim_type"))

    def execute(self, context):
        if rebuild_object(context.active_object):
            return {'FINISHED'}
        self.report({'ERROR'}, "No stored path on this object")
        return {'CANCELLED'}


class TRIM_OT_reset(Operator):
    bl_idname = "trim.reset_settings"
    bl_label = "Reset Settings"
    bl_description = "Restore the default values"
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')

    def execute(self, context):
        s, obj = active_settings(context, self.kind)
        global _GUARD
        _GUARD = True
        try:
            for prop in s.bl_rna.properties:
                if prop.identifier in {"rna_type", "name"} or prop.is_readonly:
                    continue
                s.property_unset(prop.identifier)
        finally:
            _GUARD = False
        if obj is not None and s.live_update:
            rebuild_object(obj)
        return {'FINISHED'}


class TRIM_OT_select_source(Operator):
    bl_idname = "trim.select_source"
    bl_label = "Select Source"
    bl_description = "Make the source object active"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get("trim_source"))

    def execute(self, context):
        src = bpy.data.objects.get(context.active_object.get("trim_source", ""))
        if src is None:
            self.report({'ERROR'}, "Source object not found")
            return {'CANCELLED'}
        for o in context.selected_objects:
            o.select_set(False)
        src.select_set(True)
        context.view_layer.objects.active = src
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

def draw_unwrap_block(layout, context, kind):
    s, obj = active_settings(context, kind)

    if obj is not None and s.uv_enabled:
        me = obj.data
        if not me.uv_layers:
            layout.label(text="This mesh has no UV map", icon='ERROR')
        elif not any(l.active_render for l in me.uv_layers):
            box = layout.box()
            box.label(text="No UV map is flagged for render", icon='ERROR')
            box.operator("trim.fix_uv", text="Fix It").kind = kind

    layout.prop(s, "uv_enabled")

    col = layout.column()
    col.enabled = s.uv_enabled
    col.prop(s, "uv_mode")

    mat = s.material
    if mat is None and obj is not None and obj.data.materials:
        mat = obj.data.materials[0]
    aspect = texture_aspect(mat)

    if s.uv_mode == 'AUTO':
        box = col.box()
        if aspect:
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node.image is not None:
                    w, h = node.image.size
                    box.label(text="%s  %d x %d" % (node.image.name, w, h),
                              icon='TEXTURE')
                    break
            box.label(text="Ratio %.2f : 1, pixels kept square" % aspect)
        else:
            box.label(text="No image texture found", icon='ERROR')
            box.label(text="Using Tile Length instead")

        length = uv_repeat_length(s, active_profile(s, kind), aspect)
        row = box.row()
        row.label(text="Repeat every %.3f m" % length,
                  icon='LOCKED' if s.uv_lock else 'UNLOCKED')
        if s.uv_lock:
            box.prop(s, "uv_lock", text="Locked", toggle=True)
            col.prop(s, "uv_tile_length")
        else:
            op = box.operator("trim.lock_uv", text="Lock This Value",
                              icon='DECORATE_LOCKED')
            op.kind = kind
            box.label(text="Unlocked: changes with the texture")
    elif s.uv_mode == 'TRIM':
        col.prop(s, "uv_tile_length")

    if s.uv_mode == 'WORLD':
        col.prop(s, "uv_scale")
    else:
        col.prop(s, "uv_flip_v")
        col.prop(s, "uv_scale", text="Extra Scale")


def draw_preset_block(layout, s, kind):
    layout.prop(s, "preset")
    row = layout.row(align=True)
    row.prop(s, "user_preset", text="My Presets")
    sub = row.row(align=True)
    sub.operator("trim.preset_save", text="", icon='ADD').kind = kind
    op = sub.operator("trim.preset_delete", text="", icon='REMOVE')
    op.kind = kind
    sub.enabled = True


def draw_edge_block(layout, s, prefix, label):
    col = layout.column(align=True)
    col.prop(s, prefix + "_edge", text=label)
    kind = getattr(s, prefix + "_edge")
    if kind in SHAPED:
        col.prop(s, prefix + "_size")
    if kind in ROUNDED:
        col.prop(s, prefix + "_segments")
    if kind == 'STEPPED':
        col.prop(s, prefix + "_steps")
        col.prop(s, prefix + "_step_depth")


def draw_header_block(layout, context, kind, hint):
    """Object name / live update / source rows shared by both tools."""
    s, obj = active_settings(context, kind)

    row = layout.row(align=True)
    row.label(text=hint, icon='INFO')

    if obj is None:
        layout.label(text="Settings for the next trim", icon='PREFERENCES')
        return s, obj

    row = layout.row(align=True)
    row.prop(obj, "name", text="", icon='OUTLINER_OB_MESH')
    row.prop(s, "live_update", text="", icon='FILE_REFRESH')

    row = layout.row(align=True)
    row.prop(s, "live_update", toggle=True)
    sub = row.row(align=True)
    sub.enabled = not s.live_update
    sub.operator("trim.rebuild", text="Rebuild")

    row = layout.row(align=True)
    row.operator("trim.select_source", text="Source: %s" % obj.get("trim_source", "?"),
                 icon='OBJECT_DATA', emboss=False)
    return s, obj


class VIEW3D_PT_trim_main(Panel):
    bl_label = "plinthes fred"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"

    def draw_header_preset(self, context):
        self.layout.label(text="v%d.%d.%d" % ADDON_VERSION)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Interior:")
        col = layout.column(align=True)
        col.scale_y = 1.15
        col.operator("trim.create_baseboard", icon='MOD_LENGTH')
        col.operator("trim.create_doorframe", icon='MOD_BUILD')
        col.operator("trim.create_windowframe", icon='MOD_LATTICE')
        if context.mode != 'EDIT_MESH':
            layout.label(text="Enter Edit Mode on a wall mesh", icon='INFO')


class VIEW3D_PT_trim_baseboard(Panel):
    bl_label = "Baseboard"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_main"

    def draw_header_preset(self, context):
        op = self.layout.operator("trim.reset_settings", text="", icon='LOOP_BACK',
                                  emboss=False)
        op.kind = 'BASEBOARD'

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        row = layout.row()
        row.scale_y = 1.2
        row.operator("trim.create_baseboard", text="Create Baseboard")
        draw_header_block(layout, context, 'BASEBOARD',
                          "Edit Mode: select wall faces or edges")


class VIEW3D_PT_trim_baseboard_size(Panel):
    bl_label = "Size & Profile"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_baseboard"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s, _ = active_settings(context, 'BASEBOARD')

        draw_preset_block(layout, s, 'BASEBOARD')
        layout.separator()

        col = layout.column(align=True)
        col.prop(s, "height")
        col.prop(s, "depth")
        layout.separator()
        draw_edge_block(layout, s, "inner", "Inner Edge")
        layout.separator()
        draw_edge_block(layout, s, "outer", "Outer Edge")
        layout.separator()
        layout.prop(s, "placement")
        if s.placement == 'CHAIR_RAIL':
            layout.prop(s, "rail_height")
        layout.prop(s, "flip_side")


class VIEW3D_PT_trim_baseboard_fit(Panel):
    bl_label = "Fit"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_baseboard"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'BASEBOARD')
        col = layout.column(align=True)
        col.prop(s, "wall_offset")
        col.prop(s, "vertical_offset")
        col.prop(s, "extend")
        col = layout.column(align=True)
        col.prop(s, "auto_extend")
        sub = col.row()
        sub.enabled = s.auto_extend
        sub.prop(s, "auto_extend_max")
        layout.prop(s, "cap_ends")
        layout.prop(s, "miter_limit")
        col = layout.column(align=True)
        col.prop(s, "refine")
        sub = col.row()
        sub.enabled = s.refine > 0
        sub.prop(s, "refine_angle")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        draw_unwrap_block(layout, context, 'BASEBOARD')


class VIEW3D_PT_trim_baseboard_shading(Panel):
    bl_label = "Shading"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_baseboard"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'BASEBOARD')
        layout.prop(s, "shade_smooth")
        sub = layout.column()
        sub.enabled = s.shade_smooth
        sub.prop(s, "smooth_angle")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'BASEBOARD')
        layout.prop(s, "material")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'BASEBOARD')
        layout.operator("trim.preset_folder", icon='FILE_FOLDER')
        layout.prop(s, "tolerance")
        layout.prop(s, "parent_to_source")


class VIEW3D_PT_trim_doorframe(Panel):
    bl_label = "Door Frame"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_main"

    def draw_header_preset(self, context):
        op = self.layout.operator("trim.reset_settings", text="", icon='LOOP_BACK',
                                  emboss=False)
        op.kind = 'DOORFRAME'

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        row = layout.row()
        row.scale_y = 1.2
        row.operator("trim.create_doorframe", text="Create Door Frame")
        draw_header_block(layout, context, 'DOORFRAME',
                          "One loop, on one face of the wall")


class VIEW3D_PT_trim_doorframe_size(Panel):
    bl_label = "Size & Profile"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_doorframe"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s, _ = active_settings(context, 'DOORFRAME')

        draw_preset_block(layout, s, 'DOORFRAME')
        layout.separator()

        col = layout.column(align=True)
        col.prop(s, "width")
        col.prop(s, "thickness")
        layout.separator()
        draw_edge_block(layout, s, "inner", "Inner Edge")
        layout.separator()
        draw_edge_block(layout, s, "outer", "Outer Edge")
        layout.separator()
        col = layout.column(align=True)
        col.prop(s, "skip_bottom")
        col.prop(s, "flip_side")
        col.prop(s, "both_sides", text="Mirror")


class VIEW3D_PT_trim_doorframe_jamb(Panel):
    bl_label = "Jamb"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_doorframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'DOORFRAME')
        layout.prop(s, "jamb")
        sub = layout.column(align=True)
        sub.enabled = s.jamb
        sub.prop(s, "jamb_depth")
        sub.prop(s, "jamb_reveal")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        draw_unwrap_block(layout, context, 'DOORFRAME')


class VIEW3D_PT_trim_doorframe_shading(Panel):
    bl_label = "Shading"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_doorframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'DOORFRAME')
        layout.prop(s, "shade_smooth")
        sub = layout.column()
        sub.enabled = s.shade_smooth
        sub.prop(s, "smooth_angle")
        layout.prop(s, "cap_ends")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'DOORFRAME')
        layout.prop(s, "material")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'DOORFRAME')
        col = layout.column(align=True)
        col.prop(s, "refine")
        sub = col.row()
        sub.enabled = s.refine > 0
        sub.prop(s, "refine_angle")
        layout.separator()
        layout.prop(s, "reveal")
        layout.prop(s, "tolerance")
        layout.prop(s, "miter_limit")
        layout.prop(s, "parent_to_source")



# --------------------------------------------------------------------- window

class VIEW3D_PT_trim_windowframe(Panel):
    bl_label = "Window Frame"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_main"

    def draw_header_preset(self, context):
        op = self.layout.operator("trim.reset_settings", text="", icon='LOOP_BACK',
                                  emboss=False)
        op.kind = 'WINDOWFRAME'

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        row = layout.row()
        row.scale_y = 1.2
        row.operator("trim.create_windowframe", text="Create Window Frame")
        s, obj = draw_header_block(layout, context, 'WINDOWFRAME',
                                   "One loop, on one face of the wall")
        layout.label(text="Mirror adds the far half", icon='MOD_MIRROR')


class VIEW3D_PT_trim_windowframe_size(Panel):
    bl_label = "Size & Profile"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_windowframe"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s, _ = active_settings(context, 'WINDOWFRAME')

        draw_preset_block(layout, s, 'WINDOWFRAME')
        layout.separator()

        col = layout.column(align=True)
        col.prop(s, "width")
        col.prop(s, "thickness")
        layout.separator()
        draw_edge_block(layout, s, "inner", "Inner Edge")
        layout.separator()
        draw_edge_block(layout, s, "outer", "Outer Edge")
        layout.separator()
        col = layout.column(align=True)
        col.prop(s, "flip_side")
        col.prop(s, "both_sides", text="Mirror")


class VIEW3D_PT_trim_windowframe_sill(Panel):
    bl_label = "Window Sill"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_windowframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        s, _ = active_settings(context, 'WINDOWFRAME')
        self.layout.prop(s, "sill", text="")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s, _ = active_settings(context, 'WINDOWFRAME')

        col = layout.column(align=True)
        col.enabled = s.sill
        col.prop(s, "sill_thickness")
        col.prop(s, "sill_depth")
        col.prop(s, "sill_inset")
        col.prop(s, "sill_overhang")

        col = layout.column(align=True)
        col.enabled = s.sill
        col.prop(s, "sill_edge")
        if s.sill_edge in SHAPED:
            col.prop(s, "sill_edge_size")
        if s.sill_edge in ROUNDED:
            col.prop(s, "sill_edge_segments")

        if not s.sill:
            layout.label(text="Off: the casing runs all around", icon='INFO')


class VIEW3D_PT_trim_windowframe_jamb(Panel):
    bl_label = "Jamb"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_windowframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'WINDOWFRAME')
        layout.prop(s, "jamb")
        sub = layout.column(align=True)
        sub.enabled = s.jamb
        sub.prop(s, "jamb_depth")
        sub.prop(s, "jamb_reveal")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        draw_unwrap_block(layout, context, 'WINDOWFRAME')


class VIEW3D_PT_trim_windowframe_shading(Panel):
    bl_label = "Shading"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_windowframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'WINDOWFRAME')
        layout.prop(s, "shade_smooth")
        sub = layout.column()
        sub.enabled = s.shade_smooth
        sub.prop(s, "smooth_angle")
        layout.prop(s, "cap_ends")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'WINDOWFRAME')
        layout.prop(s, "material")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'WINDOWFRAME')
        col = layout.column(align=True)
        col.prop(s, "refine")
        sub = col.row()
        sub.enabled = s.refine > 0
        sub.prop(s, "refine_angle")
        layout.separator()
        layout.prop(s, "reveal")
        layout.prop(s, "tolerance")
        layout.prop(s, "miter_limit")
        layout.prop(s, "parent_to_source")



# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    TRIM_PG_baseboard,
    TRIM_PG_doorframe,
    TRIM_PG_windowframe,
    TRIM_PG_scene,
    TRIM_OT_create_baseboard,
    TRIM_OT_create_doorframe,
    TRIM_OT_create_windowframe,
    TRIM_OT_preset_save,
    TRIM_OT_preset_delete,
    TRIM_OT_preset_folder,
    TRIM_OT_fix_uv,
    TRIM_OT_lock_uv,
    TRIM_OT_rebuild,
    TRIM_OT_reset,
    TRIM_OT_select_source,
    VIEW3D_PT_trim_main,
    VIEW3D_PT_trim_baseboard,
    VIEW3D_PT_trim_baseboard_size,
    VIEW3D_PT_trim_baseboard_fit,
    VIEW3D_PT_trim_baseboard_shading,
    VIEW3D_PT_trim_doorframe,
    VIEW3D_PT_trim_doorframe_size,
    VIEW3D_PT_trim_doorframe_shading,
    VIEW3D_PT_trim_doorframe_jamb,
    VIEW3D_PT_trim_windowframe,
    VIEW3D_PT_trim_windowframe_size,
    VIEW3D_PT_trim_windowframe_shading,
    VIEW3D_PT_trim_windowframe_sill,
    VIEW3D_PT_trim_windowframe_jamb,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.trim_settings = PointerProperty(type=TRIM_PG_scene)
    bpy.types.Object.trim_baseboard = PointerProperty(type=TRIM_PG_baseboard)
    bpy.types.Object.trim_doorframe = PointerProperty(type=TRIM_PG_doorframe)
    bpy.types.Object.trim_windowframe = PointerProperty(type=TRIM_PG_windowframe)


def unregister():
    del bpy.types.Object.trim_windowframe
    del bpy.types.Object.trim_doorframe
    del bpy.types.Object.trim_baseboard
    del bpy.types.Scene.trim_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
