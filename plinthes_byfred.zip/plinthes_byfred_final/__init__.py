# SPDX-License-Identifier: GPL-3.0-or-later
"""
plinthes_byfred - baseboard / skirting, door and window casing generator.

Workflow
--------
Baseboard : in Edit Mode, select the wall faces (or the bottom edges) of a room
            and press "Create Baseboard".  A mitred, profiled skirting is built
            along the bottom (or the top, for a crown) of the selection.

Door Frame: in Edit Mode, select the outline of an opening and press
            "Create Door Frame".  A mitred casing is built around it, on one or
            both sides of the wall, with an optional jamb lining.

Both generators keep a live link with their settings: change any value and the
mesh is rebuilt instantly.
"""

bl_info = {
    "name": "plinthes fred",
    "author": "byfred",
    "version": (1, 33, 2),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > plinthes fred",
    "description": "Baseboards, crown mouldings and door casings from selected wall geometry",
    "category": "Add Mesh",
}

import json
import math
import os

import bpy
import bmesh
from mathutils import Matrix, Vector
from bpy.props import (BoolProperty, EnumProperty, FloatProperty,
                       FloatVectorProperty, IntProperty, PointerProperty,
                       StringProperty)
from bpy.types import Operator, Panel, PropertyGroup


import sys as _sys

# ===========================================================================
#  Geometry core (kept in this file on purpose: a single-file add-on cannot
#  end up running a stale cached submodule after an in-place upgrade)
# ===========================================================================

# ---------------------------------------------------------------------------
# 2D corner profiles
# ---------------------------------------------------------------------------
#
# All corner shapes are described in a normalised "corner space" (p, q):
#
#       q
#       ^
#   E (0,1) ______
#       |         \
#       |          \   <- the profile curve
#       |           \
#   C (0,0) ---------- S (1,0)  -> p
#
# C is the sharp corner apex, S the start point on the first face and E the
# end point on the second face.  A real point is:
#
#       P = C + p * (S - C) + q * (E - C)
#
# so the same table works whatever the physical size of the cut is.

EDGE_PROFILES = ('SQUARE', 'CHAMFER', 'BULLNOSE', 'COVE', 'OGEE', 'STEPPED')


def _arc(cx, cy, r, a0, a1, segs):
    """Sample an arc, angles in degrees, both ends included."""
    pts = []
    segs = max(1, int(segs))
    for i in range(segs + 1):
        t = i / segs
        a = math.radians(a0 + (a1 - a0) * t)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def corner_points(kind, segments=4, steps=2):
    """Return the corner curve in (p, q) space, from S=(1,0) to E=(0,1)."""
    if kind == 'SQUARE':
        return [(1.0, 0.0), (0.0, 0.0), (0.0, 1.0)]

    if kind == 'CHAMFER':
        return [(1.0, 0.0), (0.0, 1.0)]

    n = max(1, int(segments))

    if kind == 'BULLNOSE':
        # convex round-over: circle centred "inside" the material
        return _arc(1.0, 1.0, 1.0, -90.0, -180.0, n)

    if kind == 'COVE':
        # concave scoop: circle centred on the apex
        return _arc(0.0, 0.0, 1.0, 0.0, 90.0, n)

    if kind == 'OGEE':
        a = _arc(0.5, 0.0, 0.5, 0.0, 90.0, n)
        b = _arc(0.5, 1.0, 0.5, -90.0, -180.0, n)
        return a + b[1:]

    if kind == 'STEPPED':
        m = max(1, int(steps))
        pts = [(1.0, 0.0)]
        for i in range(m):
            p1 = 1.0 - (i + 1) / m
            q0 = i / m
            q1 = (i + 1) / m
            pts.append((p1, q0))
            pts.append((p1, q1))
        return pts

    return [(1.0, 0.0), (0.0, 0.0), (0.0, 1.0)]


def map_corner(pts, corner, start, end):
    """Map (p, q) corner-space points onto a real 2D corner."""
    cx, cy = corner
    ax, ay = start[0] - cx, start[1] - cy
    bx, by = end[0] - cx, end[1] - cy
    return [(cx + p * ax + q * bx, cy + p * ay + q * by) for p, q in pts]


def _dedup(pts, eps=1e-7):
    out = []
    for p in pts:
        if not out or abs(p[0] - out[-1][0]) > eps or abs(p[1] - out[-1][1]) > eps:
            out.append(p)
    # a closed loop must not repeat its first point at the end
    if len(out) > 1 and abs(out[0][0] - out[-1][0]) <= eps and abs(out[0][1] - out[-1][1]) <= eps:
        out.pop()
    return out


def build_profile(size_a, size_b,
                  inner='SQUARE', inner_size=0.5, inner_segments=4,
                  inner_steps=2, inner_step_depth=0.5,
                  outer='CHAMFER', outer_size=0.5, outer_segments=4,
                  outer_steps=2, outer_step_depth=0.5,
                  flip_a=False, flip_b=False):
    """Closed 2D cross-section of a moulding, as a list of (a, b).

    a = 0 sits against the wall (baseboard) or against the opening (casing)
        and grows outwards up to ``size_a``.
    b = 0 sits on the floor (baseboard) or on the wall surface (casing)
        and grows up to ``size_b``.

    The two top corners are the shaped ones:
      * outer corner  = (size_a, size_b)  -> the visible front edge
      * inner corner  = (0, size_b)       -> the edge that dies into the wall
    """
    a = max(float(size_a), 1e-5)
    b = max(float(size_b), 1e-5)

    ref = min(a, b)
    ko = 0.0 if outer == 'SQUARE' else max(0.0, min(float(outer_size), 1.0)) * ref
    ki = 0.0 if inner == 'SQUARE' else max(0.0, min(float(inner_size), 1.0)) * ref

    # how deep the cut bites into the front face (b axis)
    ko_b = min(ko, b * 0.98)
    ki_b = min(ki, b * 0.98)

    # how far it travels along the top face (a axis).  Stepped profiles may
    # reach much further than the thickness, which is what gives a moulding
    # its relief instead of a flat slab.
    ko_a = ko * (max(0.02, float(outer_step_depth)) if outer == 'STEPPED' else 1.0)
    ki_a = ki * (max(0.02, float(inner_step_depth)) if inner == 'STEPPED' else 1.0)

    # the two cuts share the top face, keep a sliver of flat between them
    total = ko_a + ki_a
    if total > a * 0.98:
        f = (a * 0.98) / total if total > 0.0 else 0.0
        ko_a *= f
        ki_a *= f

    pts = [(0.0, 0.0), (a, 0.0)]

    if ko_b > 0.0 and ko_a > 0.0:
        pts += map_corner(corner_points(outer, outer_segments, outer_steps),
                          corner=(a, b), start=(a, b - ko_b), end=(a - ko_a, b))
    else:
        pts.append((a, b))

    if ki_b > 0.0 and ki_a > 0.0:
        pts += map_corner(corner_points(inner, inner_segments, inner_steps),
                          corner=(0.0, b), start=(ki_a, b), end=(0.0, b - ki_b))
    else:
        pts.append((0.0, b))

    pts = _dedup(pts)

    if flip_a:
        pts = [(-p, q) for p, q in pts]
    if flip_b:
        pts = [(p, -q) for p, q in pts]
    return pts


def profile_lengths(profile):
    """Cumulative perimeter of a closed profile, len = len(profile) + 1."""
    out = [0.0]
    n = len(profile)
    for i in range(n):
        x0, y0 = profile[i]
        x1, y1 = profile[(i + 1) % n]
        out.append(out[-1] + math.hypot(x1 - x0, y1 - y0))
    return out


# ---------------------------------------------------------------------------
# Edge chaining
# ---------------------------------------------------------------------------

def chain_segments(segments):
    """Turn a soup of (a, b) index pairs into runs.

    Returns a list of ``(vertex_keys, closed)`` tuples.  Open runs come first,
    then closed loops.  Junctions with more than two edges simply split runs.
    """
    adj = {}
    edges = set()
    for a, b in segments:
        if a == b:
            continue
        key = (a, b) if a < b else (b, a)
        if key in edges:
            continue
        edges.add(key)
        adj.setdefault(a, []).append(b)
        adj.setdefault(b, []).append(a)

    used = set()
    runs = []

    def ekey(a, b):
        return (a, b) if a < b else (b, a)

    def walk(start, first):
        chain = [start, first]
        used.add(ekey(start, first))
        cur = first
        while True:
            if len(adj.get(cur, ())) != 2:
                break
            nxt = None
            for cand in adj[cur]:
                if ekey(cur, cand) not in used:
                    nxt = cand
                    break
            if nxt is None:
                break
            used.add(ekey(cur, nxt))
            chain.append(nxt)
            cur = nxt
            if cur == start:
                break
        return chain

    # open runs, starting from every endpoint / junction
    for v in sorted(k for k, n in adj.items() if len(n) != 2):
        for nb in list(adj[v]):
            if ekey(v, nb) in used:
                continue
            runs.append((walk(v, nb), False))

    # whatever is left is made of closed loops
    for a, b in sorted(edges):
        if (a, b) in used:
            continue
        chain = walk(a, b)
        closed = len(chain) > 2 and chain[0] == chain[-1]
        if closed:
            chain = chain[:-1]
        runs.append((chain, closed))

    return [(c, cl) for c, cl in runs if len(c) >= 2]


# ---------------------------------------------------------------------------
# Sweeping
# ---------------------------------------------------------------------------

def _v(x):
    return Vector(x) if Vector is not None else x


def run_frames(points, closed, normal, outs, miter_limit=8.0):
    """Per-point mitre vectors.

    ``normal``  the plane normal of the run (profile "b" axis)
    ``outs``    one desired outward direction per segment (profile "a" axis)

    Returns ``(mitres, scales, sign, lengths)``.
    """
    N = normal.normalized()
    n = len(points)
    nseg = n if closed else n - 1

    tangents = []
    for i in range(nseg):
        t = points[(i + 1) % n] - points[i]
        if t.length < 1e-9:
            t = Vector((1.0, 0.0, 0.0))
        tangents.append(t.normalized())

    # which way round does (t x N) have to be flipped so it matches `outs`?
    vote = 0.0
    for i, t in enumerate(tangents):
        s = t.cross(N)
        if s.length < 1e-9:
            continue
        o = outs[i] if i < len(outs) else outs[-1]
        vote += s.normalized().dot(o)
    sign = -1.0 if vote < 0.0 else 1.0

    sides = []
    for t in tangents:
        s = t.cross(N)
        if s.length < 1e-9:
            s = Vector((1.0, 0.0, 0.0))
        sides.append(s.normalized() * sign)

    mitres, scales = [], []
    for i in range(n):
        if closed:
            s_prev = sides[i - 1]
            s_next = sides[i % nseg]
        else:
            s_prev = sides[i - 1] if i > 0 else sides[0]
            s_next = sides[i] if i < nseg else sides[-1]
        m = s_prev + s_next
        if m.length < 1e-6:
            mitres.append(s_next.copy())
            scales.append(1.0)
        else:
            m.normalize()
            d = m.dot(s_next)
            scales.append(1.0 / max(d, 1.0 / max(1.0, miter_limit)))
            mitres.append(m)

    lengths = [0.0]
    for i in range(nseg):
        lengths.append(lengths[-1] + (points[(i + 1) % n] - points[i]).length)

    return mitres, scales, sign, lengths


def sweep_run(points, closed, normal, outs, profile,
              miter_limit=8.0, offset_a=0.0, offset_b=0.0,
              uv_scale=1.0, u_scale=None, v_coords=None, cap_ends=True,
              seg_u=None):
    """Sweep a closed 2D profile along a planar polyline.

    ``u_scale``   multiplier applied to the distance along the path.
    ``v_coords``  explicit V per profile point (len == len(profile) + 1).
                  Defaults to the profile perimeter in metres.
    ``seg_u``     explicit (u_start, u_end) in metres for every segment,
                  see segment_u_ranges. Defaults to the distance along the path.

    Returns ``(verts, faces, face_uvs)`` where faces index into verts and
    face_uvs holds one (u, v) per face corner.
    """
    N = normal.normalized()
    n = len(points)
    mitres, scales, _sign, lengths = run_frames(points, closed, N, outs, miter_limit)
    plen = profile_lengths(profile)

    if u_scale is None:
        u_scale = uv_scale
    if v_coords is None:
        v_coords = [x * uv_scale for x in plen]

    verts = []
    rings = []
    for i in range(n):
        ring = []
        for (a, b) in profile:
            p = (points[i]
                 + mitres[i] * ((a + offset_a) * scales[i])
                 + N * (b + offset_b))
            ring.append(len(verts))
            verts.append(p)
        rings.append(ring)

    faces, face_uvs = [], []
    P = len(profile)
    nseg = n if closed else n - 1
    for i in range(nseg):
        r0 = rings[i]
        r1 = rings[(i + 1) % n]
        if seg_u is not None and i < len(seg_u):
            u0 = seg_u[i][0] * u_scale
            u1 = seg_u[i][1] * u_scale
        else:
            u0 = lengths[i] * u_scale
            u1 = lengths[i + 1] * u_scale
        for j in range(P):
            k = (j + 1) % P
            v0 = v_coords[j]
            v1 = v_coords[j + 1]
            faces.append((r0[j], r0[k], r1[k], r1[j]))
            face_uvs.append(((u0, v0), (u0, v1), (u1, v1), (u1, v0)))

    if cap_ends and not closed and n >= 2:
        caps = [(a * u_scale, b * u_scale) for a, b in profile]
        faces.append(tuple(reversed(rings[0])))
        face_uvs.append(tuple(reversed(caps)))
        faces.append(tuple(rings[-1]))
        face_uvs.append(tuple(caps))

    return verts, faces, face_uvs


# ---------------------------------------------------------------------------
# Path post-processing
# ---------------------------------------------------------------------------

def _mitre(vecs, i, n, nseg, closed, miter_limit):
    """Mitre direction and stretch at vertex i for per-segment directions."""
    if closed:
        prev, nxt = vecs[(i - 1) % nseg], vecs[i % nseg]
    else:
        prev = vecs[i - 1] if i > 0 else vecs[0]
        nxt = vecs[i] if i < nseg else vecs[-1]
    m = prev + nxt
    if m.length < 1e-6:
        return nxt.copy(), 1.0
    m.normalize()
    d = m.dot(nxt)
    return m, 1.0 / max(d, 1.0 / max(1.0, miter_limit))


def sweep_framed(points, closed, a_dirs, b_dirs, profile, miter_limit=8.0,
                 offset_a=0.0, offset_b=0.0, u_scale=1.0, v_coords=None,
                 cap_ends=True):
    """Sweep a profile whose two axes are given per segment.

    Unlike sweep_run the profile plane is not tied to one fixed normal, so a
    single moulding can run along the floor, turn up the leg of a door with
    a 45 degree mitre, cross the head and come back down - and also turn the
    room corners.  Profile point (a, b): a goes along ``b_dirs`` (out of the
    wall), b along ``a_dirs`` (up on the floor, away from the opening on a
    door).  U is the distance along the whole path, so the texture follows.
    """
    n = len(points)
    nseg = n if closed else n - 1
    lengths = [0.0]
    for i in range(nseg):
        lengths.append(lengths[-1] + (points[(i + 1) % n] - points[i]).length)
    if v_coords is None:
        v_coords = profile_lengths(profile)

    verts, rings = [], []
    for i in range(n):
        Am, sa = _mitre(a_dirs, i, n, nseg, closed, miter_limit)
        Bm, sb = _mitre(b_dirs, i, n, nseg, closed, miter_limit)
        ring = []
        for (pa, pb) in profile:
            ring.append(len(verts))
            verts.append(points[i] + Bm * ((pa + offset_a) * sb)
                         + Am * ((pb + offset_b) * sa))
        rings.append(ring)

    faces, face_uvs = [], []
    P = len(profile)
    for i in range(nseg):
        r0, r1 = rings[i], rings[(i + 1) % n]
        u0, u1 = lengths[i] * u_scale, lengths[i + 1] * u_scale
        for j in range(P):
            k = (j + 1) % P
            faces.append((r0[j], r0[k], r1[k], r1[j]))
            face_uvs.append(((u0, v_coords[j]), (u0, v_coords[j + 1]),
                             (u1, v_coords[j + 1]), (u1, v_coords[j])))
    if cap_ends and not closed and n >= 2:
        caps = [(a * u_scale, b * u_scale) for a, b in profile]
        faces.append(tuple(reversed(rings[0])))
        face_uvs.append(tuple(reversed(caps)))
        faces.append(tuple(rings[-1]))
        face_uvs.append(tuple(caps))
    return verts, faces, face_uvs


def _canon_dir(v):
    """Unit horizontal direction, always pointing the same way along a wall
    (+X first, then +Y), whatever way the path happens to run."""
    v = Vector((v.x, v.y, 0.0))
    if v.length < 1e-12:
        return None
    v.normalize()
    if v.x < -1e-6 or (abs(v.x) <= 1e-6 and v.y < 0.0):
        v = -v
    return v


def segment_u_ranges(points, closed, outs, edge_off=0.0):
    """World-anchored U (metres) for every segment of a run.

    * Horizontal pieces read U straight off the wall line, so two pieces of
      the same wall (one each side of a door) carry on the same grain, as if
      they were cut from one board.
    * Upright pieces (the legs of a door casing) start, at floor level, from
      the U the wall line has at the casing's outer edge, which is where the
      baseboard butts against it, then climb with the height. The wood runs
      from the baseboard straight up the leg.
    ``edge_off`` = distance from the path to the trim's outer edge.
    """
    n = len(points)
    nseg = n if closed else n - 1
    if nseg < 1:
        return []
    zref = min(p.z for p in points)
    res = []
    for i in range(nseg):
        A = points[i]
        B = points[(i + 1) % n]
        d = B - A
        horiz = Vector((d.x, d.y, 0.0))
        if horiz.length >= abs(d.z):
            c = _canon_dir(horiz)
            if c is None:
                res.append((0.0, 0.0))
            else:
                res.append((A.dot(c), B.dot(c)))
            continue
        o = outs[i] if i < len(outs) else outs[-1]
        c = _canon_dir(o)
        if c is None:
            res.append((A.z - zref, B.z - zref))
            continue
        oh = Vector((o.x, o.y, 0.0)).normalized()
        base = (A + oh * edge_off).dot(c)
        res.append((base + A.z - zref, base + B.z - zref))
    return res


def _turn_angle(prev, cur, nxt):
    """Angle between the incoming and outgoing direction at a vertex."""
    t0 = cur - prev
    t1 = nxt - cur
    if t0.length < 1e-9 or t1.length < 1e-9:
        return 0.0
    d = max(-1.0, min(1.0, t0.normalized().dot(t1.normalized())))
    return math.acos(d)


def _catmull(p0, p1, p2, p3, t, alpha=0.5):
    """Centripetal Catmull-Rom: follows an arc closely, never overshoots."""
    def knot(ti, pa, pb):
        d = (pb - pa).length
        return ti + (d ** alpha if d > 1e-12 else 1e-12)

    t0 = 0.0
    t1 = knot(t0, p0, p1)
    t2 = knot(t1, p1, p2)
    t3 = knot(t2, p2, p3)
    tt = t1 + (t2 - t1) * t

    def lerp(pa, pb, ta, tb):
        if abs(tb - ta) < 1e-12:
            return pa.copy()
        f = (tt - ta) / (tb - ta)
        return pa * (1.0 - f) + pb * f

    a1 = lerp(p0, p1, t0, t1)
    a2 = lerp(p1, p2, t1, t2)
    a3 = lerp(p2, p3, t2, t3)
    b1 = lerp(a1, a2, t0, t2)
    b2 = lerp(a2, a3, t1, t3)
    return lerp(b1, b2, t1, t2)


def refine_run(points, outs, closed, subdiv, max_angle):
    """Subdivide the curved parts of a run, leaving corners untouched.

    A low-poly arch (an arched doorway modelled with 4 or 6 facets) becomes a
    smooth curve, while square corners and straight walls are left exactly as
    they are.
    """
    n = len(points)
    nseg = n if closed else n - 1
    subdiv = int(subdiv)
    if subdiv < 1 or nseg < 2:
        return points, outs

    smooth = []
    for i in range(n):
        if not closed and (i == 0 or i == n - 1):
            smooth.append(False)
            continue
        ang = _turn_angle(points[i - 1], points[i], points[(i + 1) % n])
        smooth.append(1e-4 < ang <= max_angle)

    new_pts = []
    new_outs = []
    for i in range(nseg):
        p1 = points[i]
        p2 = points[(i + 1) % n]
        o = outs[i] if i < len(outs) else outs[-1]
        new_pts.append(p1)

        if smooth[i] or smooth[(i + 1) % n]:
            p0 = points[i - 1] if (closed or i > 0) else p1 + (p1 - p2)
            p3 = points[(i + 2) % n] if (closed or i + 2 < n) else p2 + (p2 - p1)
            for k in range(1, subdiv + 1):
                new_pts.append(_catmull(p0, p1, p2, p3, k / (subdiv + 1.0)))
            new_outs.extend([o] * (subdiv + 1))
        else:
            new_outs.append(o)

    if not closed:
        new_pts.append(points[-1])
    return new_pts, new_outs


def extend_ends(points, closed, start_amount, end_amount):
    """Push each open end of a run outwards by its own amount."""
    if closed or len(points) < 2:
        return points
    pts = [p.copy() for p in points]
    if start_amount:
        t = pts[0] - pts[1]
        if t.length > 1e-9:
            pts[0] = pts[0] + t.normalized() * start_amount
    if end_amount:
        t = pts[-1] - pts[-2]
        if t.length > 1e-9:
            pts[-1] = pts[-1] + t.normalized() * end_amount
    return pts


def extend_run(points, closed, amount):
    """Push the two open ends of a run further along their tangents."""
    if closed or amount == 0.0 or len(points) < 2:
        return points
    pts = [p.copy() for p in points]
    t0 = (pts[0] - pts[1])
    if t0.length > 1e-9:
        pts[0] = pts[0] + t0.normalized() * amount
    t1 = (pts[-1] - pts[-2])
    if t1.length > 1e-9:
        pts[-1] = pts[-1] + t1.normalized() * amount
    return pts


def _runs_from_segments(points, outs, seg_ids, n, nseg, closed):
    """Group consecutive segment ids into open runs."""
    groups = []
    cur = [seg_ids[0]]
    for i in seg_ids[1:]:
        if i == cur[-1] + 1:
            cur.append(i)
        else:
            groups.append(cur)
            cur = [i]
    groups.append(cur)

    # a closed loop can wrap around index 0
    if closed and len(groups) > 1 and groups[0][0] == 0 and groups[-1][-1] == nseg - 1:
        groups[0] = groups[-1] + groups[0]
        groups.pop()

    runs = []
    for g in groups:
        pts = [points[g[0]]]
        os_ = []
        for i in g:
            pts.append(points[(i + 1) % n])
            os_.append(outs[i] if i < len(outs) else outs[-1])
        runs.append((pts, os_, False))
    return runs


def split_at_bottom(points, outs, closed, tol=1e-4):
    """Split a loop into (everything else, the horizontal runs at the lowest Z).

    The door tool throws the bottom away; the window tool turns it into a sill.
    """
    n = len(points)
    nseg = n if closed else n - 1
    if nseg < 2:
        return [(points, outs, closed)], []

    zmin = min(p.z for p in points)
    drop = []
    for i in range(nseg):
        a = points[i]
        b = points[(i + 1) % n]
        if abs(a.z - b.z) <= tol and abs(0.5 * (a.z + b.z) - zmin) <= tol:
            drop.append(i)

    if not drop:
        return [(points, outs, closed)], []

    keep = [i for i in range(nseg) if i not in drop]
    other = _runs_from_segments(points, outs, keep, n, nseg, closed) if keep else []
    bottom = _runs_from_segments(points, outs, drop, n, nseg, closed)
    return other, bottom


def split_bottom(points, outs, closed, tol=1e-4):
    """Drop the horizontal segments sitting at the lowest Z of a closed loop."""
    other, _ = split_at_bottom(points, outs, closed, tol)
    return other if other else [(points, outs, closed)]


# ---------------------------------------------------------------------------
# Wainscoting (lambris)
# ---------------------------------------------------------------------------

def _box_uvs(locs, u_scale):
    """UVs for one quad from local (t, a, z) coords: drop the flattest axis."""
    spans = []
    for k in range(3):
        vals = [p[k] for p in locs]
        spans.append(max(vals) - min(vals))
    drop = spans.index(min(spans))
    keep = [k for k in range(3) if k != drop]
    return tuple((p[keep[0]] * u_scale, p[keep[1]] * u_scale) for p in locs)


# corner order: back face (b0..b3) then front face (f0..f3),
# each going (t0,z0) (t1,z0) (t1,z1) (t0,z1)
_BOX_FACES = ((0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
              (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7))


def _box(corners, locs, u_scale):
    faces = list(_BOX_FACES)
    uvs = [_box_uvs([locs[i] for i in f], u_scale) for f in faces]
    return list(corners), faces, uvs


def wainscot_layout(L, w, panel_w, alternate=False, ratio=2.0, min_panel=0.05):
    """Stile/panel positions along one wall segment of length ``L``.

    Returns a list of ``(t0, t1)`` panel openings.  Stiles fill the gaps,
    including one at each end.  An empty list means the segment is too short
    for a panel and is one solid stile.
    """
    if L < 2.0 * w + min_panel:
        return []
    raw = (L - w) / max(panel_w + w, 1e-6)
    n = max(1, int(round(raw)))
    step = 2 if alternate else 1
    if alternate and n % 2 == 0:
        n = n + 1 if raw > n else max(1, n - 1)

    while True:
        weights = [(ratio if (alternate and j % 2) else 1.0) for j in range(n)]
        avail = L - (n + 1) * w
        unit = avail / sum(weights)
        if n <= 1 or min(weights) * unit >= min_panel:
            break
        n = max(1, n - step)
    if avail <= 0.0:
        return []

    out = []
    t = w
    for wt in weights:
        p = wt * unit
        out.append((t, t + p))
        t += p + w
    return out


def wainscot_parts(points, closed, normal, outs, p):
    """Every piece of a wainscot band along one run.

    ``p`` is a dict:
        f           +1 or -1 (flip side)
        a0          wall gap
        backer      board thickness against the wall
        frame_w     stile / rail width
        frame_d     how far stiles and rails stand proud of the board
        panel_w     target panel width
        alternate   narrow/wide panels
        ratio       wide panel = ratio x narrow panel
        base_top    top of the baseboard (bottom rail starts there)
        top         total wainscot height
        cap_h       cap rail height
        cap_profile cap rail cross-section (already flipped), or None
        raise_d     raised panel thickness (0 = flat recessed panel)
        bevel       raised panel bevel width
        u_scale     metres -> UV
    Returns a list of (verts, faces, face_uvs).
    """
    N = normal.normalized()
    n = len(points)
    nseg = n if closed else n - 1
    if nseg < 1:
        return []
    mitres, scales, sign, lengths = run_frames(points, closed, N, outs)

    f = p["f"]
    a0 = p["a0"]
    us = p["u_scale"]
    cap_h = p["cap_h"] if p["cap_profile"] else 0.0
    cap_bot = p["top"] - cap_h
    rail_lo = (p["base_top"], p["base_top"] + p["frame_w"])
    rail_hi = (cap_bot - p["frame_w"], cap_bot)
    a_board = (0.0, p["backer"])
    a_frame = (p["backer"], p["backer"] + p["frame_d"])

    def rect(a_rng, b_rng):
        a1, a2 = a_rng[0] * f + a0, a_rng[1] * f + a0
        return [(a1, b_rng[0]), (a2, b_rng[0]), (a2, b_rng[1]), (a1, b_rng[1])]

    def sweep(profile, offset_b=0.0):
        plen = profile_lengths(profile)
        return sweep_run(points, closed, N, outs, profile,
                         offset_b=offset_b, u_scale=us,
                         v_coords=[x * us for x in plen], cap_ends=True)

    parts = []
    if cap_bot > 1e-4:
        parts.append(sweep(rect(a_board, (0.0, cap_bot))))
    if p["cap_profile"]:
        prof = [(a + a0, b) for a, b in p["cap_profile"]]
        parts.append(sweep(prof, offset_b=cap_bot))

    z_lo, z_hi = rail_lo[1], rail_hi[0]
    if p["frame_d"] <= 0.0 or z_hi - z_lo < 1e-3:
        return parts              # no room for a frame: plain board + cap

    parts.append(sweep(rect(a_frame, rail_lo)))
    parts.append(sweep(rect(a_frame, rail_hi)))

    def pos(i, t, a, z):
        """Point on segment i at distance t, depth a, height z."""
        A = points[i]
        B = points[(i + 1) % n]
        L = (B - A).length
        if t <= 1e-9:
            base = A + mitres[i] * (a * scales[i])
        elif t >= L - 1e-9:
            j = (i + 1) % n
            base = B + mitres[j] * (a * scales[j])
        else:
            d = (B - A) / L
            side = d.cross(N).normalized() * sign
            base = A + d * t + side * a
        return base + N * z

    def block(i, t0, t1, a_rng, z0, z1, inset=0.0):
        """A box (or a bevelled slab when ``inset`` > 0) on segment i."""
        aa = [a_rng[0] * f + a0, a_rng[1] * f + a0]
        corners, locs = [], []
        for k, a in enumerate(aa):
            ins = inset if k == 1 else 0.0
            for (t, z) in ((t0 + ins, z0 + ins), (t1 - ins, z0 + ins),
                           (t1 - ins, z1 - ins), (t0 + ins, z1 - ins)):
                corners.append(pos(i, t, a, z))
                locs.append((lengths[i] + t, a, z))
        return _box(corners, locs, us)

    w = p["frame_w"]
    for i in range(nseg):
        L = lengths[i + 1] - lengths[i]
        if L < 1e-6:
            continue
        openings = wainscot_layout(L, w, p["panel_w"], p["alternate"], p["ratio"])
        if not openings:
            parts.append(block(i, 0.0, L, a_frame, z_lo, z_hi))
            continue
        edges = [0.0]
        for t0, t1 in openings:
            edges += [t0, t1]
        edges.append(L)
        for k in range(0, len(edges), 2):
            parts.append(block(i, edges[k], edges[k + 1], a_frame, z_lo, z_hi))
        if p["raise_d"] > 0.0:
            for t0, t1 in openings:
                bev = max(0.0, min(p["bevel"], 0.45 * (t1 - t0), 0.45 * (z_hi - z_lo)))
                parts.append(block(i, t0, t1, (p["backer"], p["backer"] + p["raise_d"]),
                                   z_lo, z_hi, inset=bev))
    return parts


tc = _sys.modules[__name__]

# ===========================================================================
#  Blender integration
# ===========================================================================

# Blender removes bl_info from the module namespace when the add-on is installed
# as an extension, so the version is kept in a plain constant as well.
ADDON_VERSION = (1, 33, 2)

BASEBOARD_COLL = "trim_baseboards"
DOORFRAME_COLL = "trim_doorframes"
WINDOW_COLL = "trim_windows"
COLLISION_COLL = "trim_collision"

# kind -> (object property, scene property, object name base, collection)
KINDS = {
    'BASEBOARD': ("trim_baseboard", "baseboard", "baseboard", BASEBOARD_COLL),
    'DOORFRAME': ("trim_doorframe", "doorframe", "doorframe", DOORFRAME_COLL),
    'WINDOWFRAME': ("trim_windowframe", "windowframe", "windowframe", WINDOW_COLL),
}

_GUARD = False  # blocks re-entrant rebuilds while properties are copied


# ---------------------------------------------------------------------------
# Property groups
# ---------------------------------------------------------------------------

LANG_ITEMS = [
    ('AUTO', "Auto", "Follow Blender's interface language"),
    ('EN', "English", ""),
    ('FR', "Français", ""),
    ('ES', "Español", ""),
]


def _language_update_cb(self, context):
    _language_update(self, context)


EDGE_ITEMS = [
    ('SQUARE', "Square", "Keep the corner sharp"),
    ('CHAMFER', "Chamfer", "Straight bevel"),
    ('BULLNOSE', "Bullnose", "Convex round-over"),
    ('COVE', "Cove", "Concave scoop"),
    ('OGEE', "Ogee", "Classic S-curve"),
    ('STEPPED', "Stepped", "Stair-stepped profile"),
]

SHAPED = {'CHAMFER', 'BULLNOSE', 'COVE', 'OGEE', 'STEPPED'}
ROUNDED = {'BULLNOSE', 'COVE', 'OGEE'}

def _prop_update(self, context):
    """Live update callback shared by every setting."""
    if _GUARD:
        return
    obj = self.id_data
    if not isinstance(obj, bpy.types.Object):
        return
    if not obj.get("trim_type"):
        return
    if not self.live_update:
        return
    try:
        rebuild_object(obj)
    except Exception as exc:  # never let a UI edit raise
        print("[plinthes fred] rebuild failed:", exc)


def _library_texture_update(self, context):
    """Update callback for the Library Texture picker.

    Only touches the material (creating the Sollumz shader material the
    first time, or just swapping the image afterwards) - it never rebuilds
    the geometry, so picking a texture can't move or resize anything.
    """
    if _GUARD:
        return
    obj = self.id_data
    if not isinstance(obj, bpy.types.Object) or not obj.get("trim_type"):
        return
    try:
        apply_library_texture(obj, self)
    except Exception as exc:  # never let a UI edit raise
        print("[plinthes fred] Library Texture update failed:", exc)


BASEBOARD_PRESETS = {
    'FLAT': dict(height=0.10, depth=0.015,
                 inner_edge='SQUARE', outer_edge='SQUARE'),
    'CHAMFER': dict(height=0.10, depth=0.018,
                    inner_edge='SQUARE',
                    outer_edge='CHAMFER', outer_size=0.5),
    'BULLNOSE': dict(height=0.12, depth=0.018,
                     inner_edge='SQUARE',
                     outer_edge='BULLNOSE', outer_size=1.0, outer_segments=6),
    'COVE': dict(height=0.12, depth=0.020,
                 inner_edge='SQUARE',
                 outer_edge='COVE', outer_size=0.9, outer_segments=6),
    'OGEE': dict(height=0.14, depth=0.020,
                 inner_edge='COVE', inner_size=0.3, inner_segments=4,
                 outer_edge='OGEE', outer_size=1.0, outer_segments=8),
    'STEPPED': dict(height=0.14, depth=0.022,
                    inner_edge='SQUARE',
                    outer_edge='STEPPED', outer_size=0.95, outer_steps=3,
                    outer_step_depth=1.8),
    'COLONIAL': dict(height=0.16, depth=0.022,
                     inner_edge='STEPPED', inner_size=0.5, inner_steps=1,
                     inner_step_depth=1.2,
                     outer_edge='OGEE', outer_size=1.0, outer_segments=8),
    'VICTORIAN': dict(height=0.19, depth=0.025,
                      inner_edge='COVE', inner_size=0.45, inner_segments=5,
                      outer_edge='STEPPED', outer_size=1.0, outer_steps=4,
                      outer_step_depth=2.2),
}

CASING_PRESETS = {
    'FLAT': dict(width=0.09, thickness=0.018,
                 inner_edge='SQUARE', outer_edge='SQUARE'),
    'CHAMFER': dict(width=0.09, thickness=0.020,
                    inner_edge='SQUARE',
                    outer_edge='CHAMFER', outer_size=0.5),
    'STEPPED': dict(width=0.109, thickness=0.029,
                    inner_edge='STEPPED', inner_size=0.62, inner_steps=1,
                    inner_step_depth=0.74,
                    outer_edge='CHAMFER', outer_size=0.5),
    'MOLDED': dict(width=0.115, thickness=0.030,
                   inner_edge='STEPPED', inner_size=0.6, inner_steps=2,
                   inner_step_depth=1.3,
                   outer_edge='OGEE', outer_size=0.9, outer_segments=8),
    'BULLNOSE': dict(width=0.09, thickness=0.025,
                     inner_edge='SQUARE',
                     outer_edge='BULLNOSE', outer_size=1.0, outer_segments=6),
    'CRAFTSMAN': dict(width=0.14, thickness=0.025,
                      inner_edge='SQUARE',
                      outer_edge='STEPPED', outer_size=0.95, outer_steps=2,
                      outer_step_depth=1.6),
    'VICTORIAN': dict(width=0.13, thickness=0.034,
                      inner_edge='COVE', inner_size=0.5, inner_segments=5,
                      outer_edge='STEPPED', outer_size=1.0, outer_steps=3,
                      outer_step_depth=2.0),
}

PRESET_ITEMS = [
    ('FLAT', "Flat Slab", "Plain rectangular board, no relief"),
    ('CHAMFER', "Chamfered", "Simple bevel on the front edge"),
    ('BULLNOSE', "Bullnose", "Rounded front edge"),
    ('COVE', "Cove", "Concave scoop"),
    ('OGEE', "Ogee", "Classic S-curve moulding"),
    ('STEPPED', "Stepped", "Stair-stepped moulding"),
    ('MOLDED', "Molded", "Steps at the opening plus an ogee outside"),
    ('CRAFTSMAN', "Craftsman", "Wide flat board with a stepped outer edge"),
    ('COLONIAL', "Colonial", "Stepped back, ogee front"),
    ('VICTORIAN', "Victorian", "Tall, deeply moulded"),
]


# ---------------------------------------------------------------------------
# User presets, saved as plain JSON next to Blender's own config
# ---------------------------------------------------------------------------

PRESET_SKIP = {"rna_type", "name", "live_update", "user_preset", "preset"}

# Blender needs the enum item strings to stay alive, so they are cached here
_ENUM_CACHE = {}

PG_KIND = {
    "TRIM_PG_baseboard": 'BASEBOARD',
    "TRIM_PG_doorframe": 'DOORFRAME',
    "TRIM_PG_windowframe": 'WINDOWFRAME',
}


def preset_dir():
    return bpy.utils.user_resource('CONFIG', path="plinthes_fred", create=True)


def preset_path(kind):
    return os.path.join(preset_dir(), "%s.json" % kind.lower())


def load_presets(kind):
    try:
        with open(preset_path(kind), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def write_presets(kind, data):
    with open(preset_path(kind), "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)


def settings_to_dict(s):
    """Every plain value of a settings group. Material is an ID, so it is
    skipped: a preset is a shape, not a link to a specific datablock."""
    out = {}
    for prop in s.bl_rna.properties:
        if prop.identifier in PRESET_SKIP or prop.is_readonly:
            continue
        if prop.type == 'POINTER':
            continue
        value = getattr(s, prop.identifier)
        if isinstance(value, (bool, int, float, str)):
            out[prop.identifier] = value
    return out


def apply_dict(s, data):
    global _GUARD
    _GUARD = True
    try:
        for key, value in data.items():
            if key in PRESET_SKIP:
                continue
            if not hasattr(s, key):
                continue                      # preset from an older version
            try:
                setattr(s, key, value)
            except (TypeError, ValueError):
                pass                          # an enum item that no longer exists
    finally:
        _GUARD = False

    obj = s.id_data
    if isinstance(obj, bpy.types.Object) and obj.get("trim_type") and s.live_update:
        try:
            rebuild_object(obj)
        except Exception as exc:
            print("[plinthes fred] rebuild failed:", exc)


def settings_kind(s):
    return PG_KIND.get(s.bl_rna.identifier, 'BASEBOARD')


def _user_preset_items(self, context):
    kind = settings_kind(self)
    names = sorted(load_presets(kind))
    if not names:
        items = [('NONE', "No saved presets", "Use the + button to save one")]
    else:
        items = [('NONE', "Select...", "")]
        items += [(n, n, "Apply the saved preset '%s'" % n) for n in names]
    _ENUM_CACHE[kind] = items
    return items


def _user_preset_update(self, context):
    if _GUARD or self.user_preset == 'NONE':
        return
    data = load_presets(settings_kind(self)).get(self.user_preset)
    if data:
        apply_dict(self, data)


def _apply_preset(s, table):
    """Push a preset's values onto a settings group, then rebuild once."""
    global _GUARD
    values = table.get(s.preset)
    if not values:
        return
    _GUARD = True
    try:
        for key, value in values.items():
            setattr(s, key, value)
    finally:
        _GUARD = False

    obj = s.id_data
    if isinstance(obj, bpy.types.Object) and obj.get("trim_type") and s.live_update:
        try:
            rebuild_object(obj)
        except Exception as exc:
            print("[plinthes fred] rebuild failed:", exc)


def _preset_update_baseboard(self, context):
    if not _GUARD:
        _apply_preset(self, BASEBOARD_PRESETS)


def _preset_update_casing(self, context):
    if not _GUARD:
        _apply_preset(self, CASING_PRESETS)


def _preset_prop(update, default, table):
    items = [it for it in PRESET_ITEMS if it[0] in table]
    return EnumProperty(name="Preset", items=items, default=default, update=update)


def _edge_props(prefix, default_kind, default_size):
    """Build the property dict for one shaped edge (inner or outer)."""
    return {
        prefix + "_edge": EnumProperty(
            name="Edge", items=EDGE_ITEMS, default=default_kind, update=_prop_update),
        prefix + "_size": FloatProperty(
            name="Size", default=default_size, min=0.0, max=1.0, subtype='FACTOR',
            description="Cut size, as a fraction of the smallest profile dimension",
            update=_prop_update),
        prefix + "_segments": IntProperty(
            name="Segments", default=3, min=1, max=32, update=_prop_update),
        prefix + "_steps": IntProperty(
            name="Steps", default=2, min=1, max=16, update=_prop_update),
        prefix + "_step_depth": FloatProperty(
            name="Step Depth", default=0.6, min=0.02, max=4.0, soft_max=2.5,
            description="How far the steps travel along the face. Above 1.0 the "
                        "moulding gets real relief instead of a flat slab",
            update=_prop_update),
    }


def _common_props():
    """Fresh property definitions shared by both tools.

    A new dict of new property definitions is built on every call: property
    definitions must never be shared between two registered classes.
    """
    return {
        "live_update": BoolProperty(
            name="Live Update", default=True,
            description="Rebuild the mesh as soon as a setting changes"),
        "user_preset": EnumProperty(
            name="My Presets", items=_user_preset_items,
            update=_user_preset_update,
            description="Your own saved presets"),
        "flip_side": BoolProperty(
            name="Flip Side", default=False,
            description="Build on the other side of the wall",
            update=_prop_update),
        # unwrap
        "uv_enabled": BoolProperty(name="Generate UVs", default=True, update=_prop_update),
        "uv_mode": EnumProperty(
            name="Mode", update=_prop_update, default='AUTO',
            items=[('AUTO', "Fit Texture",
                    "V spans the visible profile, U tiles from the texture aspect "
                    "ratio so the pixels stay square"),
                   ('TRIM', "Fit Profile",
                    "V spans the visible profile, U repeats every Tile Length"),
                   ('WORLD', "World Metres",
                    "Raw metres on both axes, for a plain tiling texture")]),
        "uv_tile_length": FloatProperty(
            name="Tile Length", default=0.5, min=0.001, soft_max=10.0,
            unit='LENGTH', description="Distance covered by one texture repeat",
            update=_prop_update),
        "uv_flip_v": BoolProperty(name="Flip V", default=False, update=_prop_update),
        "uv_continuous": BoolProperty(
            name="Continuous Texture", default=True,
            description="Anchor the texture to the wall: the grain carries on "
                        "from one side of a door to the other, and from the "
                        "baseboard up the leg of the door casing",
            update=_prop_update),
        "uv_lock": BoolProperty(
            name="Lock", default=False,
            description="Freeze the repeat length. Fit Texture will no longer "
                        "recompute it when the material changes",
            update=_prop_update),
        "uv_scale": FloatProperty(name="UV Scale", default=1.0, min=0.001, soft_max=10.0,
                                  update=_prop_update),
        "gen_vertex_color": BoolProperty(
            name="Vertex Color", default=True,
            description="Add a vertex color layer to the mesh - some "
                        "Sollumz/GTA shaders expect one to be present",
            update=_prop_update),
        "vertex_color": FloatVectorProperty(
            name="Color", subtype='COLOR', size=4,
            default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0,
            description="Color the vertex color layer is filled with",
            update=_prop_update),
        # library texture (Sollumz)
        "library_texture": PointerProperty(
            name="Library Texture", type=bpy.types.Image,
            description="Texture applied to a Sollumz 'default' shader "
                        "material, created automatically on this object",
            update=_library_texture_update),
        # collision
        "collision_enabled": BoolProperty(
            name="Collision", default=False,
            description="Also build a simplified box collision mesh "
                        "alongside the visual one, parented to it - matches "
                        "the plinth's real dimensions, handy for interior "
                        "MLO collision. Still needs Sollumz's own bound "
                        "setup applied to it afterwards",
            update=_prop_update),
        "collision_margin": FloatProperty(
            name="Margin", default=0.0, min=0.0, soft_max=0.05,
            unit='LENGTH',
            description="Inflate the collision box outward by this much on "
                        "every side, so it doesn't clip the visual mesh",
            update=_prop_update),
        # shading
        "shade_smooth": BoolProperty(name="Shade Smooth", default=True, update=_prop_update),
        "smooth_angle": FloatProperty(name="Angle", default=0.5236, min=0.0, max=3.14159,
                                      subtype='ANGLE', update=_prop_update),
        # material
        "material": PointerProperty(name="Material", type=bpy.types.Material,
                                    update=_prop_update),
        "refine": IntProperty(
            name="Refine Curves", default=0, min=0, max=8,
            description="Subdivide curved runs, for example the top of an arched "
                        "opening. Corners and straight runs are left untouched",
            update=_prop_update),
        "refine_angle": FloatProperty(
            name="Curve Limit", default=1.0472, min=0.0, max=3.14159,
            subtype='ANGLE',
            description="Turns sharper than this stay sharp corners",
            update=_prop_update),
        # advanced
        "miter_limit": FloatProperty(name="Miter Limit", default=8.0, min=1.0, max=50.0,
                                     update=_prop_update),
        "tolerance": FloatProperty(name="Tolerance", default=0.0005, min=0.000001,
                                   soft_max=0.05, precision=5, unit='LENGTH'),
        "parent_to_source": BoolProperty(name="Parent To Source", default=True),
    }


def _baseboard_annotations():
    d = _common_props()
    d["preset"] = _preset_prop(_preset_update_baseboard, 'CHAMFER', BASEBOARD_PRESETS)
    d.update(_edge_props("inner", 'SQUARE', 0.5))
    d.update(_edge_props("outer", 'CHAMFER', 0.5))
    d.update({
        "height": FloatProperty(
            name="Height", default=0.10, min=0.0005, soft_max=0.6,
            unit='LENGTH', update=_prop_update),
        "depth": FloatProperty(
            name="Depth", default=0.018, min=0.0005, soft_max=0.2,
            unit='LENGTH', update=_prop_update),
        "placement": EnumProperty(
            name="Placement", update=_prop_update,
            items=[('SKIRTING', "Skirting", "Along the bottom of the walls"),
                   ('CROWN', "Crown", "Along the top of the walls"),
                   ('CHAIR_RAIL', "Chair Rail", "At a fixed height above the floor")],
            default='SKIRTING'),
        "rail_height": FloatProperty(
            name="Rail Height", default=0.9, min=0.0, soft_max=3.0,
            unit='LENGTH', update=_prop_update),
        # fit
        "wall_offset": FloatProperty(
            name="Wall Gap", default=0.0, soft_min=-0.05, soft_max=0.05,
            unit='LENGTH', description="Push the trim away from the wall",
            update=_prop_update),
        "vertical_offset": FloatProperty(
            name="Vertical Offset", default=0.0, soft_min=-0.1, soft_max=0.1,
            unit='LENGTH', update=_prop_update),
        "extend": FloatProperty(
            name="Extend Ends", default=0.0, soft_min=-0.2, soft_max=0.2,
            unit='LENGTH', update=_prop_update),
        "auto_extend": BoolProperty(
            name="Auto Extend", default=False,
            description="Fire a ray from each open end and stretch it until it "
                        "meets whatever is in front: a door casing, a wall, "
                        "another baseboard",
            update=_prop_update),
        "auto_extend_max": FloatProperty(
            name="Search Distance", default=0.15, min=0.001, soft_max=1.0,
            unit='LENGTH',
            description="Give up beyond this distance and leave the end alone",
            update=_prop_update),
        "auto_extend_overlap": FloatProperty(
            name="Overlap", default=0.002, min=0.0, soft_max=0.02,
            unit='LENGTH',
            description="Push a little past the detected surface (door/window "
                        "frame, wall, other baseboard) so the end actually "
                        "touches it instead of stopping just short due to "
                        "raycast precision",
            update=_prop_update),
        "stop_at_obstacles": BoolProperty(
            name="Stop At Frames", default=True,
            description="Cut the baseboard wherever another object sits on "
                        "the wall (door/window casing, jamb lining, a post...) "
                        "instead of running through it or wrapping into the "
                        "opening",
            update=_prop_update),
        "cap_ends": BoolProperty(name="Cap Ends", default=True, update=_prop_update),
        # wainscoting (lambris)
        "wainscot": BoolProperty(
            name="Wainscoting", default=False,
            description="Add a panelled wainscot band above the baseboard: "
                        "board, rails, stiles, panels and a cap rail",
            update=_prop_update),
        "wains_height": FloatProperty(
            name="Height", default=0.90, min=0.05, soft_max=2.0,
            unit='LENGTH', description="Total height from the floor to the top of the cap rail",
            update=_prop_update),
        "wains_backer": FloatProperty(
            name="Board Thickness", default=0.010, min=0.0005, soft_max=0.05,
            unit='LENGTH', description="Flat board fixed against the wall",
            update=_prop_update),
        "wains_frame_width": FloatProperty(
            name="Frame Width", default=0.07, min=0.005, soft_max=0.3,
            unit='LENGTH', description="Width of the stiles (vertical) and rails (horizontal)",
            update=_prop_update),
        "wains_frame_depth": FloatProperty(
            name="Frame Depth", default=0.008, min=0.0, soft_max=0.05,
            unit='LENGTH', description="How far the frame stands proud of the board",
            update=_prop_update),
        "wains_panel_width": FloatProperty(
            name="Panel Width", default=0.45, min=0.05, soft_max=2.0,
            unit='LENGTH', description="Target panel width. Each wall gets a whole "
                                       "number of equal panels close to this",
            update=_prop_update),
        "wains_layout": EnumProperty(
            name="Layout", update=_prop_update, default='UNIFORM',
            items=[('UNIFORM', "Uniform", "Every panel the same width"),
                   ('ALTERNATE', "Narrow / Wide", "Alternate narrow and wide panels, "
                                                  "narrow ones at both ends")]),
        "wains_ratio": FloatProperty(
            name="Wide / Narrow", default=2.5, min=1.0, soft_max=5.0,
            description="How many times wider the wide panels are",
            update=_prop_update),
        "wains_raised": BoolProperty(
            name="Raised Panels", default=True,
            description="Bevelled panel inside each frame opening",
            update=_prop_update),
        "wains_raise": FloatProperty(
            name="Panel Thickness", default=0.005, min=0.0005, soft_max=0.04,
            unit='LENGTH', update=_prop_update),
        "wains_bevel": FloatProperty(
            name="Bevel", default=0.012, min=0.0, soft_max=0.1,
            unit='LENGTH', description="Width of the sloped border of the panel",
            update=_prop_update),
        "wains_cap": BoolProperty(
            name="Cap Rail", default=True,
            description="Moulding along the top of the wainscot, same edge "
                        "shapes as the baseboard",
            update=_prop_update),
        "wains_cap_height": FloatProperty(
            name="Cap Height", default=0.04, min=0.002, soft_max=0.2,
            unit='LENGTH', update=_prop_update),
        "wains_uv_size": FloatProperty(
            name="Texture Size", default=0.5, min=0.01, soft_max=5.0,
            unit='LENGTH', description="Distance covered by one texture repeat "
                                       "on the wainscot, independent of the baseboard",
            update=_prop_update),
        "wains_cap_depth": FloatProperty(
            name="Cap Depth", default=0.028, min=0.002, soft_max=0.1,
            unit='LENGTH', update=_prop_update),
    })
    return d


def _opening_annotations():
    """Everything a door casing and a window casing have in common."""
    d = _common_props()
    d["preset"] = _preset_prop(_preset_update_casing, 'STEPPED', CASING_PRESETS)
    d.update(_edge_props("inner", 'SQUARE', 0.5))
    d.update(_edge_props("outer", 'CHAMFER', 0.4))
    d.update({
        "width": FloatProperty(
            name="Width", default=0.09, min=0.0005, soft_max=0.5,
            unit='LENGTH', update=_prop_update),
        "thickness": FloatProperty(
            name="Thickness", default=0.02, min=0.0005, soft_max=0.2,
            unit='LENGTH', update=_prop_update),
        "reveal": FloatProperty(
            name="Reveal", default=0.0, soft_min=-0.05, soft_max=0.05,
            unit='LENGTH', description="Set the casing back from the opening edge",
            update=_prop_update),
        "both_sides": BoolProperty(
            name="Mirror", default=False,
            description="Add the far half: a matching casing on the other face of the wall",
            update=_prop_update),
        "jamb": BoolProperty(
            name="Jamb Lining", default=False,
            description="Line the inside of the opening", update=_prop_update),
        "jamb_depth": FloatProperty(
            name="Jamb Depth", default=0.12, min=0.001, soft_max=0.6,
            unit='LENGTH', update=_prop_update),
        "jamb_reveal": FloatProperty(
            name="Jamb Thickness", default=0.018, min=0.0005, soft_max=0.1,
            unit='LENGTH', update=_prop_update),
        "cap_ends": BoolProperty(name="Cap Ends", default=True, update=_prop_update),
    })
    return d


def _doorframe_annotations():
    d = _opening_annotations()
    d.update({
        "skip_bottom": BoolProperty(
            name="Skip Floor Run", default=True,
            description="Do not run the casing across the floor",
            update=_prop_update),
    })
    return d


def _windowframe_annotations():
    d = _opening_annotations()
    d.update({
        "sill": BoolProperty(
            name="Window Sill", default=False,
            description="Replace the bottom run with a sill board",
            update=_prop_update),
        "sill_thickness": FloatProperty(
            name="Thickness", default=0.03, min=0.0005, soft_max=0.15,
            unit='LENGTH', update=_prop_update),
        "sill_depth": FloatProperty(
            name="Depth", default=0.05, min=0.0, soft_max=0.5,
            unit='LENGTH', description="How far the sill sticks out of the wall",
            update=_prop_update),
        "sill_inset": FloatProperty(
            name="Inset", default=0.10, min=0.0, soft_max=1.0,
            unit='LENGTH', description="How far the sill runs back into the opening",
            update=_prop_update),
        "sill_overhang": FloatProperty(
            name="Overhang", default=0.04, min=0.0, soft_max=0.4,
            unit='LENGTH', description="How far the sill runs past the opening on each side",
            update=_prop_update),
        "sill_edge": EnumProperty(
            name="Front Edge", items=EDGE_ITEMS, default='CHAMFER', update=_prop_update),
        "sill_edge_size": FloatProperty(
            name="Edge Size", default=0.35, min=0.0, max=1.0, subtype='FACTOR',
            update=_prop_update),
        "sill_edge_segments": IntProperty(
            name="Segments", default=3, min=1, max=32, update=_prop_update),
    })
    return d


class TRIM_PG_baseboard(PropertyGroup):
    __annotations__ = _baseboard_annotations()


class TRIM_PG_doorframe(PropertyGroup):
    __annotations__ = _doorframe_annotations()


class TRIM_PG_windowframe(PropertyGroup):
    __annotations__ = _windowframe_annotations()


class TRIM_PG_scene(PropertyGroup):
    baseboard: PointerProperty(type=TRIM_PG_baseboard)
    doorframe: PointerProperty(type=TRIM_PG_doorframe)
    windowframe: PointerProperty(type=TRIM_PG_windowframe)
    texture: PointerProperty(
        name="Texture", type=bpy.types.Image,
        description="Image for the Apply Texture button")
    language: EnumProperty(
        name="Language", items=LANG_ITEMS, default='AUTO', update=_language_update_cb,
        description="Language of the plinthes fred panels")
    # what Auto Detect builds (checkboxes under its button)
    auto_baseboards: BoolProperty(name="Baseboards", default=True,
                                  description="Auto Detect: baseboards along the floor")
    auto_crown: BoolProperty(name="Ceiling Mouldings", default=True,
                             description="Auto Detect: mouldings along the top of the walls")
    auto_doors: BoolProperty(name="Doors", default=True,
                             description="Auto Detect: trim the door openings")
    auto_windows: BoolProperty(name="Windows", default=True,
                               description="Auto Detect: window frames")
    auto_join: BoolProperty(name="Baseboard Around Doors", default=True,
                            description="Auto Detect: the baseboard goes round the doors "
                                        "in one piece instead of separate door frames")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def copy_settings(src, dst):
    """Copy every value of one settings group onto another."""
    global _GUARD
    _GUARD = True
    try:
        for prop in src.bl_rna.properties:
            if prop.identifier in {"rna_type", "name"} or prop.is_readonly:
                continue
            setattr(dst, prop.identifier, getattr(src, prop.identifier))
    finally:
        _GUARD = False


def unique_name(base):
    i = 1
    while "%s_%03d" % (base, i) in bpy.data.objects:
        i += 1
    return "%s_%03d" % (base, i)


def get_collection(name):
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(coll)
    elif name not in {c.name for c in bpy.context.scene.collection.children_recursive}:
        try:
            bpy.context.scene.collection.children.link(coll)
        except RuntimeError:
            pass
    return coll


def active_settings(context, kind):
    """Return (settings, target_object) - the object's own settings if the
    active object was made by this add-on, otherwise the scene defaults."""
    obj_prop, scene_prop = KINDS[kind][0], KINDS[kind][1]
    obj = context.active_object
    if obj is not None and obj.get("trim_type") == kind:
        return getattr(obj, obj_prop), obj
    return getattr(context.scene.trim_settings, scene_prop), None


def texture_aspect(mat):
    """width / height of the first image texture of a material, or None."""
    if mat is None or not getattr(mat, "use_nodes", True) or mat.node_tree is None:
        return None
    for node in mat.node_tree.nodes:
        if node.type == 'TEX_IMAGE' and node.image is not None:
            w, h = node.image.size
            if w and h:
                return w / h
    return None


# ---------------------------------------------------------------------------
# Sollumz interop
#
# Sollumz is a separate add-on, so it's reached only through bpy.ops (stable
# regardless of how Sollumz's own package happens to be named/installed -
# "Sollumz", "bl_ext.user_default.sollumz", etc.) plus a bit of introspection
# to find its "default.sps" shader without hard-coding a list index that
# could shift between Sollumz versions.
# ---------------------------------------------------------------------------

def _sollumz_shadermats():
    """Sollumz's own `shadermats` list (the shader enum of its Create Shader
    Material operator), or None when Sollumz isn't there.

    The operator class has been renamed across Sollumz versions
    (SOLLUMZ_OT_create_shader_material, SOLLUMZ_OT_createshadermaterial...),
    so it is found by its bl_idname, with a module scan as a fallback.
    """
    cls = None
    for name in ("SOLLUMZ_OT_createshadermaterial", "SOLLUMZ_OT_create_shader_material"):
        cls = getattr(bpy.types, name, None)
        if cls is not None:
            break
    if cls is None:
        for name in dir(bpy.types):
            if name.startswith("SOLLUMZ_OT"):
                c = getattr(bpy.types, name, None)
                if getattr(c, "bl_idname", "") == "sollumz.createshadermaterial":
                    cls = c
                    break
    if cls is None:
        return None
    mod = _sys.modules.get(cls.__module__)
    sm = getattr(mod, "shadermats", None) if mod is not None else None
    if sm is not None:
        return sm
    root = cls.__module__.split(".ydr")[0]
    for name, m in list(_sys.modules.items()):
        if name.startswith(root) and m is not None and hasattr(m, "shadermats"):
            return m.shadermats
    return None


def _is_sollumz_shader(mat):
    """True for a Sollumz shader material, whatever the Sollumz version
    calls it ('SHADER' in older ones, 'sollumz_material_shader' in newer)."""
    if mat is None:
        return False
    st = str(getattr(mat, "sollum_type", "") or "")
    return "shader" in st.lower()


def sollumz_available():
    return _sollumz_shadermats() is not None


def create_sollumz_shader_material(obj, filename="default.sps"):
    """Add a Sollumz shader material (e.g. "default.sps") to ``obj``.

    Uses Sollumz's own "Create Shader Material" operator so the node tree,
    ``sollum_type`` and ``shader_properties`` come out exactly as Sollumz's
    own UI would build them - this add-on doesn't try to fake that node
    graph itself. Returns (material_or_None, error_message_or_None).
    """
    shadermats = _sollumz_shadermats()
    if shadermats is None:
        return None, "Sollumz isn't installed/enabled - can't create a Sollumz shader material"

    index = next((i for i, sm in enumerate(shadermats) if sm.value == filename), None)
    if index is None:
        return None, "Sollumz has no '%s' shader (installed Sollumz version may differ)" % filename

    # the operator works on bpy.context.selected_objects and appends a new
    # material slot, so give it a clean, single-object selection and clear
    # any existing slots first or repeated calls would pile up duplicates
    obj.data.materials.clear()
    prev_selected = list(bpy.context.selected_objects)
    prev_active = bpy.context.view_layer.objects.active
    for o in prev_selected:
        o.select_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    try:
        result = bpy.ops.sollumz.createshadermaterial(shader_index=index)
    except Exception as exc:
        return None, "Sollumz's Create Shader Material operator failed: %s" % exc
    finally:
        obj.select_set(False)
        for o in prev_selected:
            o.select_set(True)
        bpy.context.view_layer.objects.active = prev_active

    if 'FINISHED' not in result or not obj.data.materials:
        return None, "Sollumz's Create Shader Material operator didn't produce a material"
    return obj.data.materials[0], None


def assign_diffuse_texture(mat, image):
    """Point the shader's "DiffuseSampler" image texture node at ``image``."""
    if mat is None or mat.node_tree is None:
        return False
    node = mat.node_tree.nodes.get("DiffuseSampler")
    if node is None or node.type != 'TEX_IMAGE':
        return False
    node.image = image
    return True


def apply_library_texture(obj, s):
    """Make ``obj``'s material match ``s.library_texture`` / the Default
    Sollumz shader, creating the material the first time it's needed.

    Never touches the mesh geometry - this only ever edits a material
    data-block and (on first use) the object's material slot.
    """
    image = s.library_texture
    if image is None:
        return

    me = obj.data
    mat = me.materials[0] if me.materials else None
    is_sollumz_shader = _is_sollumz_shader(mat)

    if not is_sollumz_shader:
        mat, err = create_sollumz_shader_material(obj, "default.sps")
        if err:
            print("[plinthes fred] Library Texture:", err)
            return

    if not assign_diffuse_texture(mat, image):
        print("[plinthes fred] Library Texture: couldn't find a DiffuseSampler "
              "node on '%s' to assign the texture to" % mat.name)


def uv_setup(s, profile, aspect, hidden_last=True):
    """Return (u_scale, v_coords) for one profile.

    The profile loop always starts against the wall, so point 0 -> 1 is the
    hidden face lying on the floor and the last point -> 0 is the hidden back.
    Everything between is what the eye sees, and that is what gets V 0..1.
    """
    plen = tc.profile_lengths(profile)
    if not s.uv_enabled:
        return 1.0, list(plen)
    if s.uv_mode == 'WORLD':
        return s.uv_scale, [x * s.uv_scale for x in plen]

    count = len(profile)
    start = plen[1] if count > 2 else plen[0]
    if count > 2:
        end = plen[count - 1] if hidden_last else plen[count]
    else:
        end = plen[-1]
    span = max(end - start, 1e-6)

    v = [(x - start) / span for x in plen]
    if s.uv_flip_v:
        v = [1.0 - x for x in v]

    tile = s.uv_tile_length
    if s.uv_mode == 'AUTO' and aspect and not s.uv_lock:
        tile = span * aspect
    return s.uv_scale / max(tile, 1e-6), v


def uv_repeat_length(s, profile, aspect):
    """The distance one texture repeat covers, in metres."""
    u_scale, _v = uv_setup(s, profile, aspect)
    return 1.0 / max(u_scale, 1e-9)


def active_profile(s, kind):
    """The cross-section the given settings would produce right now."""
    if kind == 'BASEBOARD':
        return profile_from_settings(s, s.depth, s.height)
    return profile_from_settings(s, s.width, s.thickness)


def profile_from_settings(s, size_a, size_b, flip_a=False, flip_b=False):
    return tc.build_profile(
        size_a, size_b,
        inner=s.inner_edge, inner_size=s.inner_size,
        inner_segments=s.inner_segments, inner_steps=s.inner_steps,
        inner_step_depth=s.inner_step_depth,
        outer=s.outer_edge, outer_size=s.outer_size,
        outer_segments=s.outer_segments, outer_steps=s.outer_steps,
        outer_step_depth=s.outer_step_depth,
        flip_a=flip_a, flip_b=flip_b)


# ---------------------------------------------------------------------------
# Extraction from the edit-mode mesh
# ---------------------------------------------------------------------------

def welded_ids(bm, matrix=None, eps=1e-4):
    """Vertex index -> one index per position.

    Meshes often carry unmerged duplicate vertices (a boolean, a separated
    face, an extrude): edges that meet visually would not be chained into
    one run. Every vertex sitting at the same spot gets the same id.
    """
    to_world = (lambda c: matrix @ c) if matrix is not None else (lambda c: c)
    seen = {}
    out = {}
    for v in bm.verts:
        p = to_world(v.co)
        k = (round(p.x / eps), round(p.y / eps), round(p.z / eps))
        out[v.index] = seen.setdefault(k, v.index)
    return out


def world_maps(matrix):
    """Return (point_map, normal_map) for a source object matrix.

    Everything is generated in world space: an object scale of, say,
    (2, 1, 1) would otherwise stretch the profile differently on each wall.
    """
    if matrix is None:
        return (lambda co: co.copy()), (lambda n: n.copy())
    nm = matrix.to_3x3().inverted().transposed()
    return (lambda co: matrix @ co), (lambda n: nm @ n)


def extract_wall_runs(bm, placement, tol, matrix=None, faces=None, floor_z=None,
                      edge_filter=None):
    """Collect the bottom (or top) edges of the selected walls.

    ``faces``    use these faces instead of the selection
    ``floor_z``  only keep edges lying at this height (auto mode: the floor)
    """
    bm.verts.index_update()
    to_world, to_world_n = world_maps(matrix)

    wco = {}

    def co(v):
        c = wco.get(v.index)
        if c is None:
            c = to_world(v.co)
            wco[v.index] = c
        return c

    def face_normal(f):
        n = to_world_n(f.normal)
        return n.normalized() if n.length > 1e-9 else n

    outward = {}

    sel_faces = list(faces) if faces is not None else [f for f in bm.faces if f.select]
    wall_faces = [f for f in sel_faces if abs(face_normal(f).z) < 0.7]

    if wall_faces:
        for f in wall_faces:
            fn = face_normal(f)
            n = Vector((fn.x, fn.y, 0.0))
            if n.length < 1e-6:
                continue
            n.normalize()
            zs = [co(v).z for v in f.verts]
            target = max(zs) if placement == 'CROWN' else min(zs)
            if floor_z is not None:
                edge_z = max(zs) if placement == 'CROWN' else min(zs)
                if abs(edge_z - floor_z) > tol:
                    continue
                target = floor_z
            for e in f.edges:
                if edge_filter is not None and e not in edge_filter:
                    continue
                v0, v1 = e.verts
                z0, z1 = co(v0).z, co(v1).z
                if abs(z0 - z1) > tol:
                    continue
                if abs(0.5 * (z0 + z1) - target) > tol:
                    continue
                outward[e] = outward.get(e, Vector()) + n
    else:
        for e in bm.edges:
            if not e.select:
                continue
            acc = Vector()
            for f in e.link_faces:
                fn = face_normal(f)
                if abs(fn.z) < 0.7:
                    n = Vector((fn.x, fn.y, 0.0))
                    if n.length > 1e-6:
                        acc += n.normalized()
            if acc.length < 1e-6:
                continue
            outward[e] = acc

    if not outward:
        return []

    wid = welded_ids(bm, matrix)
    seg_out = {}
    segments = []
    for e, n in outward.items():
        a, b = wid[e.verts[0].index], wid[e.verts[1].index]
        key = (a, b) if a < b else (b, a)
        if key in seg_out:
            seg_out[key] = (seg_out[key] + n.normalized()).normalized()
            continue
        seg_out[key] = n.normalized()
        segments.append(key)

    coords = {}
    for e in outward:
        for v in e.verts:
            coords[wid[v.index]] = co(v)

    runs = []
    for chain, closed in tc.chain_segments(segments):
        pts = [coords[i] for i in chain]
        outs = []
        n = len(chain)
        count = n if closed else n - 1
        for i in range(count):
            a, b = chain[i], chain[(i + 1) % n]
            key = (a, b) if a < b else (b, a)
            outs.append(seg_out.get(key, Vector((1.0, 0.0, 0.0))))
        runs.append({
            "pts": [list(p) for p in pts],
            "closed": closed,
            "outs": [list(o) for o in outs],
            "normal": [0.0, 0.0, 1.0],
        })
    return runs


def extract_opening_runs(bm, tol, matrix=None, edges=None):
    """Collect the selected opening outline(s) (or the given ``edges``)."""
    bm.verts.index_update()
    to_world, to_world_n = world_maps(matrix)

    segments = []
    coords = {}
    seg_faces = {}          # segment -> world normals of the faces around it
    wid = welded_ids(bm, matrix)

    def add(e):
        a, b = wid[e.verts[0].index], wid[e.verts[1].index]
        key = (a, b) if a < b else (b, a)
        segments.append(key)
        coords[a] = to_world(e.verts[0].co)
        coords[b] = to_world(e.verts[1].co)
        lst = seg_faces.setdefault(key, [])
        for f in e.link_faces:
            n = to_world_n(f.normal)
            if n.length > 1e-9:
                lst.append(n.normalized())

    if edges is not None:
        for e in edges:
            add(e)
        if not segments:
            return []

    for e in (bm.edges if edges is None else ()):
        if e.select:
            add(e)

    if not segments and edges is None:
        for f in bm.faces:
            if not f.select:
                continue
            for e in f.edges:
                add(e)

    if not segments:
        return []

    runs = []
    for chain, closed in tc.chain_segments(segments):
        pts = [coords[i] for i in chain]
        n = len(pts)
        if n < 3:
            continue

        # plane normal of the outline (Newell)
        nrm = Vector((0.0, 0.0, 0.0))
        for i in range(n):
            a = pts[i]
            b = pts[(i + 1) % n]
            nrm.x += (a.y - b.y) * (a.z + b.z)
            nrm.y += (a.z - b.z) * (a.x + b.x)
            nrm.z += (a.x - b.x) * (a.y + b.y)
        if nrm.length < 1e-9:
            continue
        nrm.normalize()

        # Newell's sign depends on the loop winding, not on the wall.
        # Make it point the same way as the wall face the outline sits on,
        # so the casing grows OUT of the wall instead of into it.
        count = n if closed else n - 1
        vote = 0.0
        for i in range(count):
            a, b = chain[i], chain[(i + 1) % n]
            key = (a, b) if a < b else (b, a)
            for fn in seg_faces.get(key, ()):
                d = fn.dot(nrm)
                if abs(d) > 0.7:          # faces parallel to the wall only
                    vote += d
        if vote < 0.0 or (vote == 0.0 and nrm.z < -0.999):
            nrm = -nrm

        centre = Vector((0.0, 0.0, 0.0))
        for p in pts:
            centre += p
        centre /= n

        outs = []
        for i in range(count):
            a = pts[i]
            b = pts[(i + 1) % n]
            t = (b - a)
            if t.length < 1e-9:
                outs.append(Vector((1.0, 0.0, 0.0)))
                continue
            t.normalize()
            v = (a + b) * 0.5 - centre
            v = v - nrm * v.dot(nrm)
            v = v - t * v.dot(t)
            if v.length < 1e-9:
                v = t.cross(nrm)
            outs.append(v.normalized())

        runs.append({
            "pts": [list(p) for p in pts],
            "closed": closed,
            "outs": [list(o) for o in outs],
            "normal": list(nrm),
        })
    return runs


# ---------------------------------------------------------------------------
# Auto detection: floor, door and window openings of a whole wall mesh
# ---------------------------------------------------------------------------

def detect_openings(bm, matrix=None, tol=0.002, max_reveal=0.8, min_size=0.2):
    """Find every opening outline of a wall mesh.

    Works for both kinds of walls:
      * single-sided walls with holes cut in them (the outline is made of
        boundary edges),
      * walls with a thickness (the outline is the convex 90 degree edge
        between the wall face and the reveal running through the wall).

    Returns a dict:
        doors         list of edge lists, outlines that come down to the floor
        windows       list of edge lists, closed outlines above the floor
        reveal_faces  faces lining the openings (never get a baseboard)
        wall_faces    the vertical faces of the mesh
        floor_z       lowest point of the mesh (world)
    """
    bm.verts.index_update()
    bm.normal_update()
    to_world, to_world_n = world_maps(matrix)
    wco = {v.index: to_world(v.co) for v in bm.verts}

    def fnorm(f):
        n = to_world_n(f.normal)
        return n.normalized() if n.length > 1e-9 else n

    fn = {f: fnorm(f) for f in bm.faces}
    fcenter = {f: sum((wco[v.index] for v in f.verts), Vector()) / len(f.verts)
               for f in bm.faces}
    if not wco:
        return None
    zmin = min(c.z for c in wco.values())
    zmax = max(c.z for c in wco.values())

    def at(z, ref):
        return abs(z - ref) <= tol

    wall_faces = [f for f in bm.faces if abs(fn[f].z) < 0.7]
    outline = set()
    outline_face = {}
    reveal_faces = set()

    def reaches_back(g, nf):
        """Does the flat patch ``g`` belongs to (a reveal may be split in
        triangles) touch a face turned the other way than ``nf``?"""
        ng = fn[g]
        seen = {g}
        todo = [g]
        while todo and len(seen) < 64:
            cur = todo.pop()
            for e2 in cur.edges:
                for h in e2.link_faces:
                    if h in seen:
                        continue
                    if fn[h].dot(nf) < -0.7:
                        return True
                    if fn[h].dot(ng) > 0.999:
                        seen.add(h)
                        todo.append(h)
        return False

    candidates = []          # (edge, wall face, reveal face, depth)
    for f in wall_faces:
        nf = fn[f]
        for e in f.edges:
            a, b = wco[e.verts[0].index], wco[e.verts[1].index]
            horizontal = at(a.z, b.z)
            # the floor line and the top of the walls are never openings
            if horizontal and (at(a.z, zmin) or at(a.z, zmax)):
                continue
            others = [g for g in e.link_faces if g is not f]
            if not others:
                outline.add(e)              # hole cut in a single-sided wall
                outline_face.setdefault(e, f)
                continue
            mid = (a + b) * 0.5
            for g in others:
                ng = fn[g]
                if abs(ng.dot(nf)) > 0.3:
                    continue                # flat or gentle bend: same wall
                if (fcenter[g] - mid).dot(nf) >= -1e-6:
                    continue                # concave: an inside corner
                depth = max((mid - wco[v.index]).dot(nf) for v in g.verts)
                if depth > max_reveal:
                    continue                # a real wall around a corner
                # a reveal goes through the wall: on its far side it meets
                # the back face of the same wall (facing the other way).
                # A narrow piece of wall at a corner never does.
                if not reaches_back(g, nf):
                    continue
                candidates.append((e, f, g, depth))

    # A reveal runs through the wall, so its depth is the wall thickness.
    # The thickness is the depth most candidates share; a narrow piece of
    # wall between a corner and a door has its own, different width and is
    # kept as a wall (it gets its baseboard and its ceiling moulding).
    if candidates:
        votes = {}
        for _e, _f, _g, d in candidates:
            k = round(d / 0.005)
            votes[k] = votes.get(k, 0) + 1
        best = max(votes.items(), key=lambda kv: (kv[1], -kv[0]))[0]
        thickness = best * 0.005
        slack = max(0.01, 0.1 * thickness)
        for e, f, g, d in candidates:
            if abs(d - thickness) > slack:
                continue
            outline.add(e)
            outline_face.setdefault(e, f)
            reveal_faces.add(g)

    if not outline:
        return {"doors": [], "windows": [], "reveal_faces": reveal_faces,
                "wall_faces": wall_faces, "floor_z": zmin, "ceiling_z": zmax,
                "outline_face": outline_face}

    by_key = {}
    segs = []
    wid = welded_ids(bm, matrix)
    for e in outline:
        i, j = wid[e.verts[0].index], wid[e.verts[1].index]
        k = (i, j) if i < j else (j, i)
        by_key[k] = e
        segs.append(k)

    doors, windows = [], []
    for chain, closed in tc.chain_segments(segs):
        n = len(chain)
        count = n if closed else n - 1
        if count < 2:
            continue
        pts = [wco[i] for i in chain]
        zs = [p.z for p in pts]
        height = max(zs) - min(zs)
        # width measured horizontally across the outline
        span = 0.0
        for p in pts:
            for q in pts:
                d = Vector((p.x - q.x, p.y - q.y)).length
                if d > span:
                    span = d
        if height < min_size or span < min_size:
            continue                        # a wall end, a sliver, noise
        edges = []
        for k in range(count):
            i, j = chain[k], chain[(k + 1) % n]
            edges.append(by_key[(i, j) if i < j else (j, i)])
        if not closed:
            if at(pts[0].z, zmin) and at(pts[-1].z, zmin):
                doors.append(edges)
            continue
        if at(min(zs), zmin):
            doors.append(edges)
        else:
            windows.append(edges)

    return {"doors": doors, "windows": windows, "reveal_faces": reveal_faces,
            "wall_faces": wall_faces, "floor_z": zmin, "ceiling_z": zmax,
            "outline_face": outline_face}


def joined_door_runs(bm, found, matrix=None, tol=0.002, edge_filter=None):
    """Baseboard runs that go around the doors instead of stopping at them.

    The floor line of every wall face and the outline of every door are
    chained together: the moulding runs along the floor, turns up the door
    leg with a mitre, crosses the head, comes down and carries on.
    Each run stores, per segment, ``a_dirs`` (the profile's height axis: up
    on the floor, away from the opening on a door) and ``b_dirs`` (out of the
    wall).
    """
    to_world, to_world_n = world_maps(matrix)
    bm.verts.index_update()
    wco = {v.index: to_world(v.co) for v in bm.verts}

    def fnorm(f):
        n = to_world_n(f.normal)
        n = Vector((n.x, n.y, 0.0))
        return n.normalized() if n.length > 1e-9 else n

    wid = welded_ids(bm, matrix)

    def key(e):
        i, j = wid[e.verts[0].index], wid[e.verts[1].index]
        return (i, j) if i < j else (j, i)

    frame = {}
    zf = found["floor_z"]
    reveal = found["reveal_faces"]
    for f in found["wall_faces"]:
        if f in reveal:
            continue
        nf = fnorm(f)
        if nf.length < 1e-6:
            continue
        for e in f.edges:
            if edge_filter is not None and e not in edge_filter:
                continue
            a, b = wco[e.verts[0].index], wco[e.verts[1].index]
            if abs(a.z - zf) <= tol and abs(b.z - zf) <= tol:
                k = key(e)
                if k in frame:
                    frame[k] = (frame[k][0], (frame[k][1] + nf).normalized())
                else:
                    frame[k] = (Vector((0.0, 0.0, 1.0)), nf)

    door_keys = 0
    for edges in found["doors"]:
        for e in edges:
            f = found["outline_face"].get(e)
            if f is None:
                continue
            nf = fnorm(f)
            # the side of the edge the wall face lies on, from the face's own
            # winding (a centroid is useless on an ngon wrapped round a hole)
            loop = next((l for l in e.link_loops if l.face == f), None)
            if loop is None:
                continue
            p0 = wco[loop.vert.index]
            p1 = wco[loop.link_loop_next.vert.index]
            t = p1 - p0
            if t.length < 1e-9:
                continue
            t.normalize()
            fn3 = to_world_n(f.normal)
            fn3 = fn3.normalized() if fn3.length > 1e-9 else nf
            away = fn3.cross(t)
            away -= nf * away.dot(nf)
            if away.length < 1e-9:
                continue
            frame[key(e)] = (away.normalized(), nf)
            door_keys += 1

    if not door_keys:
        return []
    runs = []
    for chain, closed in tc.chain_segments(list(frame.keys())):
        n = len(chain)
        count = n if closed else n - 1
        segs = [frame[(chain[i], chain[(i + 1) % n]) if chain[i] < chain[(i + 1) % n]
                      else (chain[(i + 1) % n], chain[i])] for i in range(count)]
        if all(abs(a.z - 1.0) < 1e-6 for a, _b in segs):
            continue            # plain floor run: the normal baseboard does it
        pts = [wco[i] for i in chain]
        runs.append({
            "pts": [list(p) for p in pts],
            "closed": closed,
            "outs": [list(b) for _a, b in segs],
            "a_dirs": [list(a) for a, _b in segs],
            "normal": [0.0, 0.0, 1.0],
        })
    return runs


# ---------------------------------------------------------------------------
# Mesh building
# ---------------------------------------------------------------------------

def _run_vectors(run):
    pts = [Vector(p) for p in run["pts"]]
    outs = [Vector(o) for o in run["outs"]] or [Vector((1.0, 0.0, 0.0))]
    nrm = Vector(run["normal"])
    return pts, outs, nrm, bool(run["closed"])


def ray_distance(origin, direction, limit, ignore=None):
    """Distance to the first surface in front of a point, 0 if nothing.

    Never raises: if there is no usable context the caller simply gets 0 and
    the end is left where it was.
    """
    try:
        scene = bpy.context.scene
        deps = bpy.context.evaluated_depsgraph_get()
    except Exception:
        return 0.0
    if scene is None or deps is None:
        return 0.0

    eps = 0.0005                      # step off our own end cap first
    start = origin + direction * eps
    try:
        hit, location, _n, _i, obj, _m = scene.ray_cast(
            deps, start, direction, distance=max(limit, 1e-4))
    except Exception:
        return 0.0
    if not hit:
        return 0.0
    if ignore is not None and obj is not None:
        original = getattr(obj, "original", obj)
        if original == ignore:
            return 0.0
    return eps + (location - start).length


def auto_extend_amounts(pts, outs, s, owner):
    """How far each open end should travel to touch what is in front."""
    limit = s.auto_extend_max
    up = Vector((0.0, 0.0, -1.0 if s.placement == 'CROWN' else 1.0))
    flip = -1.0 if s.flip_side else 1.0

    def probe(end_point, direction, out):
        best = 0.0
        for factor in (0.25, 0.5, 0.75):
            origin = (end_point
                      + up * (s.height * factor)
                      + out * (s.depth * 0.5 * flip))
            d = ray_distance(origin, direction, limit, owner)
            if d > 0.0 and (best == 0.0 or d < best):
                best = d
        # push a bit further than the raw hit distance so the end actually
        # touches the surface instead of stopping just short of it
        return best + s.auto_extend_overlap if best > 0.0 else 0.0

    first = (pts[0] - pts[1])
    last = (pts[-1] - pts[-2])
    if first.length < 1e-9 or last.length < 1e-9:
        return 0.0, 0.0
    out_first = Vector(outs[0]) if outs else Vector((1.0, 0.0, 0.0))
    out_last = Vector(outs[-1]) if outs else out_first
    return (probe(pts[0], first.normalized(), out_first),
            probe(pts[-1], last.normalized(), out_last))


def auto_extend_report(obj, kind, runs, s):
    """A short human string summarizing what Auto Extend actually found on
    the open ends of ``runs``, or None if there's nothing to report (not a
    baseboard, Auto Extend is off, or every run is a closed loop).

    This re-runs the same raycasts as the real build, just to turn them into
    a status message - it doesn't touch the mesh.
    """
    if kind != 'BASEBOARD' or not s.auto_extend:
        return None
    hits = misses = 0
    for pts, outs, _nrm, closed in _baseboard_paths(runs, s, obj):
        if closed:
            continue
        for amount in auto_extend_amounts(pts, outs, s, obj):
            if amount > 0.0:
                hits += 1
            else:
                misses += 1
    if hits == 0 and misses == 0:
        return None
    if hits == 0:
        return ("Auto Extend found nothing within %.2fm of any open end - "
                "move the door/window frame closer or raise Search Distance"
                % s.auto_extend_max)
    if misses == 0:
        return "Auto Extend touched something on all %d open end(s)" % hits
    return ("Auto Extend touched %d end(s) but found nothing on %d - "
            "those may still show a gap" % (hits, misses))


# ---------------------------------------------------------------------------
# Stop at obstacles: cut the baseboard where something sits on the wall
# ---------------------------------------------------------------------------

def split_run_where(points, outs, closed, covered, step=0.04, eps=0.001,
                    iterations=14, min_length=0.002):
    """Cut a run wherever ``covered(point, out)`` is True.

    Each segment is sampled every ``step`` metres and every change of state is
    refined by bisection, so the cut lands right against the obstacle (a door
    casing, a jamb lining...) whatever the sampling step is.

    Returns a list of ``(points, outs, closed)``.  A run that is never covered
    comes back untouched (a closed loop stays closed).
    """
    n = len(points)
    nseg = n if closed else n - 1
    if nseg < 1:
        return [(points, outs, closed)]

    seg_intervals = []
    any_cut = False
    for i in range(nseg):
        A = points[i]
        B = points[(i + 1) % n]
        o = outs[i] if i < len(outs) else outs[-1]
        d = B - A
        L = d.length
        if L < 1e-9:
            seg_intervals.append([(0.0, L)])
            continue
        d = d / L

        def free(t):
            return not covered(A + d * t, o)

        lo, hi = min(eps, L * 0.5), max(L - eps, L * 0.5)
        m = max(2, int(math.ceil((hi - lo) / step)))
        ts = [lo + (hi - lo) * k / m for k in range(m + 1)]
        states = [free(t) for t in ts]

        # exact transition positions
        edges = []
        for k in range(m):
            if states[k] == states[k + 1]:
                continue
            a, b = ts[k], ts[k + 1]
            sa = states[k]
            for _ in range(iterations):
                mid = 0.5 * (a + b)
                if free(mid) == sa:
                    a = mid
                else:
                    b = mid
            # keep the cut on the free side
            edges.append(a if sa else b)

        intervals = []
        start = 0.0 if states[0] else None
        ei = 0
        for k in range(m):
            if states[k] == states[k + 1]:
                continue
            t = edges[ei]
            ei += 1
            if states[k]:              # free -> covered
                intervals.append((start, t))
                start = None
            else:                      # covered -> free
                start = t
        if start is not None:
            intervals.append((start, L))
        if not (len(intervals) == 1 and intervals[0] == (0.0, L)):
            any_cut = True
        seg_intervals.append([(t0, t1, A, d, o, L) for t0, t1 in intervals])

    if not any_cut:
        return [(points, outs, closed)]

    pieces = []          # [pts, outs, starts_at_run_start, ends_at_run_end]
    cur = None
    for i, ivs in enumerate(seg_intervals):
        if not ivs:
            # fully covered segment: close whatever was running
            if cur is not None:
                pieces.append(cur)
                cur = None
            continue
        if len(ivs[0]) == 2:
            # zero-length segment: just carry on
            if cur is not None:
                cur[0].append(points[(i + 1) % n])
                cur[1].append(outs[i] if i < len(outs) else outs[-1])
            continue
        for t0, t1, A, d, o, L in ivs:
            p0 = A + d * t0
            p1 = A + d * t1
            if t0 == 0.0 and cur is not None:
                cur[0].append(p1)
                cur[1].append(o)
            else:
                if cur is not None:
                    pieces.append(cur)
                cur = [[p0, p1], [o], (i == 0 and t0 == 0.0), False]
            if t1 < L:
                pieces.append(cur)
                cur = None
    if cur is not None:
        cur[3] = True
        pieces.append(cur)

    # a closed loop can join its last piece back onto its first one
    if (closed and len(pieces) > 1 and pieces[0][2] and pieces[-1][3]):
        last = pieces.pop()
        first = pieces[0]
        pieces[0] = [last[0] + first[0][1:], last[1] + first[1], False, False]

    result = []
    for pts, os_, _s, _e in pieces:
        length = sum((pts[k + 1] - pts[k]).length for k in range(len(pts) - 1))
        if length >= min_length:
            result.append((pts, os_, False))
    return result


def _hit_ignore_set(owner):
    """Objects that must never count as an obstacle for ``owner``."""
    ignore = set()
    if owner is None:
        return ignore
    ignore.add(owner)
    col = bpy.data.objects.get(owner.get("trim_col", "")) if owner.get("trim_col") else None
    if col is not None:
        ignore.add(col)
    for ob in bpy.data.objects:
        if ob.get("trim_type") == 'BASEBOARD':
            ignore.add(ob)
            c = ob.get("trim_col")
            if c and c in bpy.data.objects:
                ignore.add(bpy.data.objects[c])
    return ignore


def _first_obstacle(origin, direction, limit, ignore, source):
    """First object hit in front of ``origin`` that is not ignored.
    Returns (object, distance) or (None, None)."""
    try:
        scene = bpy.context.scene
        deps = bpy.context.evaluated_depsgraph_get()
    except Exception:
        return None, None
    if scene is None or deps is None:
        return None, None

    travelled = 0.0
    start = origin.copy()
    for _ in range(16):
        remaining = limit - travelled
        if remaining <= 1e-6:
            break
        try:
            hit, loc, _n, _i, obj, _m = scene.ray_cast(
                deps, start, direction, distance=remaining)
        except Exception:
            return None, None
        if not hit:
            break
        dist = travelled + (loc - start).length
        original = getattr(obj, "original", obj) if obj is not None else None
        if original is not None and original in ignore:
            travelled = dist + 1e-5
            start = loc + direction * 1e-5
            continue
        return original, dist
    return None, None


def make_obstacle_test(s, owner):
    """Return ``covered(point, out)`` for a baseboard: True when something
    other than the wall (door/window casing, jamb lining, a post...) sits
    where the baseboard would be."""
    ignore = _hit_ignore_set(owner)
    source = None
    if owner is not None and owner.get("trim_source"):
        source = bpy.data.objects.get(owner.get("trim_source"))

    up = Vector((0.0, 0.0, -1.0 if s.placement == 'CROWN' else 1.0))
    flip = -1.0 if s.flip_side else 1.0
    clear = max(s.wall_offset, 0.0) + s.depth + 0.01
    limit = clear + 0.002
    margin = max(0.002, getattr(s, "tolerance", 0.0) * 2.0)

    def covered(p, out):
        side = Vector(out)
        side.z = 0.0
        if side.length < 1e-9:
            return False
        side.normalize()
        side *= flip
        for factor in (0.25, 0.5, 0.75):
            origin = p + up * (s.vertical_offset + s.height * factor) + side * clear
            obj, dist = _first_obstacle(origin, -side, limit, ignore, source)
            if obj is None:
                continue
            # The bare wall is exactly ``clear`` away. Anything closer stands
            # proud of the wall (casing, jamb lining, post...), whether it is
            # its own object or was joined into the wall mesh itself.
            if dist > clear - margin:
                continue
            return True
        return False

    return covered


def _baseboard_paths(runs, s, owner=None):
    """Yield (pts, outs, nrm, closed) ready to sweep, before end extension."""
    covered = None
    if getattr(s, "stop_at_obstacles", False) and owner is not None:
        covered = make_obstacle_test(s, owner)

    for run in runs:
        if run.get("a_dirs"):
            continue            # joined door runs: swept by _framed_sweeps
        pts, outs, nrm, closed = _run_vectors(run)

        if s.placement == 'CROWN':
            nrm = -nrm
        elif s.placement == 'CHAIR_RAIL':
            pts = [p + Vector((0.0, 0.0, s.rail_height)) for p in pts]

        if s.refine:
            pts, outs = tc.refine_run(pts, outs, closed, s.refine, s.refine_angle)

        if covered is not None:
            pieces = tc.split_run_where(pts, outs, closed, covered)
        else:
            pieces = [(pts, outs, closed)]

        for p_pts, p_outs, p_closed in pieces:
            yield p_pts, p_outs, nrm, p_closed


def _framed_sweeps(runs, s, profile, u_scale, v_coords, cap_ends):
    for run in runs:
        if not run.get("a_dirs"):
            continue
        pts = [Vector(p) for p in run["pts"]]
        a_dirs = [Vector(a) for a in run["a_dirs"]]
        b_dirs = [Vector(b) for b in run["outs"]]
        yield tc.sweep_framed(
            pts, bool(run["closed"]), a_dirs, b_dirs, profile,
            miter_limit=s.miter_limit, offset_a=s.wall_offset,
            offset_b=s.vertical_offset, u_scale=u_scale, v_coords=v_coords,
            cap_ends=cap_ends)


def stop_at_obstacles_report(obj, runs, s):
    """Short status line: how many pieces Stop At Frames produced."""
    if not getattr(s, "stop_at_obstacles", False):
        return "v%d.%d.%d - Stop At Frames is off" % ADDON_VERSION
    before = len(runs)
    after = sum(1 for _ in _baseboard_paths(runs, s, obj))
    return ("v%d.%d.%d - Stop At Frames: %d run(s) -> %d piece(s)"
            % (ADDON_VERSION + (before, after)))


def _baseboard_extend(pts, outs, closed, s, owner):
    if s.auto_extend and not closed:
        a, b = auto_extend_amounts(pts, outs, s, owner)
        if a or b:
            pts = tc.extend_ends(pts, closed, a, b)
    if s.extend:
        pts = tc.extend_run(pts, closed, s.extend)
    return pts


def _sweeps_baseboard(runs, s, aspect=None, owner=None):
    """Yield (verts, faces, uvs) tuples for a baseboard."""
    profile = profile_from_settings(s, s.depth, s.height, flip_a=s.flip_side)
    u_scale, v_coords = uv_setup(s, profile, aspect)
    wains = wainscot_params(s, u_scale)
    offset_a = s.wall_offset
    if wains is not None:
        # the baseboard is nailed over the wainscot board
        offset_a += wains["backer"] * wains["f"]
    for pts, outs, nrm, closed in _baseboard_paths(runs, s, owner):
        pts = _baseboard_extend(pts, outs, closed, s, owner)

        seg_u = None
        if s.uv_enabled and s.uv_continuous:
            seg_u = tc.segment_u_ranges(pts, closed, outs)

        yield tc.sweep_run(
            pts, closed, nrm, outs, profile,
            miter_limit=s.miter_limit,
            offset_a=offset_a,
            offset_b=s.vertical_offset,
            u_scale=u_scale, v_coords=v_coords, cap_ends=s.cap_ends,
            seg_u=seg_u)

        if wains is not None:
            for part in tc.wainscot_parts(pts, closed, nrm, outs, wains):
                yield part

    for part in _framed_sweeps(runs, s, profile, u_scale, v_coords, s.cap_ends):
        yield part


def wainscot_params(s, u_scale):
    """Settings dict for wainscot_parts, or None when it is off."""
    if not getattr(s, "wainscot", False) or s.placement != 'SKIRTING':
        return None
    f = -1.0 if s.flip_side else 1.0
    cap = None
    if s.wains_cap:
        cap = profile_from_settings(s, s.wains_cap_depth, s.wains_cap_height,
                                    flip_a=s.flip_side)
    return {
        "f": f,
        "a0": s.wall_offset,
        "backer": s.wains_backer,
        "frame_w": s.wains_frame_width,
        "frame_d": s.wains_frame_depth,
        "panel_w": s.wains_panel_width,
        "alternate": s.wains_layout == 'ALTERNATE',
        "ratio": s.wains_ratio,
        "base_top": s.vertical_offset + s.height,
        "top": max(s.wains_height, s.vertical_offset + s.height + 0.01),
        "cap_h": s.wains_cap_height,
        "cap_profile": cap,
        "raise_d": s.wains_raise if s.wains_raised else 0.0,
        "bevel": s.wains_bevel,
        # its own texel density: editing the baseboard profile must never
        # rescale the wainscot texture
        "u_scale": (s.uv_scale / max(s.wains_uv_size, 1e-4)) if s.uv_enabled else 1.0,
    }


def _sill_profile(s):
    """Sill cross-section: a = downwards (away from the opening), b = wall normal."""
    prof = tc.build_profile(
        s.sill_thickness, s.sill_depth + s.sill_inset,
        inner=s.sill_edge, inner_size=s.sill_edge_size,
        inner_segments=s.sill_edge_segments,
        outer=s.sill_edge, outer_size=s.sill_edge_size,
        outer_segments=s.sill_edge_segments)
    # the profile is built from 0; slide it back so it starts inside the opening
    return [(a, b - s.sill_inset) for a, b in prof]


def _baseboard_u_scale(owner):
    """U density of a baseboard built on the same wall as ``owner``, so a
    casing can share it and the texture lines up where the two meet."""
    if owner is None:
        return None
    src = owner.get("trim_source")
    for ob in bpy.data.objects:
        if ob is owner or ob.get("trim_type") != 'BASEBOARD':
            continue
        if src and ob.get("trim_source") != src:
            continue
        bs = ob.trim_baseboard
        if bs.placement != 'SKIRTING' or not bs.uv_enabled:
            continue
        mat = bs.material or (ob.data.materials[0] if ob.data.materials else None)
        prof = profile_from_settings(bs, bs.depth, bs.height)
        return uv_setup(bs, prof, texture_aspect(mat))[0]
    return None


def _sweeps_opening(runs, s, is_window, aspect=None, owner=None):
    """Yield (verts, faces, uvs) tuples for a door or window casing."""
    casing = profile_from_settings(s, s.width, s.thickness)
    u_scale, v_coords = uv_setup(s, casing, aspect)
    continuous = s.uv_enabled and s.uv_continuous
    if continuous:
        shared = _baseboard_u_scale(owner)
        if shared:
            u_scale = shared
    jamb = [(0.0, -s.jamb_depth * 0.5), (0.0, s.jamb_depth * 0.5),
            (-s.jamb_reveal, s.jamb_depth * 0.5), (-s.jamb_reveal, -s.jamb_depth * 0.5)]

    use_sill = is_window and s.sill
    skip_bottom = use_sill if is_window else s.skip_bottom
    tol = max(s.tolerance, 1e-5)

    for run in runs:
        pts, outs, nrm, closed = _run_vectors(run)
        if s.flip_side:
            nrm = -nrm

        if s.refine:
            pts, outs = tc.refine_run(pts, outs, closed, s.refine, s.refine_angle)

        pieces = [(pts, outs, closed)]
        bottoms = []
        if closed and (skip_bottom or use_sill):
            other, bottoms = tc.split_at_bottom(pts, outs, closed, tol)
            if skip_bottom and other:
                pieces = other

        for p, o, cl in pieces:
            sides = [False, True] if s.both_sides else [False]
            for mirrored in sides:
                prof = casing
                if mirrored:
                    prof = [(a, -b) for a, b in casing]
                yield tc.sweep_run(
                    p, cl, nrm, o, prof,
                    miter_limit=s.miter_limit,
                    offset_a=s.reveal, offset_b=0.0,
                    u_scale=u_scale, v_coords=v_coords, cap_ends=s.cap_ends,
                    seg_u=(tc.segment_u_ranges(p, cl, o, s.reveal + s.width)
                           if continuous else None))
            if s.jamb:
                ju, jv = uv_setup(s, jamb, aspect)
                yield tc.sweep_run(
                    p, cl, nrm, o, jamb,
                    miter_limit=s.miter_limit,
                    offset_a=0.0, offset_b=0.0,
                    u_scale=ju, v_coords=jv, cap_ends=s.cap_ends,
                    seg_u=tc.segment_u_ranges(p, cl, o) if continuous else None)

        if use_sill:
            sill = _sill_profile(s)
            su, sv = uv_setup(s, sill, aspect)
            for bp, bo, _bc in bottoms:
                bp = tc.extend_run(bp, False, s.sill_overhang)
                yield tc.sweep_run(
                    bp, False, nrm, bo, sill,
                    miter_limit=s.miter_limit,
                    offset_a=0.0, offset_b=0.0,
                    u_scale=su, v_coords=sv, cap_ends=True)


def collision_box_profile(profile, margin=0.0):
    """A plain 4-point rectangle enclosing ``profile``, inflated by margin.

    Used for the simplified collision mesh: whatever the moulding's real
    cross-section looks like (chamfer, bullnose, stepped, ...), the collision
    just needs its bounding box so it stays a handful of triangles - simple
    and cheap, per GTA V/FiveM collision conventions.
    """
    xs = [p[0] for p in profile]
    ys = [p[1] for p in profile]
    x0, x1 = min(xs) - margin, max(xs) + margin
    y0, y1 = min(ys) - margin, max(ys) + margin
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]


def _sweeps_baseboard_collision(runs, s, owner=None):
    """Yield sweep_run tuples for a simplified box collision under a baseboard."""
    profile = profile_from_settings(s, s.depth, s.height, flip_a=s.flip_side)
    box = collision_box_profile(profile, s.collision_margin)
    v_coords = profile_lengths(box)

    wains = wainscot_params(s, 1.0)
    if wains is not None:
        f = wains["f"]
        thick = max(wains["backer"] + wains["frame_d"],
                    s.wains_cap_depth if s.wains_cap else 0.0,
                    wains["backer"] + s.depth)
        x1 = thick * f + s.collision_margin * f
        x0 = -s.collision_margin * f
        box = [(x0, -s.collision_margin), (x1, -s.collision_margin),
               (x1, wains["top"] + s.collision_margin),
               (x0, wains["top"] + s.collision_margin)]
        v_coords = profile_lengths(box)

    for pts, outs, nrm, closed in _baseboard_paths(runs, s, owner):
        pts = _baseboard_extend(pts, outs, closed, s, owner)

        yield tc.sweep_run(
            pts, closed, nrm, outs, box,
            miter_limit=s.miter_limit,
            offset_a=s.wall_offset,
            offset_b=s.vertical_offset,
            u_scale=1.0, v_coords=v_coords, cap_ends=True)

    for part in _framed_sweeps(runs, s, box, 1.0, v_coords, True):
        yield part


def _sweeps_opening_collision(runs, s, is_window):
    """Yield sweep_run tuples for a simplified box collision under a casing."""
    casing = profile_from_settings(s, s.width, s.thickness)
    box = collision_box_profile(casing, s.collision_margin)
    v_coords = profile_lengths(box)
    tol = max(s.tolerance, 1e-5)

    for run in runs:
        pts, outs, nrm, closed = _run_vectors(run)
        if s.flip_side:
            nrm = -nrm

        if s.refine:
            pts, outs = tc.refine_run(pts, outs, closed, s.refine, s.refine_angle)

        pieces = [(pts, outs, closed)]
        if closed and s.skip_bottom and not (is_window and s.sill):
            other, _bottoms = tc.split_at_bottom(pts, outs, closed, tol)
            if other:
                pieces = other

        for p, o, cl in pieces:
            yield tc.sweep_run(
                p, cl, nrm, o, box,
                miter_limit=s.miter_limit,
                offset_a=s.reveal, offset_b=0.0,
                u_scale=1.0, v_coords=v_coords, cap_ends=True)


def build_collision_mesh(me, runs, s, kind, owner=None):
    """(Re)build the simplified box collision mesh from the stored runs.

    No UVs, no material, no smoothing - it's never meant to be seen, only to
    give the physics engine something to bump into.
    """
    bm = bmesh.new()

    if kind == 'BASEBOARD':
        gen = _sweeps_baseboard_collision(runs, s, owner)
    else:
        gen = _sweeps_opening_collision(runs, s, kind == 'WINDOWFRAME')

    for verts, faces, _face_uvs in gen:
        bverts = [bm.verts.new(v) for v in verts]
        for face in faces:
            try:
                bm.faces.new([bverts[i] for i in face])
            except ValueError:
                continue

    bm.verts.index_update()
    bm.faces.index_update()
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])

    bm.to_mesh(me)
    bm.free()
    me.update()
    me.update_tag()


def sync_collision_object(owner, kind, runs, s):
    """Create, refresh, or remove the companion collision object for ``owner``.

    The collision object is a plain child of the visual trim object, named
    "<trim>_col" and kept in its own collection so it's easy to hide or
    exclude from the viewport. It still needs Sollumz's own bound/collision
    setup run on it before it does anything in-game - this only builds the
    simplified geometry, it doesn't know Sollumz's own operators for that.
    """
    existing_name = owner.get("trim_col")
    col_obj = bpy.data.objects.get(existing_name) if existing_name else None

    if not s.collision_enabled:
        if col_obj is not None:
            me = col_obj.data
            bpy.data.objects.remove(col_obj, do_unlink=True)
            if me is not None and me.users == 0:
                bpy.data.meshes.remove(me)
        if "trim_col" in owner:
            del owner["trim_col"]
        return

    if col_obj is None:
        name = unique_name(owner.name + "_col")
        me = bpy.data.meshes.new(name)
        col_obj = bpy.data.objects.new(name, me)
        get_collection(COLLISION_COLL).objects.link(col_obj)
        col_obj.parent = owner
        col_obj.matrix_parent_inverse = Matrix.Identity(4)
        col_obj.matrix_basis = Matrix.Identity(4)
        col_obj.display_type = 'WIRE'
        col_obj.hide_render = True
        owner["trim_col"] = col_obj.name

    build_collision_mesh(col_obj.data, runs, s, kind, owner)


def _layer_names(me):
    """Names for the UV map and vertex color layer of a rebuilt mesh.

    A rebuild replaces every layer, so the names must be carried over:
    a Sollumz shader reads "UVMap 0" / "Color 1" by name, and a texture
    breaks the moment the rebuilt mesh calls them anything else.

    Priority: what the material's nodes ask for, then what the mesh had,
    then the Sollumz names when Sollumz is installed, else Blender's.
    """
    uv_name = color_name = None
    for mat in me.materials:
        if mat is None or not getattr(mat, "use_nodes", True) or mat.node_tree is None:
            continue
        for node in mat.node_tree.nodes:
            if uv_name is None and node.type == 'UVMAP' and node.uv_map:
                uv_name = node.uv_map
            elif color_name is None and node.type == 'VERTEX_COLOR' and node.layer_name:
                color_name = node.layer_name
    # a Sollumz shader material: its export expects these exact names
    if any(_is_sollumz_shader(m) for m in me.materials):
        uv_name = uv_name or "UVMap 0"
        color_name = color_name or "Color 1"
    if uv_name is None and me.uv_layers:
        uv_name = me.uv_layers[0].name
    if color_name is None and len(me.color_attributes):
        color_name = me.color_attributes[0].name
    sollumz = sollumz_available()
    if uv_name is None:
        uv_name = "UVMap 0" if sollumz else "UVMap"
    if color_name is None:
        color_name = "Color 1" if sollumz else "Color"
    return uv_name, color_name


def build_mesh(me, runs, s, kind, owner=None):
    """(Re)build the mesh datablock from the stored runs."""
    uv_name, color_name = _layer_names(me)
    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new(uv_name)
    color_layer = bm.loops.layers.color.new(color_name) if s.gen_vertex_color else None
    vcolor = tuple(s.vertex_color) if color_layer is not None else None

    mat = s.material or (me.materials[0] if me.materials else None)
    aspect = texture_aspect(mat)

    if kind == 'BASEBOARD':
        gen = _sweeps_baseboard(runs, s, aspect, owner)
    else:
        gen = _sweeps_opening(runs, s, kind == 'WINDOWFRAME', aspect, owner)

    for verts, faces, face_uvs in gen:
        bverts = [bm.verts.new(v) for v in verts]
        for idx, face in enumerate(faces):
            try:
                f = bm.faces.new([bverts[i] for i in face])
            except ValueError:
                continue
            for loop, uv in zip(f.loops, face_uvs[idx]):
                loop[uv_layer].uv = uv
                if color_layer is not None:
                    loop[color_layer] = vcolor

    bm.verts.index_update()
    bm.faces.index_update()
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])

    smooth = s.shade_smooth
    for f in bm.faces:
        f.smooth = smooth
    if smooth:
        limit = s.smooth_angle
        for e in bm.edges:
            if len(e.link_faces) == 2:
                e.smooth = e.calc_face_angle(0.0) <= limit
            else:
                e.smooth = False

    bm.to_mesh(me)
    bm.free()
    me.update()

    # bm.to_mesh replaces every custom data layer, which leaves the mesh with
    # no UV map flagged for rendering. An Image Texture node with nothing
    # plugged into its Vector input then samples a single texel and the whole
    # trim turns into one flat colour. Put the flags back.
    if me.uv_layers:
        me.uv_layers.active_index = 0
        for i, layer in enumerate(me.uv_layers):
            layer.active_render = (i == 0)
        # the first me.update() above ran before the flags were restored, so
        # the mesh was briefly "no UV flagged for render" - update again now
        # that it's fixed, or a rebuild triggered from the Rebuild button can
        # leave the viewport showing that flat colour instead of the texture
        # until something else nudges it.
        me.update()

    # same story for vertex colors: bm.to_mesh created the "Color" layer but
    # didn't mark it active, so Vertex Paint mode and any "Color Attribute"
    # node with nothing typed into its Name field keep showing the mesh's
    # default (grey/white) instead of it.
    if me.color_attributes:
        me.color_attributes.active_color_index = 0
        if hasattr(me.color_attributes, "render_color_index"):
            me.color_attributes.render_color_index = 0
        me.update()

    # and make sure the viewport rebuilds its cached batches, since the mesh
    # was edited from a property callback rather than by an operator
    me.update_tag()
    for ob in bpy.data.objects:
        if ob.data is me:
            ob.update_tag(refresh={'DATA', 'OBJECT'})

    # force every 3D viewport to redraw right away - the GPU shading batch
    # built while the UV map was still unflagged can otherwise linger as a
    # flat colour on screen until some unrelated redraw happens to clear it
    wm = getattr(bpy.context, "window_manager", None)
    if wm is not None:
        for window in wm.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

    # material: only touched when one is picked, so a manual assignment survives
    if s.material is not None:
        if not me.materials:
            me.materials.append(s.material)
        elif me.materials[0] is not s.material:
            me.materials[0] = s.material


def rebuild_object(obj):
    kind = obj.get("trim_type")
    raw = obj.get("trim_data")
    if not kind or not raw:
        return False
    if kind not in KINDS:
        return False
    data = json.loads(raw)
    s = getattr(obj, KINDS[kind][0])
    build_mesh(obj.data, data["runs"], s, kind, obj)
    sync_collision_object(obj, kind, data["runs"], s)
    return True


def create_trim_object(context, source, runs, settings, kind):
    obj_prop, _scene_prop, base, coll_name = KINDS[kind]
    name = unique_name(base)
    me = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, me)

    obj["trim_type"] = kind
    obj["trim_source"] = source.name
    obj["trim_data"] = json.dumps({"runs": runs, "space": "WORLD"})

    target = getattr(obj, obj_prop)
    copy_settings(settings, target)

    coll = get_collection(coll_name)
    coll.objects.link(obj)

    # the runs are stored in world space, so the object itself stays at the
    # origin; parenting uses the inverse matrix so it still follows the wall
    if settings.parent_to_source:
        obj.parent = source
        obj.matrix_parent_inverse = source.matrix_world.inverted()
    obj.matrix_basis = Matrix.Identity(4)

    build_mesh(me, runs, target, kind, obj)
    sync_collision_object(obj, kind, runs, target)
    if target.library_texture is not None:
        apply_library_texture(obj, target)
    return obj


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class TRIM_OT_create_baseboard(Operator):
    bl_idname = "trim.create_baseboard"
    bl_label = "Create Baseboard"
    bl_description = "Build a mitred baseboard along the selected wall geometry"
    bl_options = {'REGISTER', 'UNDO'}

    wainscot: BoolProperty(
        name="Wainscoting", default=False, options={'HIDDEN', 'SKIP_SAVE'},
        description="Build a panelled wainscot above the baseboard")
    crown: BoolProperty(
        name="Ceiling", default=False, options={'HIDDEN', 'SKIP_SAVE'},
        description="Build the moulding along the top of the walls")

    @classmethod
    def description(cls, context, props):
        if props is not None and props.crown:
            return ("Build a crown moulding along the top of the selected walls, "
                    "against the ceiling")
        if props is not None and props.wainscot:
            return ("Build a baseboard with a panelled wainscot (lambris) above "
                    "it, along the selected wall geometry")
        return "Build a plain mitred baseboard along the selected wall geometry"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        # the button decides: plain baseboard or wainscot. The scene
        # settings are switched for this one creation, then put back.
        s = context.scene.trim_settings.baseboard
        old = (s.wainscot, s.placement)
        global _GUARD
        _GUARD = True
        try:
            s.wainscot = self.wainscot and not self.crown
            if self.crown:
                s.placement = 'CROWN'
            elif self.wainscot or s.placement == 'CROWN':
                s.placement = 'SKIRTING'
        finally:
            _GUARD = False
        try:
            return self._create(context, s)
        finally:
            _GUARD = True
            try:
                s.wainscot, s.placement = old
            finally:
                _GUARD = False

    def _create(self, context, s):
        source = context.active_object

        bm = bmesh.from_edit_mesh(source.data)
        bm.verts.ensure_lookup_table()
        faces = [f for f in bm.faces if f.select]
        if faces:
            # never run along the reveal of a door or window, even when
            # it is part of the selection (the moulding would wrap into
            # the opening, or follow the top of a door frame)
            found = detect_openings(bm, source.matrix_world,
                                    tol=max(s.tolerance, 1e-6) * 4.0)
            if found is not None:
                kept = [f for f in faces if f not in found["reveal_faces"]]
                if kept:
                    faces = kept
        runs = extract_wall_runs(bm, s.placement, max(s.tolerance, 1e-6),
                                 source.matrix_world, faces=faces or None)

        if not runs:
            self.report({'ERROR'},
                        "Nothing found: select the wall faces, or the bottom edges directly")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')
        obj = create_trim_object(context, source, runs, s, 'BASEBOARD')

        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        msg = "Created '%s': %d run(s), %d face(s)" % (
            obj.name, len(runs), len(obj.data.polygons))
        cut_msg = stop_at_obstacles_report(obj, runs, getattr(obj, "trim_baseboard"))
        if cut_msg:
            msg += " - " + cut_msg
        extend_msg = auto_extend_report(obj, 'BASEBOARD', runs, getattr(obj, "trim_baseboard"))
        if extend_msg:
            msg += " - " + extend_msg
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class TRIM_OT_auto_trim(Operator):
    bl_idname = "trim.auto_trim"
    bl_label = "Auto Detect"
    bl_description = ("Scan the whole wall mesh and build everything at once: "
                      "baseboards along the floor, a door frame on every opening "
                      "that reaches the floor, a window frame on every other one")
    bl_options = {'REGISTER', 'UNDO'}

    baseboards: BoolProperty(name="Baseboards", default=True)
    wainscot: BoolProperty(name="As Wainscoting", default=False,
                           description="Build wainscots instead of plain baseboards")
    crown: BoolProperty(name="Ceiling Mouldings", default=True,
                        description="Also run a moulding along the top of the walls")
    doors: BoolProperty(name="Door Frames", default=True)
    join_doors: BoolProperty(
        name="Baseboard Around Doors", default=True,
        description="The baseboard turns up the door legs with a mitre and goes "
                    "around the door like the top corners, in one continuous "
                    "piece (texture included). Off: separate door frames")
    windows: BoolProperty(name="Window Frames", default=True)
    selected_only: BoolProperty(
        name="Selected Edges Only", default=False,
        description="Only build on the edges selected in Edit Mode: select the "
                    "door outline and the floor edges you want, and both are "
                    "made in one go")
    max_reveal: FloatProperty(
        name="Max Wall Thickness", default=0.8, min=0.01, soft_max=2.0, unit='LENGTH',
        description="Openings are recognised by their reveal through the wall: "
                    "anything deeper than this is treated as a wall corner instead")

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == 'MESH'
                and not obj.get("trim_type")
                and context.mode in {'OBJECT', 'EDIT_MESH'})

    def execute(self, context):
        global _GUARD
        source = context.active_object
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        sc = context.scene.trim_settings

        bm = bmesh.new()
        bm.from_mesh(source.data)
        bm.verts.ensure_lookup_table()
        tol = max(sc.baseboard.tolerance, 1e-6) * 4.0
        found = detect_openings(bm, source.matrix_world, tol=tol,
                                max_reveal=self.max_reveal)
        if found is None:
            bm.free()
            self.report({'ERROR'}, "This mesh is empty")
            return {'CANCELLED'}

        sel = None
        if self.selected_only:
            sel = {e for e in bm.edges if e.select}
            if not sel:
                bm.free()
                self.report({'ERROR'}, "Select edges in Edit Mode first: the door "
                                       "outline and/or the floor edges")
                return {'CANCELLED'}
            # the selection says it all: whatever is selected and is not the
            # floor or the top of the walls is an opening outline
            self._outlines_from_selection(bm, found, sel, source.matrix_world, tol)

        made = []
        counts = []
        join = (self.join_doors and self.doors and self.baseboards
                and not self.wainscot and found["doors"])
        joined_runs = (joined_door_runs(bm, found, source.matrix_world, tol,
                                        edge_filter=sel)
                       if join else [])
        if join and not joined_runs:
            join = False

        # frames first: the baseboards then stop against their casings
        for flag, groups, kind, label in (
                (self.doors and not join, found["doors"], 'DOORFRAME', "door"),
                (self.windows, found["windows"], 'WINDOWFRAME', "window")):
            if not flag or not groups:
                continue
            settings = getattr(sc, KINDS[kind][1])
            runs = []
            for edges in groups:
                runs += extract_opening_runs(bm, max(settings.tolerance, 1e-6),
                                             source.matrix_world, edges=edges)
            if runs:
                made.append(create_trim_object(context, source, runs, settings, kind))
                counts.append("%d %s(s)" % (len(runs), label))

        if self.baseboards or self.crown:
            context.view_layer.update()
        if self.baseboards:
            reveal = found["reveal_faces"]
            faces = [f for f in found["wall_faces"] if f not in reveal]
            s = sc.baseboard
            old = (s.wainscot, s.placement)
            _GUARD = True
            try:
                s.wainscot = self.wainscot
                s.placement = 'SKIRTING'
            finally:
                _GUARD = False
            try:
                runs = extract_wall_runs(bm, 'SKIRTING', tol, source.matrix_world,
                                         faces=faces, floor_z=found["floor_z"],
                                         edge_filter=sel)
                if join:
                    # floor lines that touch a door are swept with it instead
                    used = set()
                    for jr in joined_runs:
                        for p in jr["pts"]:
                            used.add(tuple(round(c, 5) for c in p))
                    runs = [r for r in runs
                            if not any(tuple(round(c, 5) for c in p) in used
                                       for p in r["pts"])]
                    runs = runs + joined_runs
                    counts.append("%d door(s) joined" % len(found["doors"]))
                if runs:
                    made.append(create_trim_object(context, source, runs, s, 'BASEBOARD'))
                    counts.append("%d wall run(s)" % len(runs))
            finally:
                _GUARD = True
                try:
                    s.wainscot, s.placement = old
                finally:
                    _GUARD = False

        if self.crown:
            reveal = found["reveal_faces"]
            faces = [f for f in found["wall_faces"] if f not in reveal]
            s = sc.baseboard
            old = (s.wainscot, s.placement)
            _GUARD = True
            try:
                s.wainscot = False
                s.placement = 'CROWN'
            finally:
                _GUARD = False
            try:
                runs = extract_wall_runs(bm, 'CROWN', tol, source.matrix_world,
                                         faces=faces, floor_z=found["ceiling_z"],
                                         edge_filter=sel)
                if runs:
                    made.append(create_trim_object(context, source, runs, s, 'BASEBOARD'))
                    counts.append("%d ceiling run(s)" % len(runs))
            finally:
                _GUARD = True
                try:
                    s.wainscot, s.placement = old
                finally:
                    _GUARD = False
        bm.free()

        if not made:
            self.report({'WARNING'}, "Nothing to build was found on '%s'" % source.name)
            return {'CANCELLED'}
        for o in context.selected_objects:
            o.select_set(False)
        for o in made:
            o.select_set(True)
        context.view_layer.objects.active = made[-1]
        self.report({'INFO'}, "Auto Detect on '%s': %s" % (source.name, ", ".join(counts)))
        return {'FINISHED'}


def _outlines_from_selection(self, bm, found, sel, matrix, tol):
    """Door / window outlines taken straight from the selected edges.

    No reveal detection: works whatever the wall thickness, single-sided
    or solid. Selected floor and ceiling edges are left for the baseboard
    and the ceiling moulding.
    """
    to_world, to_world_n = world_maps(matrix)
    wco = {v.index: to_world(v.co) for v in bm.verts}
    zf, zc = found["floor_z"], found["ceiling_z"]

    def flat_at(e, z):
        a, b = wco[e.verts[0].index], wco[e.verts[1].index]
        return abs(a.z - z) <= tol and abs(b.z - z) <= tol

    outline = [e for e in sel if not flat_at(e, zf) and not flat_at(e, zc)]
    wid = welded_ids(bm, matrix)
    by_key = {}          # position key -> every edge sitting there
    for e in outline:
        i, j = wid[e.verts[0].index], wid[e.verts[1].index]
        if i != j:
            by_key.setdefault((i, j) if i < j else (j, i), []).append(e)

    doors, windows = [], []
    outline_face = {}
    reveal = set()
    for chain, closed in tc.chain_segments(list(by_key.keys())):
        n = len(chain)
        count = n if closed else n - 1
        if count < 1:
            continue
        pts = [wco[i] for i in chain]
        copies = [by_key[(chain[k], chain[(k + 1) % n]) if chain[k] < chain[(k + 1) % n]
                         else (chain[(k + 1) % n], chain[k])] for k in range(count)]
        # plane of the outline: the wall it is cut in
        N = Vector()
        loop = pts if closed else pts + [pts[0]]
        for k in range(len(loop) - 1 if not closed else len(loop)):
            a, b = loop[k], loop[(k + 1) % len(loop)]
            N.x += (a.y - b.y) * (a.z + b.z)
            N.y += (a.z - b.z) * (a.x + b.x)
            N.z += (a.x - b.x) * (a.y + b.y)
        if N.length < 1e-9:
            continue
        N.normalize()
        edges = []
        for group in copies:
            # among the duplicate edges at this spot, the one lying on the
            # wall face (the face parallel to the outline) carries the trim
            best, best_e, best_d = None, group[0], 0.7
            for e in group:
                for f in e.link_faces:
                    fn = to_world_n(f.normal)
                    if fn.length < 1e-9:
                        continue
                    d = abs(fn.normalized().dot(N))
                    if d > best_d:
                        best, best_e, best_d = f, e, d
            edges.append(best_e)
            if best is None:
                continue
            outline_face[best_e] = best
            for e in group:
                for f in e.link_faces:
                    if f is not best:
                        reveal.add(f)
        zs = [p.z for p in pts]
        touches = abs(min(zs) - zf) <= tol
        if (not closed and abs(pts[0].z - zf) <= tol and abs(pts[-1].z - zf) <= tol) \
                or (closed and touches):
            doors.append(edges)
        elif closed:
            windows.append(edges)
        elif touches:
            doors.append(edges)
        else:
            windows.append(edges)

    found["doors"] = doors
    found["windows"] = windows
    found["outline_face"] = outline_face
    found["reveal_faces"] = reveal


TRIM_OT_auto_trim._outlines_from_selection = _outlines_from_selection


class TRIM_OT_create_doorframe(Operator):
    bl_idname = "trim.create_doorframe"
    bl_label = "Create Door Frame"
    bl_description = "Build a mitred casing around the selected opening outline"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        source = context.active_object
        s = context.scene.trim_settings.doorframe

        bm = bmesh.from_edit_mesh(source.data)
        bm.verts.ensure_lookup_table()
        runs = extract_opening_runs(bm, max(s.tolerance, 1e-6),
                                    source.matrix_world)

        if not runs:
            self.report({'ERROR'}, "Nothing found: select the edges around the opening")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')
        obj = create_trim_object(context, source, runs, s, 'DOORFRAME')

        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        self.report({'INFO'}, "Created '%s': %d outline(s), %d face(s)"
                    % (obj.name, len(runs), len(obj.data.polygons)))
        return {'FINISHED'}


class TRIM_OT_create_windowframe(Operator):
    bl_idname = "trim.create_windowframe"
    bl_label = "Create Window Frame"
    bl_description = "Build a mitred casing around the selected window outline"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        source = context.active_object
        s = context.scene.trim_settings.windowframe

        bm = bmesh.from_edit_mesh(source.data)
        bm.verts.ensure_lookup_table()
        runs = extract_opening_runs(bm, max(s.tolerance, 1e-6),
                                    source.matrix_world)

        if not runs:
            self.report({'ERROR'}, "Nothing found: select the edges around the window")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')
        obj = create_trim_object(context, source, runs, s, 'WINDOWFRAME')

        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        self.report({'INFO'}, "Created '%s': %d outline(s), %d face(s)"
                    % (obj.name, len(runs), len(obj.data.polygons)))
        return {'FINISHED'}


class TRIM_OT_preset_save(Operator):
    bl_idname = "trim.preset_save"
    bl_label = "Save Preset"
    bl_description = "Save the current settings under a name you choose"
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')
    preset_name: StringProperty(name="Name", default="My Preset")

    def invoke(self, context, event):
        s, _obj = active_settings(context, self.kind)
        if s.user_preset != 'NONE':
            self.preset_name = s.user_preset
        return context.window_manager.invoke_props_dialog(self, width=280)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "preset_name")
        if self.preset_name.strip() in load_presets(self.kind):
            layout.label(text="This will overwrite the existing one", icon='ERROR')

    def execute(self, context):
        name = self.preset_name.strip()
        if not name:
            self.report({'ERROR'}, "Give the preset a name")
            return {'CANCELLED'}

        s, _obj = active_settings(context, self.kind)
        data = load_presets(self.kind)
        data[name] = settings_to_dict(s)
        try:
            write_presets(self.kind, data)
        except OSError as exc:
            self.report({'ERROR'}, "Could not write the preset file: %s" % exc)
            return {'CANCELLED'}

        global _GUARD
        _GUARD = True
        try:
            s.user_preset = name
        except TypeError:
            pass
        finally:
            _GUARD = False

        self.report({'INFO'}, "Saved '%s'" % name)
        return {'FINISHED'}


class TRIM_OT_preset_delete(Operator):
    bl_idname = "trim.preset_delete"
    bl_label = "Delete Preset"
    bl_description = "Delete the selected preset"
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        s, _obj = active_settings(context, self.kind)
        name = s.user_preset
        data = load_presets(self.kind)
        if name == 'NONE' or name not in data:
            self.report({'ERROR'}, "No preset selected")
            return {'CANCELLED'}
        del data[name]
        try:
            write_presets(self.kind, data)
        except OSError as exc:
            self.report({'ERROR'}, "Could not write the preset file: %s" % exc)
            return {'CANCELLED'}

        global _GUARD
        _GUARD = True
        try:
            s.user_preset = 'NONE'
        except TypeError:
            pass
        finally:
            _GUARD = False

        self.report({'INFO'}, "Deleted '%s'" % name)
        return {'FINISHED'}


class TRIM_OT_preset_folder(Operator):
    bl_idname = "trim.preset_folder"
    bl_label = "Open Preset Folder"
    bl_description = "Show the folder holding the preset files"
    bl_options = {'REGISTER'}

    def execute(self, context):
        path = preset_dir()
        try:
            bpy.ops.wm.path_open(filepath=path)
        except Exception:
            self.report({'INFO'}, path)
            return {'FINISHED'}
        self.report({'INFO'}, path)
        return {'FINISHED'}


class TRIM_OT_fix_uv(Operator):
    bl_idname = "trim.fix_uv"
    bl_label = "Fix UV Map"
    bl_description = "Flag the first UV map as the one to render"
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        me = context.active_object.data
        if not me.uv_layers:
            self.report({'ERROR'}, "No UV map on this mesh, rebuild it first")
            return {'CANCELLED'}
        me.uv_layers.active_index = 0
        for i, layer in enumerate(me.uv_layers):
            layer.active_render = (i == 0)
        me.update_tag()
        context.active_object.update_tag(refresh={'DATA'})
        self.report({'INFO'}, "'%s' is now the render UV map" % me.uv_layers[0].name)
        return {'FINISHED'}


class TRIM_OT_lock_uv(Operator):
    bl_idname = "trim.lock_uv"
    bl_label = "Lock Current Repeat"
    bl_description = ("Freeze the repeat length being used right now, so a "
                      "rebuild can never change the mapping again")
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')

    def execute(self, context):
        s, obj = active_settings(context, self.kind)
        mat = s.material
        if mat is None and obj is not None and obj.data.materials:
            mat = obj.data.materials[0]
        length = uv_repeat_length(s, active_profile(s, self.kind),
                                  texture_aspect(mat))
        global _GUARD
        _GUARD = True
        try:
            s.uv_tile_length = length
            s.uv_lock = True
        finally:
            _GUARD = False
        self.report({'INFO'}, "Repeat locked at %.3f m" % length)
        return {'FINISHED'}


def _selected_trims(context):
    objs = list(context.selected_objects)
    act = context.active_object
    if act is not None and act not in objs:
        objs.append(act)
    return [o for o in objs if o.get("trim_type") in KINDS]


class TRIM_OT_apply_texture(Operator):
    bl_idname = "trim.apply_texture"
    bl_label = "Apply Texture"
    bl_description = ("Put the chosen image on the selected baseboards, wainscots "
                      "and frames (Sollumz default shader). With nothing selected, "
                      "it is kept for the next ones you create")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.trim_settings.texture is not None

    def execute(self, context):
        global _GUARD
        image = context.scene.trim_settings.texture
        targets = _selected_trims(context)

        if not targets:
            _GUARD = True
            try:
                for kind in KINDS:
                    setattr(getattr(context.scene.trim_settings, KINDS[kind][1]),
                            "library_texture", image)
            finally:
                _GUARD = False
            self.report({'INFO'}, "'%s' will be used by the next trims you create" % image.name)
            return {'FINISHED'}

        if not sollumz_available():
            self.report({'ERROR'}, "Sollumz isn't installed/enabled - it is needed for the shader")
            return {'CANCELLED'}

        done = 0
        for obj in targets:
            s = getattr(obj, KINDS[obj["trim_type"]][0])
            _GUARD = True
            try:
                s.library_texture = image
            finally:
                _GUARD = False
            apply_library_texture(obj, s)
            # rebuild so the UV / color layer names match the new material
            rebuild_object(obj)
            mat = obj.data.materials[0] if obj.data.materials else None
            node = mat.node_tree.nodes.get("DiffuseSampler") if mat and mat.node_tree else None
            if node is not None and node.image == image:
                done += 1
        if done < len(targets):
            self.report({'WARNING'}, "Texture applied on %d of %d object(s) - see the console"
                        % (done, len(targets)))
        else:
            self.report({'INFO'}, "'%s' applied on %d object(s)" % (image.name, done))
        return {'FINISHED'}


class TRIM_OT_rebuild(Operator):
    bl_idname = "trim.rebuild"
    bl_label = "Rebuild"
    bl_description = "Rebuild this trim from its stored path"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get("trim_type"))

    def execute(self, context):
        obj = context.active_object
        if rebuild_object(obj):
            kind = obj.get("trim_type")
            raw = obj.get("trim_data")
            if kind == 'BASEBOARD' and raw:
                data = json.loads(raw)
                s = getattr(obj, KINDS[kind][0])
                msgs = []
                cut = stop_at_obstacles_report(obj, data["runs"], s)
                if cut:
                    msgs.append(cut)
                msg = auto_extend_report(obj, kind, data["runs"], s)
                if msg:
                    msgs.append(msg)
                if msgs:
                    self.report({'INFO'}, " - ".join(msgs))
            return {'FINISHED'}
        self.report({'ERROR'}, "No stored path on this object")
        return {'CANCELLED'}


class TRIM_OT_reset(Operator):
    bl_idname = "trim.reset_settings"
    bl_label = "Reset Settings"
    bl_description = "Restore the default values"
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')

    def execute(self, context):
        s, obj = active_settings(context, self.kind)
        global _GUARD
        _GUARD = True
        try:
            for prop in s.bl_rna.properties:
                if prop.identifier in {"rna_type", "name"} or prop.is_readonly:
                    continue
                s.property_unset(prop.identifier)
        finally:
            _GUARD = False
        if obj is not None and s.live_update:
            rebuild_object(obj)
        return {'FINISHED'}


class TRIM_OT_select_source(Operator):
    bl_idname = "trim.select_source"
    bl_label = "Select Source"
    bl_description = "Make the source object active"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get("trim_source"))

    def execute(self, context):
        src = bpy.data.objects.get(context.active_object.get("trim_source", ""))
        if src is None:
            self.report({'ERROR'}, "Source object not found")
            return {'CANCELLED'}
        for o in context.selected_objects:
            o.select_set(False)
        src.select_set(True)
        context.view_layer.objects.active = src
        return {'FINISHED'}


class TRIM_OT_preset_texture_collision(Operator):
    bl_idname = "trim.preset_texture_collision"
    bl_label = "Texture + Collision"
    bl_description = ("Create the trim with its Sollumz material, the "
                       "selected texture and a matching collision all set "
                       "up in one step, without changing its dimensions")
    bl_options = {'REGISTER', 'UNDO'}

    kind: StringProperty(default='BASEBOARD')

    _CREATE_OPS = {
        'BASEBOARD': "create_baseboard",
        'DOORFRAME': "create_doorframe",
        'WINDOWFRAME': "create_windowframe",
    }

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        s, _ = active_settings(context, self.kind)
        if s.library_texture is None:
            self.report({'ERROR'}, "Pick a Library Texture first")
            return {'CANCELLED'}

        global _GUARD
        _GUARD = True
        try:
            s.collision_enabled = True
        finally:
            _GUARD = False

        op_name = self._CREATE_OPS.get(self.kind)
        if op_name is None:
            self.report({'ERROR'}, "Unknown trim kind '%s'" % self.kind)
            return {'CANCELLED'}
        return getattr(bpy.ops.trim, op_name)()


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

def draw_unwrap_block(layout, context, kind):
    s, obj = active_settings(context, kind)

    if obj is not None and s.uv_enabled:
        me = obj.data
        if not me.uv_layers:
            layout.label(text="This mesh has no UV map", icon='ERROR')
        elif not any(l.active_render for l in me.uv_layers):
            box = layout.box()
            box.label(text="No UV map is flagged for render", icon='ERROR')
            box.operator("trim.fix_uv", text="Fix It").kind = kind

    layout.prop(s, "uv_enabled")

    col = layout.column()
    col.enabled = s.uv_enabled
    col.prop(s, "uv_continuous")
    col.prop(s, "uv_mode")

    mat = s.material
    if mat is None and obj is not None and obj.data.materials:
        mat = obj.data.materials[0]
    aspect = texture_aspect(mat)

    if s.uv_mode == 'AUTO':
        box = col.box()
        if aspect:
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node.image is not None:
                    w, h = node.image.size
                    box.label(text="%s  %d x %d" % (node.image.name, w, h),
                              icon='TEXTURE')
                    break
            box.label(text="Ratio %.2f : 1, pixels kept square" % aspect)
        else:
            box.label(text="No image texture found", icon='ERROR')
            box.label(text="Using Tile Length instead")

        length = uv_repeat_length(s, active_profile(s, kind), aspect)
        row = box.row()
        row.label(text="Repeat every %.3f m" % length,
                  icon='LOCKED' if s.uv_lock else 'UNLOCKED')
        if s.uv_lock:
            box.prop(s, "uv_lock", text="Locked", toggle=True)
            col.prop(s, "uv_tile_length")
        else:
            op = box.operator("trim.lock_uv", text="Lock This Value",
                              icon='DECORATE_LOCKED')
            op.kind = kind
            box.label(text="Unlocked: changes with the texture")
    elif s.uv_mode == 'TRIM':
        col.prop(s, "uv_tile_length")

    if s.uv_mode == 'WORLD':
        col.prop(s, "uv_scale")
    else:
        col.prop(s, "uv_flip_v")
        col.prop(s, "uv_scale", text="Extra Scale")

    layout.separator()
    layout.prop(s, "gen_vertex_color")
    vc_row = layout.column()
    vc_row.enabled = s.gen_vertex_color
    vc_row.prop(s, "vertex_color")


def draw_preset_block(layout, s, kind):
    layout.prop(s, "preset")
    row = layout.row(align=True)
    row.prop(s, "user_preset", text="My Presets")
    sub = row.row(align=True)
    sub.operator("trim.preset_save", text="", icon='ADD').kind = kind
    op = sub.operator("trim.preset_delete", text="", icon='REMOVE')
    op.kind = kind
    sub.enabled = True


def draw_edge_block(layout, s, prefix, label):
    col = layout.column(align=True)
    col.prop(s, prefix + "_edge", text=label)
    kind = getattr(s, prefix + "_edge")
    if kind in SHAPED:
        col.prop(s, prefix + "_size")
    if kind in ROUNDED:
        col.prop(s, prefix + "_segments")
    if kind == 'STEPPED':
        col.prop(s, prefix + "_steps")
        col.prop(s, prefix + "_step_depth")


def draw_header_block(layout, context, kind, hint):
    """Object name / live update / source rows shared by both tools."""
    s, obj = active_settings(context, kind)

    row = layout.row(align=True)
    row.label(text=hint, icon='INFO')

    if obj is None:
        layout.label(text="Settings for the next trim", icon='PREFERENCES')
        return s, obj

    row = layout.row(align=True)
    row.prop(obj, "name", text="", icon='OUTLINER_OB_MESH')
    row.prop(s, "live_update", text="", icon='FILE_REFRESH')

    row = layout.row(align=True)
    row.prop(s, "live_update", toggle=True)
    sub = row.row(align=True)
    sub.enabled = not s.live_update
    sub.operator("trim.rebuild", text="Rebuild")

    row = layout.row(align=True)
    row.operator("trim.select_source", text="Source: %s" % obj.get("trim_source", "?"),
                 icon='OBJECT_DATA', emboss=False)
    return s, obj


def draw_library_texture_block(layout, context, kind):
    """'Library Texture' UI shared by the baseboard/doorframe/windowframe
    panels: pick an image, show it, and show the (fixed) Sollumz shader
    that will be used to build the material automatically."""
    s, _ = active_settings(context, kind)
    layout.template_ID(s, "library_texture", open="image.open")

    row = layout.row()
    row.enabled = False
    row.label(text="Shader: Default Sollumz")

    if not sollumz_available():
        box = layout.box()
        box.label(text="Sollumz not found", icon='ERROR')
        box.label(text="Install/enable it to auto-create the material")


def draw_collision_block(layout, context, kind):
    """'Collision' UI shared by the baseboard/doorframe/windowframe panels,
    plus the 'Texture + Collision' one-click preset."""
    s, _ = active_settings(context, kind)
    layout.prop(s, "collision_enabled", text="Collision")
    sub = layout.column()
    sub.enabled = s.collision_enabled
    sub.prop(s, "collision_margin")
    if s.collision_enabled:
        layout.label(text="Still needs Sollumz's own bound setup for export", icon='INFO')

    layout.separator()
    op = layout.operator("trim.preset_texture_collision", text="Texture + Collision",
                         icon='SHADING_TEXTURE')
    op.kind = kind


class VIEW3D_PT_trim_main(Panel):
    bl_label = "plinthes fred"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"

    def draw_header_preset(self, context):
        self.layout.label(text="v%d.%d.%d" % ADDON_VERSION)

    def draw(self, context):
        layout = self.layout
        sc = context.scene.trim_settings
        layout.prop(sc, "language")
        box = layout.box()
        row = box.row()
        row.scale_y = 1.4
        op = row.operator("trim.auto_trim", text="Auto Detect (whole wall)", icon='AUTO')
        op.baseboards = sc.auto_baseboards
        op.crown = sc.auto_crown
        op.doors = sc.auto_doors
        op.windows = sc.auto_windows
        op.join_doors = sc.auto_join
        grid = box.grid_flow(columns=2, even_columns=True, align=True)
        grid.prop(sc, "auto_baseboards", toggle=True)
        grid.prop(sc, "auto_crown", toggle=True)
        grid.prop(sc, "auto_doors", toggle=True)
        grid.prop(sc, "auto_windows", toggle=True)
        sub = box.row()
        sub.enabled = sc.auto_doors and sc.auto_baseboards
        sub.prop(sc, "auto_join")
        row = box.row()
        row.enabled = context.mode == 'EDIT_MESH'
        op = row.operator("trim.auto_trim", text="Create From Selection", icon='RESTRICT_SELECT_OFF')
        op.selected_only = True
        op.baseboards = sc.auto_baseboards
        op.crown = sc.auto_crown
        op.doors = sc.auto_doors
        op.windows = sc.auto_windows
        op.join_doors = sc.auto_join
        layout.label(text="Interior:")
        col = layout.column(align=True)
        col.scale_y = 1.15
        col.operator("trim.create_baseboard", icon='MOD_LENGTH')
        col.operator("trim.create_baseboard", text="Create Wainscoting",
                     icon='MESH_GRID').wainscot = True
        col.operator("trim.create_baseboard", text="Create Ceiling Moulding",
                     icon='TRIA_UP_BAR').crown = True
        col.operator("trim.create_doorframe", icon='MOD_BUILD')
        col.operator("trim.create_windowframe", icon='MOD_LATTICE')
        if context.mode != 'EDIT_MESH':
            layout.label(text="Enter Edit Mode on a wall mesh", icon='INFO')

        layout.separator()
        layout.label(text="Texture:")
        box = layout.box()
        box.template_ID(context.scene.trim_settings, "texture", open="image.open")
        n = len(_selected_trims(context))
        row = box.row()
        row.scale_y = 1.15
        if n:
            text = "Apply Texture (%d selected)" % n
        else:
            text = "Use For Next Trims"
        row.operator("trim.apply_texture", text=text, icon='TEXTURE')


class VIEW3D_PT_trim_baseboard(Panel):
    bl_label = "Baseboard"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_main"

    def draw_header_preset(self, context):
        op = self.layout.operator("trim.reset_settings", text="", icon='LOOP_BACK',
                                  emboss=False)
        op.kind = 'BASEBOARD'

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        row = layout.row()
        row.scale_y = 1.2
        row.operator("trim.create_baseboard", text="Create Baseboard")
        row.operator("trim.create_baseboard", text="Create Wainscoting").wainscot = True
        row = layout.row()
        row.operator("trim.create_baseboard", text="Create Ceiling Moulding").crown = True
        draw_header_block(layout, context, 'BASEBOARD',
                          "Edit Mode: select wall faces or edges")


class VIEW3D_PT_trim_baseboard_size(Panel):
    bl_label = "Size & Profile"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_baseboard"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s, _ = active_settings(context, 'BASEBOARD')

        draw_preset_block(layout, s, 'BASEBOARD')
        layout.separator()

        col = layout.column(align=True)
        col.prop(s, "height")
        col.prop(s, "depth")
        layout.separator()
        draw_edge_block(layout, s, "inner", "Inner Edge")
        layout.separator()
        draw_edge_block(layout, s, "outer", "Outer Edge")
        layout.separator()
        layout.prop(s, "placement")
        if s.placement == 'CHAIR_RAIL':
            layout.prop(s, "rail_height")
        layout.prop(s, "flip_side")


class VIEW3D_PT_trim_baseboard_fit(Panel):
    bl_label = "Fit"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_baseboard"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'BASEBOARD')
        col = layout.column(align=True)
        col.prop(s, "wall_offset")
        col.prop(s, "vertical_offset")
        col.prop(s, "extend")
        layout.prop(s, "stop_at_obstacles")
        col = layout.column(align=True)
        col.prop(s, "auto_extend")
        sub = col.column(align=True)
        sub.enabled = s.auto_extend
        sub.prop(s, "auto_extend_max")
        sub.prop(s, "auto_extend_overlap")
        layout.prop(s, "cap_ends")
        layout.prop(s, "miter_limit")
        col = layout.column(align=True)
        col.prop(s, "refine")
        sub = col.row()
        sub.enabled = s.refine > 0
        sub.prop(s, "refine_angle")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        draw_unwrap_block(layout, context, 'BASEBOARD')


class VIEW3D_PT_trim_baseboard_wainscot(Panel):
    bl_label = "Wainscoting"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_baseboard"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        s, obj = active_settings(context, 'BASEBOARD')
        if obj is not None:
            self.layout.prop(s, "wainscot", text="")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s, obj = active_settings(context, 'BASEBOARD')
        if obj is None:
            layout.label(text="Used by Create Wainscoting", icon='INFO')
        elif s.placement != 'SKIRTING':
            layout.label(text="Only with Placement: Skirting", icon='INFO')
        if obj is not None:
            layout.enabled = s.wainscot and s.placement == 'SKIRTING'
        col = layout.column(align=True)
        col.prop(s, "wains_height")
        col.prop(s, "wains_backer")
        layout.separator()
        col = layout.column(align=True)
        col.prop(s, "wains_frame_width")
        col.prop(s, "wains_frame_depth")
        layout.separator()
        col = layout.column(align=True)
        col.prop(s, "wains_layout")
        col.prop(s, "wains_panel_width")
        if s.wains_layout == 'ALTERNATE':
            col.prop(s, "wains_ratio")
        layout.separator()
        layout.prop(s, "wains_raised")
        col = layout.column(align=True)
        col.enabled = s.wains_raised
        col.prop(s, "wains_raise")
        col.prop(s, "wains_bevel")
        layout.separator()
        layout.prop(s, "wains_cap")
        col = layout.column(align=True)
        col.enabled = s.wains_cap
        col.prop(s, "wains_cap_height")
        col.prop(s, "wains_cap_depth")
        layout.separator()
        layout.prop(s, "wains_uv_size")


class VIEW3D_PT_trim_baseboard_shading(Panel):
    bl_label = "Shading"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_baseboard"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'BASEBOARD')
        layout.prop(s, "shade_smooth")
        sub = layout.column()
        sub.enabled = s.shade_smooth
        sub.prop(s, "smooth_angle")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'BASEBOARD')
        layout.prop(s, "material")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'BASEBOARD')
        layout.operator("trim.preset_folder", icon='FILE_FOLDER')
        layout.prop(s, "tolerance")
        layout.prop(s, "parent_to_source")


class VIEW3D_PT_trim_doorframe(Panel):
    bl_label = "Door Frame"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_main"

    def draw_header_preset(self, context):
        op = self.layout.operator("trim.reset_settings", text="", icon='LOOP_BACK',
                                  emboss=False)
        op.kind = 'DOORFRAME'

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        row = layout.row()
        row.scale_y = 1.2
        row.operator("trim.create_doorframe", text="Create Door Frame")
        draw_header_block(layout, context, 'DOORFRAME',
                          "One loop, on one face of the wall")


class VIEW3D_PT_trim_doorframe_size(Panel):
    bl_label = "Size & Profile"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_doorframe"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s, _ = active_settings(context, 'DOORFRAME')

        draw_preset_block(layout, s, 'DOORFRAME')
        layout.separator()

        col = layout.column(align=True)
        col.prop(s, "width")
        col.prop(s, "thickness")
        layout.separator()
        draw_edge_block(layout, s, "inner", "Inner Edge")
        layout.separator()
        draw_edge_block(layout, s, "outer", "Outer Edge")
        layout.separator()
        col = layout.column(align=True)
        col.prop(s, "skip_bottom")
        col.prop(s, "flip_side")
        col.prop(s, "both_sides", text="Mirror")


class VIEW3D_PT_trim_doorframe_jamb(Panel):
    bl_label = "Jamb"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_doorframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'DOORFRAME')
        layout.prop(s, "jamb")
        sub = layout.column(align=True)
        sub.enabled = s.jamb
        sub.prop(s, "jamb_depth")
        sub.prop(s, "jamb_reveal")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        draw_unwrap_block(layout, context, 'DOORFRAME')


class VIEW3D_PT_trim_doorframe_shading(Panel):
    bl_label = "Shading"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_doorframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'DOORFRAME')
        layout.prop(s, "shade_smooth")
        sub = layout.column()
        sub.enabled = s.shade_smooth
        sub.prop(s, "smooth_angle")
        layout.prop(s, "cap_ends")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'DOORFRAME')
        layout.prop(s, "material")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'DOORFRAME')
        col = layout.column(align=True)
        col.prop(s, "refine")
        sub = col.row()
        sub.enabled = s.refine > 0
        sub.prop(s, "refine_angle")
        layout.separator()
        layout.prop(s, "reveal")
        layout.prop(s, "tolerance")
        layout.prop(s, "miter_limit")
        layout.prop(s, "parent_to_source")


# --------------------------------------------------------------------- window

class VIEW3D_PT_trim_windowframe(Panel):
    bl_label = "Window Frame"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_main"

    def draw_header_preset(self, context):
        op = self.layout.operator("trim.reset_settings", text="", icon='LOOP_BACK',
                                  emboss=False)
        op.kind = 'WINDOWFRAME'

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        row = layout.row()
        row.scale_y = 1.2
        row.operator("trim.create_windowframe", text="Create Window Frame")
        s, obj = draw_header_block(layout, context, 'WINDOWFRAME',
                                   "One loop, on one face of the wall")
        layout.label(text="Mirror adds the far half", icon='MOD_MIRROR')


class VIEW3D_PT_trim_windowframe_size(Panel):
    bl_label = "Size & Profile"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_windowframe"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s, _ = active_settings(context, 'WINDOWFRAME')

        draw_preset_block(layout, s, 'WINDOWFRAME')
        layout.separator()

        col = layout.column(align=True)
        col.prop(s, "width")
        col.prop(s, "thickness")
        layout.separator()
        draw_edge_block(layout, s, "inner", "Inner Edge")
        layout.separator()
        draw_edge_block(layout, s, "outer", "Outer Edge")
        layout.separator()
        col = layout.column(align=True)
        col.prop(s, "flip_side")
        col.prop(s, "both_sides", text="Mirror")


class VIEW3D_PT_trim_windowframe_sill(Panel):
    bl_label = "Window Sill"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_windowframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        s, _ = active_settings(context, 'WINDOWFRAME')
        self.layout.prop(s, "sill", text="")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s, _ = active_settings(context, 'WINDOWFRAME')

        col = layout.column(align=True)
        col.enabled = s.sill
        col.prop(s, "sill_thickness")
        col.prop(s, "sill_depth")
        col.prop(s, "sill_inset")
        col.prop(s, "sill_overhang")

        col = layout.column(align=True)
        col.enabled = s.sill
        col.prop(s, "sill_edge")
        if s.sill_edge in SHAPED:
            col.prop(s, "sill_edge_size")
        if s.sill_edge in ROUNDED:
            col.prop(s, "sill_edge_segments")

        if not s.sill:
            layout.label(text="Off: the casing runs all around", icon='INFO')


class VIEW3D_PT_trim_windowframe_jamb(Panel):
    bl_label = "Jamb"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_windowframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'WINDOWFRAME')
        layout.prop(s, "jamb")
        sub = layout.column(align=True)
        sub.enabled = s.jamb
        sub.prop(s, "jamb_depth")
        sub.prop(s, "jamb_reveal")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        draw_unwrap_block(layout, context, 'WINDOWFRAME')


class VIEW3D_PT_trim_windowframe_shading(Panel):
    bl_label = "Shading"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_windowframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'WINDOWFRAME')
        layout.prop(s, "shade_smooth")
        sub = layout.column()
        sub.enabled = s.shade_smooth
        sub.prop(s, "smooth_angle")
        layout.prop(s, "cap_ends")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'WINDOWFRAME')
        layout.prop(s, "material")



    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        s, _ = active_settings(context, 'WINDOWFRAME')
        col = layout.column(align=True)
        col.prop(s, "refine")
        sub = col.row()
        sub.enabled = s.refine > 0
        sub.prop(s, "refine_angle")
        layout.separator()
        layout.prop(s, "reveal")
        layout.prop(s, "tolerance")
        layout.prop(s, "miter_limit")
        layout.prop(s, "parent_to_source")


class VIEW3D_PT_trim_baseboard_texture(Panel):
    bl_label = "Library Texture"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_baseboard"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        draw_library_texture_block(layout, context, 'BASEBOARD')


class VIEW3D_PT_trim_baseboard_collision(Panel):
    bl_label = "Collision"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_baseboard"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        draw_collision_block(layout, context, 'BASEBOARD')


class VIEW3D_PT_trim_doorframe_texture(Panel):
    bl_label = "Library Texture"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_doorframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        draw_library_texture_block(layout, context, 'DOORFRAME')


class VIEW3D_PT_trim_doorframe_collision(Panel):
    bl_label = "Collision"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_doorframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        draw_collision_block(layout, context, 'DOORFRAME')


class VIEW3D_PT_trim_windowframe_texture(Panel):
    bl_label = "Library Texture"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_windowframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        draw_library_texture_block(layout, context, 'WINDOWFRAME')


class VIEW3D_PT_trim_windowframe_collision(Panel):
    bl_label = "Collision"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "plinthes fred"
    bl_parent_id = "VIEW3D_PT_trim_windowframe"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        draw_collision_block(layout, context, 'WINDOWFRAME')


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    TRIM_PG_baseboard,
    TRIM_PG_doorframe,
    TRIM_PG_windowframe,
    TRIM_PG_scene,
    TRIM_OT_create_baseboard,
    TRIM_OT_auto_trim,
    TRIM_OT_create_doorframe,
    TRIM_OT_create_windowframe,
    TRIM_OT_preset_save,
    TRIM_OT_preset_delete,
    TRIM_OT_preset_folder,
    TRIM_OT_fix_uv,
    TRIM_OT_lock_uv,
    TRIM_OT_rebuild,
    TRIM_OT_apply_texture,
    TRIM_OT_reset,
    TRIM_OT_select_source,
    TRIM_OT_preset_texture_collision,
    VIEW3D_PT_trim_main,
    VIEW3D_PT_trim_baseboard,
    VIEW3D_PT_trim_baseboard_size,
    VIEW3D_PT_trim_baseboard_fit,
    VIEW3D_PT_trim_baseboard_wainscot,
    VIEW3D_PT_trim_baseboard_shading,
    VIEW3D_PT_trim_baseboard_texture,
    VIEW3D_PT_trim_baseboard_collision,
    VIEW3D_PT_trim_doorframe,
    VIEW3D_PT_trim_doorframe_size,
    VIEW3D_PT_trim_doorframe_shading,
    VIEW3D_PT_trim_doorframe_jamb,
    VIEW3D_PT_trim_doorframe_texture,
    VIEW3D_PT_trim_doorframe_collision,
    VIEW3D_PT_trim_windowframe,
    VIEW3D_PT_trim_windowframe_size,
    VIEW3D_PT_trim_windowframe_shading,
    VIEW3D_PT_trim_windowframe_sill,
    VIEW3D_PT_trim_windowframe_jamb,
    VIEW3D_PT_trim_windowframe_texture,
    VIEW3D_PT_trim_windowframe_collision,
)


# ===========================================================================
#  Interface language (English / Francais / Espanol)
# ===========================================================================

# English text -> (French, Spanish).  Anything missing stays in English.
UI_TEXT = {
    "plinthes fred": ("plinthes fred", "plinthes fred"),
    "Language": ("Langue", "Idioma"),
    "Create From Selection": ("Créer depuis la sélection", "Crear desde la selección"),
    "Auto Detect (whole wall)": ("Détection auto (mur entier)", "Detección auto (muro entero)"),
    "Auto Detect": ("Détection auto", "Detección auto"),
    "Baseboards": ("Plinthes", "Zócalos"),
    "Ceiling Mouldings": ("Moulures plafond", "Molduras de techo"),
    "Doors": ("Portes", "Puertas"),
    "Windows": ("Fenêtres", "Ventanas"),
    "Baseboard Around Doors": ("Plinthe autour des portes", "Zócalo alrededor de puertas"),
    "As Wainscoting": ("En lambris", "Como friso"),
    "Door Frames": ("Cadres de porte", "Marcos de puerta"),
    "Window Frames": ("Cadres de fenêtre", "Marcos de ventana"),
    "Max Wall Thickness": ("Épaisseur max. du mur", "Grosor máx. del muro"),
    "Interior:": ("Intérieur :", "Interior:"),
    "Create Baseboard": ("Créer plinthe", "Crear zócalo"),
    "Create Wainscoting": ("Créer lambris", "Crear friso"),
    "Create Ceiling Moulding": ("Créer moulure plafond", "Crear moldura de techo"),
    "Create Door Frame": ("Créer cadre de porte", "Crear marco de puerta"),
    "Create Window Frame": ("Créer cadre de fenêtre", "Crear marco de ventana"),
    "Enter Edit Mode on a wall mesh": ("Passe en Edit Mode sur un mur", "Entra en Edit Mode en un muro"),
    "Texture:": ("Texture :", "Textura:"),
    "Texture": ("Texture", "Textura"),
    "Apply Texture": ("Appliquer la texture", "Aplicar textura"),
    "Apply Texture (%d selected)": ("Appliquer la texture (%d sélectionnés)", "Aplicar textura (%d seleccionados)"),
    "Use For Next Trims": ("Utiliser pour les prochaines", "Usar para las siguientes"),
    "Baseboard": ("Plinthe", "Zócalo"),
    "Door Frame": ("Cadre de porte", "Marco de puerta"),
    "Window Frame": ("Cadre de fenêtre", "Marco de ventana"),
    "Edit Mode: select wall faces or edges": ("Edit Mode : sélectionne les faces ou arêtes du mur", "Edit Mode: selecciona caras o aristas del muro"),
    "One loop, on one face of the wall": ("Une boucle, sur une face du mur", "Un contorno, en una cara del muro"),
    "Settings for the next trim": ("Réglages pour la prochaine moulure", "Ajustes para la próxima moldura"),
    "Live Update": ("Mise à jour directe", "Actualización en vivo"),
    "Rebuild": ("Reconstruire", "Reconstruir"),
    "Source: %s": ("Source : %s", "Origen: %s"),
    "Size & Profile": ("Taille et profil", "Tamaño y perfil"),
    "Preset": ("Préréglage", "Preajuste"),
    "My Presets": ("Mes préréglages", "Mis preajustes"),
    "Select...": ("Choisir...", "Elegir..."),
    "Height": ("Hauteur", "Altura"),
    "Depth": ("Épaisseur", "Grosor"),
    "Width": ("Largeur", "Ancho"),
    "Thickness": ("Épaisseur", "Grosor"),
    "Inner Edge": ("Arête intérieure", "Arista interior"),
    "Outer Edge": ("Arête extérieure", "Arista exterior"),
    "Edge": ("Arête", "Arista"),
    "Size": ("Taille", "Tamaño"),
    "Segments": ("Segments", "Segmentos"),
    "Steps": ("Marches", "Escalones"),
    "Step Depth": ("Profondeur des marches", "Profundidad de escalones"),
    "Placement": ("Position", "Posición"),
    "Skirting": ("Plinthe (sol)", "Zócalo (suelo)"),
    "Crown": ("Corniche (plafond)", "Cornisa (techo)"),
    "Chair Rail": ("Cimaise", "Guardasillas"),
    "Rail Height": ("Hauteur cimaise", "Altura guardasillas"),
    "Flip Side": ("Inverser le côté", "Invertir lado"),
    "Fit": ("Ajustement", "Ajuste"),
    "Wall Gap": ("Écart au mur", "Separación del muro"),
    "Vertical Offset": ("Décalage vertical", "Desplazamiento vertical"),
    "Extend Ends": ("Prolonger les bouts", "Extender extremos"),
    "Stop At Frames": ("Arrêter aux cadres", "Parar en los marcos"),
    "Auto Extend": ("Prolonger auto", "Extender auto"),
    "Search Distance": ("Distance de recherche", "Distancia de búsqueda"),
    "Overlap": ("Chevauchement", "Solapamiento"),
    "Cap Ends": ("Fermer les bouts", "Cerrar extremos"),
    "Miter Limit": ("Limite d'onglet", "Límite de inglete"),
    "Refine Curves": ("Lisser les courbes", "Suavizar curvas"),
    "Curve Limit": ("Limite de courbe", "Límite de curva"),
    "Wainscoting": ("Lambris", "Friso"),
    "Used by Create Wainscoting": ("Utilisé par Créer lambris", "Usado por Crear friso"),
    "Only with Placement: Skirting": ("Seulement en position Plinthe (sol)", "Solo en posición Zócalo (suelo)"),
    "Board Thickness": ("Épaisseur du panneau", "Grosor del tablero"),
    "Frame Width": ("Largeur du cadre", "Ancho del marco"),
    "Frame Depth": ("Relief du cadre", "Relieve del marco"),
    "Layout": ("Disposition", "Disposición"),
    "Uniform": ("Uniforme", "Uniforme"),
    "Narrow / Wide": ("Étroit / large", "Estrecho / ancho"),
    "Panel Width": ("Largeur des panneaux", "Ancho de paneles"),
    "Wide / Narrow": ("Large / étroit", "Ancho / estrecho"),
    "Raised Panels": ("Panneaux en relief", "Paneles en relieve"),
    "Panel Thickness": ("Épaisseur des panneaux", "Grosor de paneles"),
    "Bevel": ("Biseau", "Bisel"),
    "Cap Rail": ("Moulure du haut", "Moldura superior"),
    "Cap Height": ("Hauteur moulure", "Altura moldura"),
    "Cap Depth": ("Épaisseur moulure", "Grosor moldura"),
    "Texture Size": ("Taille de texture", "Tamaño de textura"),
    "Shading": ("Ombrage", "Sombreado"),
    "Shade Smooth": ("Lissage", "Suavizado"),
    "Angle": ("Angle", "Ángulo"),
    "Material": ("Matériau", "Material"),
    "Library Texture": ("Texture de bibliothèque", "Textura de biblioteca"),
    "Shader: Default Sollumz": ("Shader : Sollumz default", "Shader: Sollumz default"),
    "Sollumz not found": ("Sollumz introuvable", "Sollumz no encontrado"),
    "Install/enable it to auto-create the material": ("Installe-le pour créer le matériau", "Instálalo para crear el material"),
    "Collision": ("Collision", "Colisión"),
    "Margin": ("Marge", "Margen"),
    "Still needs Sollumz's own bound setup for export": ("Il faut encore le réglage bound de Sollumz pour l'export", "Aún necesita la configuración bound de Sollumz para exportar"),
    "Texture + Collision": ("Texture + collision", "Textura + colisión"),
    "Generate UVs": ("Générer les UV", "Generar UV"),
    "Continuous Texture": ("Texture continue", "Textura continua"),
    "Mode": ("Mode", "Modo"),
    "Fit Texture": ("Ajuster à la texture", "Ajustar a la textura"),
    "Fit Profile": ("Ajuster au profil", "Ajustar al perfil"),
    "World Metres": ("Mètres monde", "Metros mundo"),
    "Tile Length": ("Longueur de répétition", "Longitud de repetición"),
    "Flip V": ("Inverser V", "Invertir V"),
    "UV Scale": ("Échelle UV", "Escala UV"),
    "Extra Scale": ("Échelle en plus", "Escala extra"),
    "Lock": ("Verrouiller", "Bloquear"),
    "Locked": ("Verrouillé", "Bloqueado"),
    "Lock This Value": ("Verrouiller cette valeur", "Bloquear este valor"),
    "Unlocked: changes with the texture": ("Déverrouillé : suit la texture", "Desbloqueado: sigue la textura"),
    "No image texture found": ("Aucune image trouvée", "No se encontró imagen"),
    "Using Tile Length instead": ("Longueur de répétition utilisée", "Se usa la longitud de repetición"),
    "Ratio %s : 1, pixels kept square": ("Ratio %s : 1, pixels carrés", "Proporción %s : 1, píxeles cuadrados"),
    "Repeat every %s m": ("Répétition tous les %s m", "Repetición cada %s m"),
    "This mesh has no UV map": ("Ce mesh n'a pas de carte UV", "Este mesh no tiene mapa UV"),
    "No UV map is flagged for render": ("Aucune carte UV marquée pour le rendu", "Ningún mapa UV marcado para render"),
    "Fix It": ("Corriger", "Corregir"),
    "Vertex Color": ("Couleur de sommet", "Color de vértice"),
    "Color": ("Couleur", "Color"),
    "Advanced": ("Avancé", "Avanzado"),
    "Tolerance": ("Tolérance", "Tolerancia"),
    "Parent To Source": ("Parenter au mur", "Emparentar al muro"),
    "Open Preset Folder": ("Ouvrir le dossier des préréglages", "Abrir carpeta de preajustes"),
    "Jamb": ("Tableau", "Jamba"),
    "Jamb Lining": ("Habillage du tableau", "Revestimiento de jamba"),
    "Jamb Depth": ("Profondeur du tableau", "Profundidad de jamba"),
    "Jamb Thickness": ("Épaisseur du tableau", "Grosor de jamba"),
    "Reveal": ("Retrait", "Retranqueo"),
    "Skip Floor Run": ("Pas de bas au sol", "Sin tramo en el suelo"),
    "Mirror": ("Miroir", "Espejo"),
    "Mirror adds the far half": ("Miroir ajoute l'autre côté du mur", "Espejo añade el otro lado del muro"),
    "Window Sill": ("Appui de fenêtre", "Alféizar"),
    "Overhang": ("Débord", "Vuelo"),
    "Inset": ("Retrait", "Entrante"),
    "Front Edge": ("Arête avant", "Arista frontal"),
    "Edge Size": ("Taille d'arête", "Tamaño de arista"),
    "Ceiling": ("Plafond", "Techo"),
    "Off: the casing runs all around": ("Décoché : le cadre fait tout le tour", "Desactivado: el marco da toda la vuelta"),
    "Square": ("Droit", "Recto"),
    "Chamfer": ("Chanfrein", "Chaflán"),
    "Chamfered": ("Chanfreiné", "Achaflanado"),
    "Bullnose": ("Arrondi", "Redondeado"),
    "Cove": ("Gorge", "Media caña"),
    "Ogee": ("Doucine", "Gola"),
    "Stepped": ("À gradins", "Escalonado"),
    "Flat Slab": ("Plate", "Plana"),
    "Molded": ("Moulurée", "Moldurada"),
    "Craftsman": ("Craftsman", "Craftsman"),
    "Colonial": ("Colonial", "Colonial"),
    "Victorian": ("Victorienne", "Victoriana"),
}

def _ui_lang():
    try:
        lang = bpy.context.scene.trim_settings.language
    except Exception:
        lang = 'AUTO'
    if lang == 'AUTO':
        loc = (bpy.app.translations.locale or "")[:2].lower()
        return {'fr': 'FR', 'es': 'ES'}.get(loc, 'EN')
    return lang


def _template_rx(key):
    import re
    parts = re.split(r'(%[-0-9.]*[sdf])', key)
    rx = "".join("(.+?)" if re.fullmatch(r'%[-0-9.]*[sdf]', p) else re.escape(p)
                 for p in parts)
    return re.compile("^" + rx + "$")


_TEMPLATES = [(k, _template_rx(k)) for k in UI_TEXT if "%" in k]


def T(text):
    """Translate one UI string into the chosen language."""
    if not text:
        return text
    lang = _ui_lang()
    if lang == 'EN':
        return text
    col = 0 if lang == 'FR' else 1
    hit = UI_TEXT.get(text)
    if hit:
        return hit[col]
    for key, rx in _TEMPLATES:
        m = rx.match(text)
        if m:
            out = UI_TEXT[key][col]
            for g in m.groups():
                out = out.replace("%s", g, 1) if "%s" in out else out.replace("%d", g, 1)
            return out
    return text


class _TL:
    """Layout wrapper that translates every label it draws."""
    __slots__ = ("_l",)
    _SUB = {"row", "column", "box", "split", "grid_flow", "column_flow"}

    def __init__(self, layout):
        object.__setattr__(self, "_l", layout)

    def __getattr__(self, name):
        attr = getattr(self._l, name)
        if name in _TL._SUB:
            return lambda *a, **k: _TL(attr(*a, **k))
        return attr

    def __setattr__(self, name, value):
        setattr(self._l, name, value)

    def label(self, *a, text="", **k):
        return self._l.label(*a, text=T(text), **k)

    def prop(self, data, prop, *a, text=None, **k):
        if text is None:
            try:
                text = data.bl_rna.properties[prop].name
            except Exception:
                text = None
        if text is not None:
            k["text"] = T(text)
        return self._l.prop(data, prop, *a, **k)

    def operator(self, idname, *a, text=None, **k):
        if text is None:
            try:
                mod, fn = idname.split(".")
                text = getattr(getattr(bpy.ops, mod), fn).get_rna_type().name
            except Exception:
                text = None
        if text is not None:
            k["text"] = T(text)
        return self._l.operator(idname, *a, **k)


class _PanelView:
    """What a panel's draw() sees: the real panel, with a translating layout."""
    def __init__(self, panel):
        object.__setattr__(self, "_p", panel)

    def __getattr__(self, name):
        if name == "layout":
            return _TL(self._p.layout)
        return getattr(self._p, name)


def _wrap_draw(fn):
    def draw(self, context):
        return fn(_PanelView(self), context)
    return draw


def _translate_panels():
    """Re-register the panels so their titles show in the chosen language."""
    panels = [c for c in classes if issubclass(c, Panel)]
    for c in reversed(panels):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
    for c in panels:
        c.bl_label = T(getattr(c, "_en_label", c.bl_label))
        bpy.utils.register_class(c)


def _language_update(self, context):
    try:
        _translate_panels()
    except Exception as exc:
        print("[plinthes fred] language switch failed:", exc)
    for win in context.window_manager.windows:
        for area in win.screen.areas:
            area.tag_redraw()


def _prepare_i18n():
    for c in classes:
        if issubclass(c, Panel) and not getattr(c, "_i18n", False):
            c._en_label = c.bl_label
            for meth in ("draw", "draw_header", "draw_header_preset"):
                fn = c.__dict__.get(meth)
                if fn is not None:
                    setattr(c, meth, _wrap_draw(fn))
            c._i18n = True


def _apply_language_on_load(*_args):
    try:
        if _ui_lang() != 'EN':
            _translate_panels()
    except Exception:
        pass


def register():
    _prepare_i18n()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.trim_settings = PointerProperty(type=TRIM_PG_scene)
    bpy.types.Object.trim_baseboard = PointerProperty(type=TRIM_PG_baseboard)
    bpy.types.Object.trim_doorframe = PointerProperty(type=TRIM_PG_doorframe)
    bpy.types.Object.trim_windowframe = PointerProperty(type=TRIM_PG_windowframe)
    if _apply_language_on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_apply_language_on_load)
    bpy.app.timers.register(_apply_language_on_load, first_interval=0.5)


def unregister():
    if _apply_language_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_apply_language_on_load)
    del bpy.types.Object.trim_windowframe
    del bpy.types.Object.trim_doorframe
    del bpy.types.Object.trim_baseboard
    del bpy.types.Scene.trim_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()